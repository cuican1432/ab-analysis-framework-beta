---
name: ab-analysis-framework-beta
description: TT A/B 实验分析框架主入口技能。主要用于实验报告生成，以及基于 PRD 与 Raw Data 联合解读后输出标准化实验报告。用户提到 A/B 实验分析、实验复盘、实验报告、PRD + 数据联合解读并希望直接写报告时，应优先使用本技能。
---

# TT AB Analysis Framework

It mainly supports two task types:

1. Experiment Report Generation
2. Report Generation with Temporary Guidance

You do not need to remember the internal helper skills. In most cases, calling `ab-analysis-framework-beta` directly is enough.

If the main goal is to build or normalize the knowledge store itself rather than run experiment analysis, use `ab-knowledge-builder-beta`.

## 1) Experiment Report Generation

### Use this when
- 实验观测期结束，数据已经就绪
- 需要基于 PRD + raw data 文档快速生成标准化实验报告

### You can say
- Please use `ab-analysis-framework-beta` to generate an experiment report.
- Experiment name (optional): [xxx]
- PRD link: [URL]
- Raw Data link: [URL]

### Hard Constraints | 关键硬约束
- Output the final result as a Feishu/Lark doc when tooling permits; otherwise return a fully structured doc body the user can paste.
- Follow the strict report structure: `总结论 + 总建议` first, then repeat `分结论 -> 归因链路 -> 细节表格`.
- Keep attribution evidence-bound. No unsupported psych speculation.
- Fully disclose significant movements of core secondary metrics; do not hide them because they are not the headline metric.
- Before writing `实验背景与设计`, extract required setup/config fields from the source header verbatim. Missing fields must be `not found`; PRD/Raw Data conflicts must be shown side-by-side with `to confirm`.
- Do not truncate the raw detail tables in `## 数据附录 (Data Appendix)`. Follow the fallback chain in `references/core/report_output_rules.md`.
- For detailed output/formatting/appendix rules, use `references/core/report_output_rules.md` as the single source of truth.

### What the system will do
- run the doc-first analysis workflow
- silently prioritize stored metric glossary and business knowledge
- recall core-flag metric groups by default, especially any group marked as company-core, business-core, or sub-business-core
- identify the experiment's primary business domain first, then apply domain-first recall before ordering metric groups
- perform attribution, risk review, and evidence-boundary labeling when needed
- output a structured experiment report as a Feishu/Lark doc using standard Markdown (tables, emoji markers, blockquotes, bold) rather than scattered analysis fragments

## 2) Report Generation with Temporary Guidance

### Use this when
- 本期实验有临时监控指标
- 本次需要一个临时极性或解释规则
- 你不希望把它永久写入知识库

### You can say
- Please use `ab-analysis-framework-beta` to generate an experiment report with this temporary metric/rule guidance.
- Experiment name (optional): [xxx]
- PRD link: [URL]
- Raw Data link: [URL]
- Temporary metric guidance: [example: click_report increasing means worsening risk in this experiment]

### What the system will do
- apply the temporary instruction only for the current run
- prioritize it during attribution and polarity judgment
- do not write it back into the long-term knowledge base unless explicitly asked
- still obey hard framework rules and never relax data discipline because of a temporary note

## Internal reference map

- Report Generation →
  - `references/core/*`
  - `references/knowledge/glossary/index.md`
  - `references/knowledge/kb/index.md`
  - then follow default read order steps `3-6` below when the case needs knowledge recall
- Temporary Guidance Report →
  - `references/core/*`
  - `references/knowledge/glossary/index.md`
  - `references/knowledge/kb/index.md`
  - current-run temporary guidance first, then follow default read order steps `3-6` below

## Core Read Order

When reading `references/core/*`, use this order:

1. `workflow.md`
2. `rules.md`
3. `memory.md`
4. `runbook.md`
5. `report_output_rules.md`
6. `tooling.md`

## Storage Hint

- Knowledge reading layer → `references/knowledge/*`
- Long-term live glossary content → `userdata/ab-analysis-framework-beta/glossary/*`
- Long-term live business knowledge → `userdata/ab-analysis-framework-beta/kb/*`
- Glossary maintenance rules → `references/knowledge/glossary_guide.md`
- Business knowledge maintenance rules → `references/knowledge/knowledge_guide.md`
- Runtime local incremental layer → `userdata/ab-analysis-framework-beta/*`
- Memory can help recall, but it is not the main glossary store

## Userdata Boundary

When the user wants to inject local knowledge, local data files, or run-specific reusable notes, use `userdata/ab-analysis-framework-beta/` as the default writable layer.

- Local glossary additions / partial confirmations → `userdata/ab-analysis-framework-beta/glossary/`
- Local business notes / project context → `userdata/ab-analysis-framework-beta/kb/`
- User-specific interpretation rules / temporary reusable overrides → `userdata/ab-analysis-framework-beta/custom_rules/`

Do not casually rewrite packaged shared references during normal ingestion:

- packaged knowledge guides and reading indexes stay in `references/knowledge/*`
- local evolving and long-term live knowledge should go to `userdata/ab-analysis-framework-beta/*`

Default read order:

1. `references/core/*`
2. current-run explicit temporary guidance
3. `references/knowledge/*`
4. `userdata/ab-analysis-framework-beta/custom_rules/*`
5. `userdata/ab-analysis-framework-beta/glossary/*`
6. `userdata/ab-analysis-framework-beta/kb/*`

Do not use generic roots such as `userdata/glossary/` or `userdata/kb/`; keep the skill-scoped namespace to avoid collisions with other packages.

Metric recall reminder:

- do not narrow the recall set only to the experiment's most obvious business theme
- any glossary metric group marked as company-core, business-core, or sub-business-core should be recalled by default
- for the experiment's own subdomain, also recall the related `001`, `011`, and `111` metric groups by default
- if a flagged core group is missing from the source, state that it is unavailable instead of silently dropping it
- treat glossary `importance` as a base priority
- do not treat one domain's stored priority table as universal; a `DM`-scoped ordering may need to be re-ranked when the experiment's primary business domain is `Share&Repost`, `Sticker`, `Inbox`, or another domain
- identify the experiment's primary business domain first, then order metric groups with a domain-first lens:
  - same-domain groups first
  - adjacent-domain groups next
  - distant-domain groups after that
- do not assume a group that is `P3` in one domain should stay `P3` when the experiment's primary business domain changes

## Linkage Rule With `ab-knowledge-builder-beta`

`ab-analysis-framework-beta` reads the live knowledge layer under `userdata/ab-analysis-framework-beta/*`, but it does not own detailed knowledge-content editing.

Update this framework skill when one of these changes:

- the knowledge path changes
- the knowledge schema changes
- the read order changes
- new required indexes or reading categories are introduced
- analysis rules must adapt to newly stabilized knowledge conventions

Do not update this framework skill for pure knowledge-content growth by default.
