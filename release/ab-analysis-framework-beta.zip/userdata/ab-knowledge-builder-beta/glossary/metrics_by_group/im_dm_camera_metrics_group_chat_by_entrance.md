# Metrics By Group | [IM] DM Camera Metrics Group Chat by entrance

group_id: 7054232
canonical_name: [IM] DM Camera Metrics Group Chat by entrance
tags: metric-group, dm
wiki_digests: [[digests/digest_7054232_dm_camera_group_chat_by_entrance]]
wiki_matrices: [[digests/event_metric_matrix_7054232_dm_camera_group_chat_by_entrance]]

## Metrics

- Group Chat Send Message from inbox entrance uv/au
  - metric_id: `2005360`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_send_message_from_inbox_entrance_uv_au__id_2005360.md`
- Group Chat Send Message from chat page entrance uv/au
  - metric_id: `2005361`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_send_message_from_chat_page_entrance_uv_au__id_2005361.md`
- Group Chat Send Message from try effect entrance uv/au
  - metric_id: `2005362`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_send_message_from_try_effect_entrance_uv_au__id_2005362.md`
- Group Chat Send Message from video detail entrance uv/au
  - metric_id: `2005363`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_send_message_from_video_detail_entrance_uv_au__id_2005363.md`
- Group Chat Send Message from main posting entrance uv/au
  - metric_id: `2005364`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_send_message_from_main_posting_entrance_uv_au__id_2005364.md`
- Group Chat Send Message from chat upload entrance uv/au
  - metric_id: `2005365`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_send_message_from_chat_upload_entrance_uv_au__id_2005365.md`
- Group Chat Click DM Camera shooting entrance uv/au
  - metric_id: `2005366`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_click_dm_camera_shooting_entrance_uv_au__id_2005366.md`
- Group Chat Click try effect entrance uv/au
  - metric_id: `2005367`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_click_try_effect_entrance_uv_au__id_2005367.md`
- Group Chat Click video detail entrance uv/au
  - metric_id: `2005368`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_click_video_detail_entrance_uv_au__id_2005368.md`
- Group Chat Click inbox camera icon entrance uv/au
  - metric_id: `2005369`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_click_inbox_camera_icon_entrance_uv_au__id_2005369.md`
- Group Chat Click chat page entrance uv/au
  - metric_id: `2005370`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_click_chat_page_entrance_uv_au__id_2005370.md`
- Group Chat Click chat page upload entrance uv/au
  - metric_id: `2005371`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_click_chat_page_upload_entrance_uv_au__id_2005371.md`

## Auto Definitions (Excerpt)

### Metric: Group Chat Click chat page entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054232
- Digest: [[digests/digest_7054232_dm_camera_group_chat_by_entrance]]
- Numerator: `T2:group_chat_page_camera_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click chat page entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054232.json`
- Field family: `camera_group_entrance_click`
- Aggregation: `uv/base_user`
- Meaning: 群聊 chat page 入口点击覆盖
- Key filters:
  - `chat_type = group` - 将整个包限定在群聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看群聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Click chat page upload entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054232
- Digest: [[digests/digest_7054232_dm_camera_group_chat_by_entrance]]
- Numerator: `T2:group_chat_album_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click chat page upload entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054232.json`
- Key filters:
  - `chat_type = group` - 将整个包限定在群聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看群聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Click DM Camera shooting entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054232
- Digest: [[digests/digest_7054232_dm_camera_group_chat_by_entrance]]
- Numerator: `T2:group_chat_camera_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click DM Camera Shooting entrance uv/au (exclude main posting flow)
- Provenance: `raw/libra/libra_metric_group_7054232.json`
- Key filters:
  - `chat_type = group` - 将整个包限定在群聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看群聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Click inbox camera icon entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054232
- Digest: [[digests/digest_7054232_dm_camera_group_chat_by_entrance]]
- Numerator: `T2:group_chat_inbox_camera_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click inbox camera icon entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054232.json`
- Field family: `camera_group_entrance_click`
- Aggregation: `uv/base_user`
- Meaning: 群聊 inbox 入口点击覆盖
- Key filters:
  - `chat_type = group` - 将整个包限定在群聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看群聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Click try effect entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054232
- Digest: [[digests/digest_7054232_dm_camera_group_chat_by_entrance]]
- Numerator: `T2:group_chat_try_effect_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click try effect entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054232.json`
- Key filters:
  - `chat_type = group` - 将整个包限定在群聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看群聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Click video detail entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054232
- Digest: [[digests/digest_7054232_dm_camera_group_chat_by_entrance]]
- Numerator: `T2:group_chat_video_detail_camera_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click video detail entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054232.json`
- Field family: `camera_group_entrance_click`
- Aggregation: `uv/base_user`
- Meaning: 群聊 video detail 入口点击覆盖
- Key filters:
  - `chat_type = group` - 将整个包限定在群聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看群聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Send Message from chat page entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054232
- Digest: [[digests/digest_7054232_dm_camera_group_chat_by_entrance]]
- Numerator: `T2:group_chat_page_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send Message from chat page entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054232.json`
- Field family: `camera_group_entrance_send`
- Aggregation: `uv/base_user`
- Meaning: 群聊 chat page 入口发送覆盖
- Key filters:
  - `chat_type = group` - 将整个包限定在群聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看群聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Send Message from chat upload entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054232
- Digest: [[digests/digest_7054232_dm_camera_group_chat_by_entrance]]
- Numerator: `T2:group_chat_page_upload_entrance_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send message from chat page upload entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054232.json`
- Key filters:
  - `chat_type = group` - 将整个包限定在群聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看群聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Send Message from inbox entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054232
- Digest: [[digests/digest_7054232_dm_camera_group_chat_by_entrance]]
- Numerator: `T2:group_chat_inbox_camera_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send Message from inbox entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054232.json`
- Field family: `camera_group_entrance_send`
- Aggregation: `uv/base_user`
- Meaning: 群聊 inbox 入口发送覆盖
- Key filters:
  - `chat_type = group` - 将整个包限定在群聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看群聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Send Message from main posting entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054232
- Digest: [[digests/digest_7054232_dm_camera_group_chat_by_entrance]]
- Numerator: `T2:group_chat_main_posting_camera_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send Message from main posting entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054232.json`
- Key filters:
  - `chat_type = group` - 将整个包限定在群聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看群聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Send Message from try effect entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054232
- Digest: [[digests/digest_7054232_dm_camera_group_chat_by_entrance]]
- Numerator: `T2:group_chat_try_effect_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send Message from try effect entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054232.json`
- Key filters:
  - `chat_type = group` - 将整个包限定在群聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看群聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Send Message from video detail entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054232
- Digest: [[digests/digest_7054232_dm_camera_group_chat_by_entrance]]
- Numerator: `T2:group_chat_video_detail_entrance_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send Message from video detail entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054232.json`
- Field family: `camera_group_entrance_send`
- Aggregation: `uv/base_user`
- Meaning: 群聊 video detail 入口发送覆盖
- Key filters:
  - `chat_type = group` - 将整个包限定在群聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看群聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->
