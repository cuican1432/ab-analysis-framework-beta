# Metrics By Group | [IM] DM Camera Metrics by entrance

group_id: 7043217
canonical_name: [IM] DM Camera Metrics by entrance
tags: metric-group, dm
wiki_digests: [[digests/digest_7043217_dm_camera_by_entrance]]
wiki_matrices: [[digests/event_metric_matrix_7043217_dm_camera_by_entrance]]

## Metrics

- Send Message from inbox entrance uv/au
  - metric_id: `2005318`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_message_from_inbox_entrance_uv_au__id_2005318.md`
- Send Message from chat page entrance uv/au
  - metric_id: `2005319`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_message_from_chat_page_entrance_uv_au__id_2005319.md`
- Send Message from try effect entrance uv/au
  - metric_id: `2005320`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_message_from_try_effect_entrance_uv_au__id_2005320.md`
- Send Message from video detail entrance uv/au
  - metric_id: `2005321`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_message_from_video_detail_entrance_uv_au__id_2005321.md`
- Send Message from main posting entrance uv/au
  - metric_id: `2005322`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_message_from_main_posting_entrance_uv_au__id_2005322.md`
- Send Message from chat upload entrance uv/au
  - metric_id: `2005323`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_message_from_chat_upload_entrance_uv_au__id_2005323.md`
- Click DM Camera shooting entrance uv/au
  - metric_id: `2005324`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_dm_camera_shooting_entrance_uv_au__id_2005324.md`
- Click try effect entrance uv/au
  - metric_id: `2005325`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_try_effect_entrance_uv_au__id_2005325.md`
- Click video detail entrance uv/au
  - metric_id: `2005326`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_video_detail_entrance_uv_au__id_2005326.md`
- Click main posting entrance uv/au
  - metric_id: `2005327`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_main_posting_entrance_uv_au__id_2005327.md`
- Click inbox camera icon entrance uv/au
  - metric_id: `2005328`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_inbox_camera_icon_entrance_uv_au__id_2005328.md`
- Click chat page entrance uv/au
  - metric_id: `2005329`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_chat_page_entrance_uv_au__id_2005329.md`
- Click chat page upload entrance uv/au
  - metric_id: `2005330`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_chat_page_upload_entrance_uv_au__id_2005330.md`
- Enter DM camera shooting page entrance uv/au
  - metric_id: `2005331`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_enter_dm_camera_shooting_page_entrance_uv_au__id_2005331.md`

## Auto Definitions (Excerpt)

### Metric: Click chat page entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043217
- Digest: [[digests/digest_7043217_dm_camera_by_entrance]]
- Numerator: `T2:chat_page_camera_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click chat page entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7043217.json`
- Field family: `camera_entrance_click`
- Aggregation: `uv/base_user`
- Meaning: chat page 相机入口点击覆盖
- Key filters:
  - entrance bucket - 做入口归因
  - camera funnel stage - 区分入口曝光问题与后段转化问题
  - cohort cuts - 看不同人群入口偏好差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Click chat page upload entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043217
- Digest: [[digests/digest_7043217_dm_camera_by_entrance]]
- Numerator: `T2:album_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click chat page upload entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7043217.json`
- Key filters:
  - entrance bucket - 做入口归因
  - camera funnel stage - 区分入口曝光问题与后段转化问题
  - cohort cuts - 看不同人群入口偏好差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Click DM Camera shooting entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043217
- Digest: [[digests/digest_7043217_dm_camera_by_entrance]]
- Numerator: `T2:camera_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click DM Camera Shooting entrance uv/au (exclude main posting flow)
- Provenance: `raw/libra/libra_metric_group_7043217.json`
- Key filters:
  - entrance bucket - 做入口归因
  - camera funnel stage - 区分入口曝光问题与后段转化问题
  - cohort cuts - 看不同人群入口偏好差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Click inbox camera icon entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043217
- Digest: [[digests/digest_7043217_dm_camera_by_entrance]]
- Numerator: `T2:inbox_camera_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click inbox camera icon entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7043217.json`
- Field family: `camera_entrance_click`
- Aggregation: `uv/base_user`
- Meaning: inbox 相机入口点击覆盖
- Key filters:
  - entrance bucket - 做入口归因
  - camera funnel stage - 区分入口曝光问题与后段转化问题
  - cohort cuts - 看不同人群入口偏好差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Click main posting entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043217
- Digest: [[digests/digest_7043217_dm_camera_by_entrance]]
- Numerator: `T2:main_camera_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click main posting entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7043217.json`
- Key filters:
  - entrance bucket - 做入口归因
  - camera funnel stage - 区分入口曝光问题与后段转化问题
  - cohort cuts - 看不同人群入口偏好差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Click try effect entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043217
- Digest: [[digests/digest_7043217_dm_camera_by_entrance]]
- Numerator: `T2:try_effect_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click try effect entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7043217.json`
- Key filters:
  - entrance bucket - 做入口归因
  - camera funnel stage - 区分入口曝光问题与后段转化问题
  - cohort cuts - 看不同人群入口偏好差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Click video detail entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043217
- Digest: [[digests/digest_7043217_dm_camera_by_entrance]]
- Numerator: `T2:video_detail_camera_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click video detail entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7043217.json`
- Field family: `camera_entrance_click`
- Aggregation: `uv/base_user`
- Meaning: video detail 相机入口点击覆盖
- Key filters:
  - entrance bucket - 做入口归因
  - camera funnel stage - 区分入口曝光问题与后段转化问题
  - cohort cuts - 看不同人群入口偏好差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Enter DM camera shooting page entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043217
- Digest: [[digests/digest_7043217_dm_camera_by_entrance]]
- Numerator: `T2:enter_video_shoot_page_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Enter DM camera shooting page entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7043217.json`
- Field family: `camera_shoot_page_entry`
- Aggregation: `uv/base_user`
- Meaning: 进入拍摄页的用户覆盖
- Key filters:
  - entrance bucket - 做入口归因
  - camera funnel stage - 区分入口曝光问题与后段转化问题
  - cohort cuts - 看不同人群入口偏好差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Message from chat page entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043217
- Digest: [[digests/digest_7043217_dm_camera_by_entrance]]
- Numerator: `T2:chat_page_entrance_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send Message from chat page entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7043217.json`
- Field family: `camera_entrance_send`
- Aggregation: `uv/base_user`
- Meaning: chat page 入口带来的发送覆盖
- Key filters:
  - entrance bucket - 做入口归因
  - camera funnel stage - 区分入口曝光问题与后段转化问题
  - cohort cuts - 看不同人群入口偏好差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Message from chat upload entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043217
- Digest: [[digests/digest_7043217_dm_camera_by_entrance]]
- Numerator: `T2:chat_page_upload_entrance_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send message from chat page upload entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7043217.json`
- Key filters:
  - entrance bucket - 做入口归因
  - camera funnel stage - 区分入口曝光问题与后段转化问题
  - cohort cuts - 看不同人群入口偏好差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Message from inbox entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043217
- Digest: [[digests/digest_7043217_dm_camera_by_entrance]]
- Numerator: `T2:inbox_camera_entrance_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send Message from inbox entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7043217.json`
- Field family: `camera_entrance_send`
- Aggregation: `uv/base_user`
- Meaning: inbox 入口带来的发送覆盖
- Key filters:
  - entrance bucket - 做入口归因
  - camera funnel stage - 区分入口曝光问题与后段转化问题
  - cohort cuts - 看不同人群入口偏好差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Message from main posting entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043217
- Digest: [[digests/digest_7043217_dm_camera_by_entrance]]
- Numerator: `T2:main_posting_camera_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send Message from main posting entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7043217.json`
- Field family: `camera_entrance_send`
- Aggregation: `uv/base_user`
- Meaning: main posting 入口带来的发送覆盖
- Key filters:
  - entrance bucket - 做入口归因
  - camera funnel stage - 区分入口曝光问题与后段转化问题
  - cohort cuts - 看不同人群入口偏好差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Message from try effect entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043217
- Digest: [[digests/digest_7043217_dm_camera_by_entrance]]
- Numerator: `T2:try_effect_entrance_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send Message from try effect entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7043217.json`
- Key filters:
  - entrance bucket - 做入口归因
  - camera funnel stage - 区分入口曝光问题与后段转化问题
  - cohort cuts - 看不同人群入口偏好差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Message from video detail entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043217
- Digest: [[digests/digest_7043217_dm_camera_by_entrance]]
- Numerator: `T2:video_detail_entrance_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send Message from video detail entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7043217.json`
- Field family: `camera_entrance_send`
- Aggregation: `uv/base_user`
- Meaning: video detail 入口带来的发送覆盖
- Key filters:
  - entrance bucket - 做入口归因
  - camera funnel stage - 区分入口曝光问题与后段转化问题
  - cohort cuts - 看不同人群入口偏好差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->
