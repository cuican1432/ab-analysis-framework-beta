# Metrics By Group | Inbox element metrics uid

group_id: 7032341
canonical_name: Inbox element metrics uid
tags: metric-group, dm
wiki_digests: [[digests/digest_7032341_inbox_element_metrics_uid]]
wiki_matrices: [[digests/event_metric_matrix_7032341_inbox_element_metrics_uid]]

## Metrics

- base_user
  - metric_id: `3417596`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_3417596.md`
- Enter_inbox_user/U
  - metric_id: `3417597`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_enter_inbox_user_u__id_3417597.md`
- Enter_inbox_pv/U
  - metric_id: `3417598`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_enter_inbox_pv_u__id_3417598.md`
- inbox_story_show_user/dau
  - metric_id: `3417599`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_story_show_user_dau__id_3417599.md`
- inbox_story_show_pv/dau
  - metric_id: `3417600`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_story_show_pv_dau__id_3417600.md`
- inbox_story_click_user/dau
  - metric_id: `3417601`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_story_click_user_dau__id_3417601.md`
- inbox_story_click_pv/dau
  - metric_id: `3417602`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_story_click_pv_dau__id_3417602.md`
- inbox_story_click_user/show_user
  - metric_id: `3417603`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_story_click_user_show_user__id_3417603.md`
- inbox_story_click_pv/show_pv
  - metric_id: `3417604`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_story_click_pv_show_pv__id_3417604.md`
- inbox_activity_show_user/dau
  - metric_id: `3417605`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_activity_show_user_dau__id_3417605.md`
- inbox_activity_show_pv/dau
  - metric_id: `3417606`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_activity_show_pv_dau__id_3417606.md`
- inbox_activity_click_user/dau
  - metric_id: `3417607`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_activity_click_user_dau__id_3417607.md`
- inbox_activity_click_pv/dau
  - metric_id: `3417608`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_activity_click_pv_dau__id_3417608.md`
- inbox_activity_click_user/show_user
  - metric_id: `3417609`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_activity_click_user_show_user__id_3417609.md`
- inbox_activity_click_pv/show_pv
  - metric_id: `3417610`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_activity_click_pv_show_pv__id_3417610.md`
- inbox_followers_show_user/dau
  - metric_id: `3417611`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_followers_show_user_dau__id_3417611.md`
- inbox_followers_show_pv/dau
  - metric_id: `3417612`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_followers_show_pv_dau__id_3417612.md`
- inbox_followers_click_user/dau
  - metric_id: `3417613`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_followers_click_user_dau__id_3417613.md`
- inbox_followers_click_pv/dau
  - metric_id: `3417614`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_followers_click_pv_dau__id_3417614.md`
- inbox_followers_click_user/show_user
  - metric_id: `3417615`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_followers_click_user_show_user__id_3417615.md`
- inbox_followers_click_pv/show_pv
  - metric_id: `3417616`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_followers_click_pv_show_pv__id_3417616.md`
- inbox_concats_show_user/dau
  - metric_id: `3417617`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_concats_show_user_dau__id_3417617.md`
- inbox_concats_show_pv/dau
  - metric_id: `3417618`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_concats_show_pv_dau__id_3417618.md`
- inbox_concats_click_user/dau
  - metric_id: `3417619`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_concats_click_user_dau__id_3417619.md`
- inbox_concats_click_pv/dau
  - metric_id: `3417620`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_concats_click_pv_dau__id_3417620.md`
- inbox_concats_click_user/show_user
  - metric_id: `3417621`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_concats_click_user_show_user__id_3417621.md`
- inbox_concats_click_pv/show_pv
  - metric_id: `3417622`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_concats_click_pv_show_pv__id_3417622.md`
- inbox_recommend_show_user/dau
  - metric_id: `3417623`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_recommend_show_user_dau__id_3417623.md`
- inbox_recommend_show_pv/dau
  - metric_id: `3417624`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_recommend_show_pv_dau__id_3417624.md`
- inbox_recommend_click_user/dau
  - metric_id: `3417625`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_recommend_click_user_dau__id_3417625.md`
- inbox_recommend_click_pv/dau
  - metric_id: `3417626`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_recommend_click_pv_dau__id_3417626.md`
- inbox_recommend_click_user/show_user
  - metric_id: `3417627`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_recommend_click_user_show_user__id_3417627.md`
- inbox_recommend_click_pv/show_pv
  - metric_id: `3417628`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_recommend_click_pv_show_pv__id_3417628.md`
- inbox_system_show_user/dau
  - metric_id: `3417629`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_system_show_user_dau__id_3417629.md`
- inbox_system_show_pv/dau
  - metric_id: `3417630`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_system_show_pv_dau__id_3417630.md`
- inbox_system_click_user/dau
  - metric_id: `3417631`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_system_click_user_dau__id_3417631.md`
- inbox_system_click_pv/dau
  - metric_id: `3417632`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_system_click_pv_dau__id_3417632.md`
- inbox_system_click_user/show_user
  - metric_id: `3417633`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_system_click_user_show_user__id_3417633.md`
- inbox_system_click_pv/show_pv
  - metric_id: `3417634`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_system_click_pv_show_pv__id_3417634.md`
- inbox_dm_show_user/dau
  - metric_id: `3417635`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_dm_show_user_dau__id_3417635.md`
- inbox_dm_show_pv/dau
  - metric_id: `3417636`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_dm_show_pv_dau__id_3417636.md`
- inbox_dm_click_user/dau
  - metric_id: `3417637`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_dm_click_user_dau__id_3417637.md`
- inbox_dm_click_pv/dau
  - metric_id: `3417638`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_dm_click_pv_dau__id_3417638.md`
- inbox_dm_click_user/show_user
  - metric_id: `3417639`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_dm_click_user_show_user__id_3417639.md`
- inbox_dm_click_pv/show_pv
  - metric_id: `3417640`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_dm_click_pv_show_pv__id_3417640.md`
- Inbox
  - metric_id: `3417645`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox__id_3417645.md`

## Auto Definitions (Excerpt)

### Metric: base_user (3417596)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Enter_inbox_pv/U (3417598)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:enter_inbox_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: enter inbox count per user
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Enter_inbox_user/U (3417597)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:enter_inbox_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: enter inbox penetration
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox (3417645)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_skylight_click_cnt` (type: `pv`)
- Denominator: `T1:inbox_skylight_show_cnt` (type: `pv`)
- Description: inbox_skylight_click_pv/inbox_skylight_show_pv
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_activity_click_pv/dau (3417608)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_activity_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox activity click count per user
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_activity_click_pv/show_pv (3417610)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_activity_click_cnt` (type: `pv`)
- Denominator: `T1:inbox_activity_show_cnt` (type: `pv`)
- Description: inbox_activity_click_pv/show_pv
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: pv / pv
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_activity_click_user/dau (3417607)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_activity_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox activity click penetration
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_activity_click_user/show_user (3417609)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_activity_click_cnt` (type: `uv`)
- Denominator: `T1:inbox_activity_show_cnt` (type: `uv`)
- Description: inbox_activity_click_user/show_user
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: uv / uv
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_activity_show_pv/dau (3417606)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_activity_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox activity show count per user
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_activity_show_user/dau (3417605)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_activity_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox activity show penetration
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_concats_click_pv/dau (3417620)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_contacts_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox concats click count per user
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_concats_click_pv/show_pv (3417622)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_contacts_click_cnt` (type: `pv`)
- Denominator: `T1:inbox_contacts_show_cnt` (type: `pv`)
- Description: inbox_concats_click_pv/show_pv
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: pv / pv
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_concats_click_user/dau (3417619)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_contacts_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox concats click penetration
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_concats_click_user/show_user (3417621)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_contacts_click_cnt` (type: `uv`)
- Denominator: `T1:inbox_contacts_show_cnt` (type: `uv`)
- Description: inbox_concats_click_user/show_user
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: uv / uv
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_concats_show_pv/dau (3417618)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_contacts_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox concats show count per user
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_concats_show_user/dau (3417617)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_contacts_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox concats show penetration
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_dm_click_pv/dau (3417638)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_dm_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox dm click count per user
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_dm_click_pv/show_pv (3417640)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_dm_click_cnt` (type: `pv`)
- Denominator: `T1:inbox_dm_show_cnt` (type: `pv`)
- Description: inbox_dm_click_pv/show_pv
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: pv / pv
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_dm_click_user/dau (3417637)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_dm_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox dm click penetration
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_dm_click_user/show_user (3417639)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_dm_click_cnt` (type: `uv`)
- Denominator: `T1:inbox_dm_show_cnt` (type: `uv`)
- Description: inbox_dm_click_user/show_user
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: uv / uv
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_dm_show_pv/dau (3417636)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_dm_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox dm show count per user
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_dm_show_user/dau (3417635)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_dm_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox dm show penetration
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_followers_click_pv/dau (3417614)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_followers_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox followers click count per user
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_followers_click_pv/show_pv (3417616)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_followers_click_cnt` (type: `pv`)
- Denominator: `T1:inbox_followers_show_cnt` (type: `pv`)
- Description: inbox_followers_click_pv/show_pv
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: pv / pv
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_followers_click_user/dau (3417613)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_followers_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox followers click penetration
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_followers_click_user/show_user (3417615)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_followers_click_cnt` (type: `uv`)
- Denominator: `T1:inbox_followers_show_cnt` (type: `uv`)
- Description: inbox_followers_click_user/show_user
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: uv / uv
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_followers_show_pv/dau (3417612)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_followers_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox followers show count per user
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_followers_show_user/dau (3417611)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_followers_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox followers show penetration
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_recommend_click_pv/dau (3417626)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_recommend_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox recommend click count per user
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_recommend_click_pv/show_pv (3417628)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032341
- Digest: [[digests/digest_7032341_inbox_element_metrics_uid]]
- Numerator: `T1:inbox_recommend_click_cnt` (type: `pv`)
- Denominator: `T1:inbox_recommend_show_cnt` (type: `pv`)
- Description: inbox_recommend_click_pv/show_pv
- Provenance: `raw/libra/libra_metric_group_7032341.json`
- Aggregation: pv / pv
- Key filters:
  - `enter_from = notification_page` - 约束 DM / activity / followers / contacts / recommend / system / skylight 分支
  - `event = enter_homepage_message` - 锁定 inbox 入口
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox element uid metrics are confirmed at user-level inbox surface aggregate table level.
  - User-side Dorado task discovery confirms this uid group is backed by:

<!-- AUTO-GENERATED:metric_fields:end -->

> truncated: 16 more metrics omitted from the auto excerpt.
