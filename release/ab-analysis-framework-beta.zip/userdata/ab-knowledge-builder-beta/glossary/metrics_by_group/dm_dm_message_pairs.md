# Metrics By Group | [DM] DM Message Pairs

group_id: 7048542
canonical_name: [DM] DM Message Pairs
tags: metric-group, dm
wiki_digests: [[digests/digest_7048542_dm_message_pairs]]
wiki_matrices: [[digests/event_metric_matrix_7048542_dm_message_pairs]]

## Metrics

- Private Chat MUF Send or Like Pair/User
  - metric_id: `1262932`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_muf_send_or_like_pair_user__id_1262932.md`
- Group Chat MUF Send or Like Pair/User
  - metric_id: `1262933`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_muf_send_or_like_pair_user__id_1262933.md`
- IM MUF Send or Like Pair/User
  - metric_id: `1262934`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_im_muf_send_or_like_pair_user__id_1262934.md`

## Auto Definitions (Excerpt)

### Metric: Group Chat MUF Send or Like Pair/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7048542
- Digest: [[digests/digest_7048542_dm_message_pairs]]
- Numerator: `T1:send_or_like_muf_message_by_group_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Group Chat MUF Send or Like Pair/User
- Provenance: `raw/libra/libra_metric_group_7048542.json`
- Aggregation: pv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-tmp-dm-social-im-group-chat-muf-pair-1d]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: IM MUF Send or Like Pair/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7048542
- Digest: [[digests/digest_7048542_dm_message_pairs]]
- Numerator: `T1:send_or_like_muf_message_private_and_group_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: IM MUF Send or Like Pair/User
- Provenance: `raw/libra/libra_metric_group_7048542.json`
- Aggregation: pv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-tmp-dm-social-im-group-chat-muf-pair-1d]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat MUF Send or Like Pair/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7048542
- Digest: [[digests/digest_7048542_dm_message_pairs]]
- Numerator: `T1:send_or_like_muf_message_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Same as Key Project-DM: Social MUF Send or Like Message Pair/User
- Provenance: `raw/libra/libra_metric_group_7048542.json`
- Aggregation: pv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-tmp-dm-social-im-group-chat-muf-pair-1d]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->
