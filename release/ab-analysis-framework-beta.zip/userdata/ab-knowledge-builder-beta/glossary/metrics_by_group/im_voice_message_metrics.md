# Metrics By Group | [IM] Voice Message Metrics

group_id: 7054071
canonical_name: [IM] Voice Message Metrics
tags: metric-group, dm
wiki_digests: [[digests/digest_7054071_dm_voice_message]]
wiki_matrices: [[digests/event_metric_matrix_7054071_dm_voice_message]]

## Metrics

- base_user
  - metric_id: `2780376`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_2780376.md`
- Send Voice Message pv/au
  - metric_id: `2780377`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_voice_message_pv_au__id_2780377.md`
- Send Voice Message uv/au
  - metric_id: `2780378`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_voice_message_uv_au__id_2780378.md`
- Start Record Voice Message pv/au
  - metric_id: `2780379`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_start_record_voice_message_pv_au__id_2780379.md`
- Start Record Voice Message uv/au
  - metric_id: `2780380`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_start_record_voice_message_uv_au__id_2780380.md`
- UV Send/Record CTR
  - metric_id: `2780381`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_uv_send_record_ctr__id_2780381.md`
- Show Voice Message Entrance pv/au
  - metric_id: `2780382`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_show_voice_message_entrance_pv_au__id_2780382.md`
- Show Voice Message Entrance uv/au
  - metric_id: `2780383`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_show_voice_message_entrance_uv_au__id_2780383.md`
- UV Record/Show CTR
  - metric_id: `2780384`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_uv_record_show_ctr__id_2780384.md`
- Play Voice Message pv/au
  - metric_id: `2780385`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_play_voice_message_pv_au__id_2780385.md`
- Play Voice Message uv/au
  - metric_id: `2780386`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_play_voice_message_uv_au__id_2780386.md`
- Send Private Voice Message pv/au
  - metric_id: `2780387`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_private_voice_message_pv_au__id_2780387.md`
- Send Private Voice Message uv/au
  - metric_id: `2780388`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_private_voice_message_uv_au__id_2780388.md`
- Send Group Voice Message pv/au
  - metric_id: `2780389`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_group_voice_message_pv_au__id_2780389.md`
- Send Group Voice Message uv/au
  - metric_id: `2780390`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_group_voice_message_uv_au__id_2780390.md`
- Voice Message duration/user
  - metric_id: `2780391`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_voice_message_duration_user__id_2780391.md`
- Voice Message duration/message
  - metric_id: `2780392`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_voice_message_duration_message__id_2780392.md`
- Cancel Voice Message pv/au
  - metric_id: `2780393`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cancel_voice_message_pv_au__id_2780393.md`
- Cancel Voice Message uv/au
  - metric_id: `2780394`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cancel_voice_message_uv_au__id_2780394.md`
- Cancel/Record Proportion pv/pv
  - metric_id: `2780395`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cancel_record_proportion_pv_pv__id_2780395.md`
- Play Voice Message in Entry pv/au
  - metric_id: `2780396`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_play_voice_message_in_entry_pv_au__id_2780396.md`
- Play Voice Message in Entry uv/au
  - metric_id: `2780397`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_play_voice_message_in_entry_uv_au__id_2780397.md`
- Play in Entry/Record Proportion pv/pv
  - metric_id: `2780398`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_play_in_entry_record_proportion_pv_pv__id_2780398.md`
- Finish Playing in Entry/Play in Entry Proportion pv/pv
  - metric_id: `2780399`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_finish_playing_in_entry_play_in_entry_proportion_pv_pv__id_2780399.md`
- Finish Playing Voice Message in Entry pv/au
  - metric_id: `2780400`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_finish_playing_voice_message_in_entry_pv_au__id_2780400.md`
- Finish Playing Voice Message in Entry uv/au
  - metric_id: `2780401`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_finish_playing_voice_message_in_entry_uv_au__id_2780401.md`
- Show Voice Message pv/au
  - metric_id: `2780402`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_show_voice_message_pv_au__id_2780402.md`
- Show Voice Message uv/au
  - metric_id: `2780403`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_show_voice_message_uv_au__id_2780403.md`
- Play/Show Voice Message CTR uv/uv
  - metric_id: `2780404`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_play_show_voice_message_ctr_uv_uv__id_2780404.md`
- Finish Playing Voice Message pv/au
  - metric_id: `2780405`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_finish_playing_voice_message_pv_au__id_2780405.md`
- Finish Playing Voice Message uv/au
  - metric_id: `2780406`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_finish_playing_voice_message_uv_au__id_2780406.md`
- Finish Playing/Play Voice Message Proportion pv/pv
  - metric_id: `2780407`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_finish_playing_play_voice_message_proportion_pv_pv__id_2780407.md`

## Auto Definitions (Excerpt)

### Metric: base_user (2780376)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cancel/Record Proportion pv/pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:cancel_record_voice_message_cnt` (type: `pv`)
- Denominator: `T1:record_voice_message_cnt` (type: `pv`)
- Description: proportion that cancel sending to recording voice message
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cancel Voice Message pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:cancel_record_voice_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: counts that cancel voice message
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Field family: `voice_record_funnel`
- Aggregation: `pv/base_user`
- Meaning: 人均取消录制量
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cancel Voice Message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:cancel_record_voice_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: users that cancel voice message
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Finish Playing in Entry/Play in Entry Proportion pv/pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_play_entry_finish_cnt` (type: `pv`)
- Denominator: `T1:voice_message_play_entry_cnt` (type: `pv`)
- Description: proportion that finish playing in entry to playing in entry
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Finish Playing/Play Voice Message Proportion pv/pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_play_finish_cnt` (type: `pv`)
- Denominator: `T1:voice_message_play_cnt` (type: `pv`)
- Description: proportion that finish playing to playing voice messages
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Finish Playing Voice Message in Entry pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_play_entry_finish_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: counts that finish playing voice message
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Finish Playing Voice Message in Entry uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_play_entry_finish_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: users that finish playing voice message
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Finish Playing Voice Message pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_play_finish_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: counts that finish playing voice messages
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Field family: `voice_play_consumption`
- Aggregation: `pv/base_user`
- Meaning: 人均语音播完量
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Finish Playing Voice Message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_play_finish_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: users that finish playing voice messages
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Play in Entry/Record Proportion pv/pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_play_entry_cnt` (type: `pv`)
- Denominator: `T1:record_voice_message_cnt` (type: `pv`)
- Description: proportion that playing in entry to recording voice message
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Play/Show Voice Message CTR uv/uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_play_cnt` (type: `uv`)
- Denominator: `T1:voice_message_show_cnt` (type: `uv`)
- Description: UV proportion of playing voice message to showing voice message
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Play Voice Message in Entry pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_play_entry_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: counts that play voice message in entry
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Play Voice Message in Entry uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_play_entry_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: users that play voice message in entry
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Play Voice Message pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_play_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Volume of voice message played
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Field family: `voice_play_consumption`
- Aggregation: `pv/base_user`
- Meaning: 人均语音播放量
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Play Voice Message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_play_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Users that played voice messages
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Group Voice Message pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:group_chat_send_voice_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Volume of voice messages sent to group chats
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Group Voice Message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:group_chat_send_voice_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Users that send voice messages to group chats
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Private Voice Message pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:private_chat_send_voice_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Volume of voice messages sent to private chats
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Private Voice Message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:private_chat_send_voice_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Users that send voice messages to private chats
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Voice Message pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:send_voice_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Volume of voice messages sent
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Field family: `voice_send_completion`
- Aggregation: `pv/base_user`
- Meaning: 人均语音发送量
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Voice Message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:send_voice_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Users that sent voice messages
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Show Voice Message Entrance pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_entrance_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Volume of voice message entrance shown
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Field family: `voice_entrance_exposure`
- Aggregation: `pv/base_user`
- Meaning: 语音入口曝光强度
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Show Voice Message Entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_entrance_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Users that see the voice message entrance
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Show Voice Message pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: counts that show voice message
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Show Voice Message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:voice_message_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: users that show voice message
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Start Record Voice Message pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:record_voice_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Volume of voice message that began recordings
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Field family: `voice_record_funnel`
- Aggregation: `pv/base_user`
- Meaning: 人均语音录制启动量
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Start Record Voice Message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:record_voice_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Users that begin to record a voice message
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: UV Record/Show CTR
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:record_voice_message_cnt` (type: `uv`)
- Denominator: `T1:voice_message_entrance_show_cnt` (type: `uv`)
- Description: UV Proportion of users that record after seeing the voice message entrance
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Field family: `voice_record_funnel`
- Aggregation: `uv/uv`
- Meaning: 入口曝光到录制启动的转化
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: UV Send/Record CTR
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054071
- Digest: [[digests/digest_7054071_dm_voice_message]]
- Numerator: `T1:send_voice_message_cnt` (type: `uv`)
- Denominator: `T1:record_voice_message_cnt` (type: `uv`)
- Description: UV Proportion of users that send voice message after they record
- Provenance: `raw/libra/libra_metric_group_7054071.json`
- Field family: `voice_record_funnel`
- Aggregation: `uv/uv`
- Meaning: 录制到成功发送的转化
- Key filters:
  - `message_type = voice_message` - 约束 voice send-side 分支
  - `chat_type` - 区分 private / group 语音发送
  - funnel stage - 区分 show / record / cancel / play / finish
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-app-abtest-social-im-voice-message-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

> truncated: 2 more metrics omitted from the auto excerpt.
