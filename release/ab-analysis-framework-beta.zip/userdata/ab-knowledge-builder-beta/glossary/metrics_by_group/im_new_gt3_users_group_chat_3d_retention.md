# Metrics By Group | [IM] New gt3-users Group Chat 3d Retention

group_id: 7056674
canonical_name: [IM] New gt3-users Group Chat 3d Retention
tags: metric-group, dm
wiki_digests: [[digests/digest_7056674_dm_group_chat_3d_retention_new_gt3_users]]
wiki_matrices: [[digests/event_metric_matrix_7056674_dm_group_chat_3d_retention_new_gt3_users]]

## Metrics

- base_user
  - metric_id: `2780338`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_2780338.md`
- 3d retention
  - metric_id: `2780339`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_3d_retention__id_2780339.md`
- Share panel main 3d retention
  - metric_id: `2780340`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_panel_main_3d_retention__id_2780340.md`
- Share panel create group 3d retention
  - metric_id: `2780341`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_panel_create_group_3d_retention__id_2780341.md`
- Inbox (top left) 3d retention
  - metric_id: `2780342`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_top_left_3d_retention__id_2780342.md`
- Inbox (multi-mention) 3d retention
  - metric_id: `2780343`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_multi_mention_3d_retention__id_2780343.md`
- Inbox (multi-link) 3d retention
  - metric_id: `2780344`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_multi_link_3d_retention__id_2780344.md`
- Inbox (cluster) 3d retention
  - metric_id: `2780345`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_cluster_3d_retention__id_2780345.md`
- Private Chat 3d retention
  - metric_id: `2780346`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_3d_retention__id_2780346.md`
- Live 3d retention
  - metric_id: `2780347`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_live_3d_retention__id_2780347.md`
- AI group shot 3d retention
  - metric_id: `2780348`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_ai_group_shot_3d_retention__id_2780348.md`
- Others
  - metric_id: `2780349`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_others__id_2780349.md`

## Auto Definitions (Excerpt)

### Metric: 3d retention (2780339)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7056674
- Digest: [[digests/digest_7056674_dm_group_chat_3d_retention_new_gt3_users]]
- Numerator: `T5:new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T5:new_group_chat` (type: `pv`)
- Description: 3d retention
- Provenance: `raw/libra/libra_metric_group_7056674.json`
- Field family: `group_chat_retention_3d_gt3_core`
- Aggregation: `pv/pv`
- Meaning: 高价值新建群 cohort 在 3d 窗口后的留存率
- Key filters:
  - `3d` - 指定早期留存窗口
  - `new gt3-users` - 将 cohort 限定为高价值新建群用户
  - creation-source prefix - 比较不同建群来源质量
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-im-new-gt3-users-group-chat-retention-3d-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: AI group shot 3d retention (2780348)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7056674
- Digest: [[digests/digest_7056674_dm_group_chat_3d_retention_new_gt3_users]]
- Numerator: `T5:ai_group_shot_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T5:ai_group_shot_new_group_chat` (type: `pv`)
- Provenance: `raw/libra/libra_metric_group_7056674.json`
- Key filters:
  - `3d` - 指定早期留存窗口
  - `new gt3-users` - 将 cohort 限定为高价值新建群用户
  - creation-source prefix - 比较不同建群来源质量
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-im-new-gt3-users-group-chat-retention-3d-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: base_user (2780338)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7056674
- Digest: [[digests/digest_7056674_dm_group_chat_3d_retention_new_gt3_users]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7056674.json`
- Key filters:
  - `3d` - 指定早期留存窗口
  - `new gt3-users` - 将 cohort 限定为高价值新建群用户
  - creation-source prefix - 比较不同建群来源质量
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-im-new-gt3-users-group-chat-retention-3d-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox (cluster) 3d retention (2780345)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7056674
- Digest: [[digests/digest_7056674_dm_group_chat_3d_retention_new_gt3_users]]
- Numerator: `T5:inbox_cluster_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T5:inbox_cluster_new_group_chat` (type: `pv`)
- Provenance: `raw/libra/libra_metric_group_7056674.json`
- Key filters:
  - `3d` - 指定早期留存窗口
  - `new gt3-users` - 将 cohort 限定为高价值新建群用户
  - creation-source prefix - 比较不同建群来源质量
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-im-new-gt3-users-group-chat-retention-3d-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox (multi-link) 3d retention (2780344)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7056674
- Digest: [[digests/digest_7056674_dm_group_chat_3d_retention_new_gt3_users]]
- Numerator: `T5:inbox_multi_link_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T5:inbox_multi_link_new_group_chat` (type: `pv`)
- Provenance: `raw/libra/libra_metric_group_7056674.json`
- Key filters:
  - `3d` - 指定早期留存窗口
  - `new gt3-users` - 将 cohort 限定为高价值新建群用户
  - creation-source prefix - 比较不同建群来源质量
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-im-new-gt3-users-group-chat-retention-3d-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox (multi-mention) 3d retention (2780343)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7056674
- Digest: [[digests/digest_7056674_dm_group_chat_3d_retention_new_gt3_users]]
- Numerator: `T5:inbox_multi_mention_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T5:inbox_multi_mention_new_group_chat` (type: `pv`)
- Provenance: `raw/libra/libra_metric_group_7056674.json`
- Key filters:
  - `3d` - 指定早期留存窗口
  - `new gt3-users` - 将 cohort 限定为高价值新建群用户
  - creation-source prefix - 比较不同建群来源质量
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-im-new-gt3-users-group-chat-retention-3d-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox (top left) 3d retention (2780342)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7056674
- Digest: [[digests/digest_7056674_dm_group_chat_3d_retention_new_gt3_users]]
- Numerator: `T5:inbox_top_left_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T5:inbox_top_left_new_group_chat` (type: `pv`)
- Provenance: `raw/libra/libra_metric_group_7056674.json`
- Field family: `group_chat_retention_3d_gt3_source_quality`
- Aggregation: `pv/pv`
- Meaning: inbox top-left 来源在高价值 cohort 下的 3d 留存率
- Key filters:
  - `3d` - 指定早期留存窗口
  - `new gt3-users` - 将 cohort 限定为高价值新建群用户
  - creation-source prefix - 比较不同建群来源质量
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-im-new-gt3-users-group-chat-retention-3d-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Live 3d retention (2780347)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7056674
- Digest: [[digests/digest_7056674_dm_group_chat_3d_retention_new_gt3_users]]
- Numerator: `T5:live_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T5:live_new_group_chat` (type: `pv`)
- Provenance: `raw/libra/libra_metric_group_7056674.json`
- Field family: `group_chat_retention_3d_gt3_source_quality`
- Aggregation: `pv/pv`
- Meaning: live 来源在高价值 cohort 下的 3d 留存率
- Key filters:
  - `3d` - 指定早期留存窗口
  - `new gt3-users` - 将 cohort 限定为高价值新建群用户
  - creation-source prefix - 比较不同建群来源质量
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-im-new-gt3-users-group-chat-retention-3d-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Others (2780349)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7056674
- Digest: [[digests/digest_7056674_dm_group_chat_3d_retention_new_gt3_users]]
- Numerator: `T5:other_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T5:other_new_group_chat` (type: `pv`)
- Description: As long as not in above categories
- Provenance: `raw/libra/libra_metric_group_7056674.json`
- Key filters:
  - `3d` - 指定早期留存窗口
  - `new gt3-users` - 将 cohort 限定为高价值新建群用户
  - creation-source prefix - 比较不同建群来源质量
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-im-new-gt3-users-group-chat-retention-3d-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat 3d retention (2780346)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7056674
- Digest: [[digests/digest_7056674_dm_group_chat_3d_retention_new_gt3_users]]
- Numerator: `T5:private_chat_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T5:private_chat_new_group_chat` (type: `pv`)
- Provenance: `raw/libra/libra_metric_group_7056674.json`
- Field family: `group_chat_retention_3d_gt3_source_quality`
- Aggregation: `pv/pv`
- Meaning: private-chat 来源在高价值 cohort 下的 3d 留存率
- Key filters:
  - `3d` - 指定早期留存窗口
  - `new gt3-users` - 将 cohort 限定为高价值新建群用户
  - creation-source prefix - 比较不同建群来源质量
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-im-new-gt3-users-group-chat-retention-3d-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Share panel create group 3d retention (2780341)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7056674
- Digest: [[digests/digest_7056674_dm_group_chat_3d_retention_new_gt3_users]]
- Numerator: `T5:share_panel_create_group_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T5:share_panel_create_group_new_group_chat` (type: `pv`)
- Description: Share panel: create group button
- Provenance: `raw/libra/libra_metric_group_7056674.json`
- Field family: `group_chat_retention_3d_gt3_source_quality`
- Aggregation: `pv/pv`
- Meaning: share panel create-group 来源在高价值 cohort 下的 3d 留存率
- Key filters:
  - `3d` - 指定早期留存窗口
  - `new gt3-users` - 将 cohort 限定为高价值新建群用户
  - creation-source prefix - 比较不同建群来源质量
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-im-new-gt3-users-group-chat-retention-3d-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Share panel main 3d retention (2780340)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7056674
- Digest: [[digests/digest_7056674_dm_group_chat_3d_retention_new_gt3_users]]
- Numerator: `T5:new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T5:share_panel_main_new_group_chat` (type: `pv`)
- Description: Share panel: create group and share (normal)
- Provenance: `raw/libra/libra_metric_group_7056674.json`
- Field family: `group_chat_retention_3d_gt3_source_quality`
- Aggregation: `pv/pv`
- Meaning: 主 share panel 来源在高价值 cohort 下的 3d 留存率
- Key filters:
  - `3d` - 指定早期留存窗口
  - `new gt3-users` - 将 cohort 限定为高价值新建群用户
  - creation-source prefix - 比较不同建群来源质量
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-im-new-gt3-users-group-chat-retention-3d-di]]

<!-- AUTO-GENERATED:metric_fields:end -->
