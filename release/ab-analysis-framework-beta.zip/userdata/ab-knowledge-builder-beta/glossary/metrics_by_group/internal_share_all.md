# Metrics By Group | Internal Share All

group_id: 7050036
canonical_name: Internal Share All
tags: metric-group, dm
wiki_digests: [[digests/digest_7050036_internal_share_all]]
wiki_matrices: [[digests/event_metric_matrix_7050036_internal_share_all]]

## Metrics

- base_user
  - metric_id: `3121941`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_3121941.md`
- share_show_user_cnt/user
  - metric_id: `3121942`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_show_user_cnt_user__id_3121942.md`
- share_show_user_days/days
  - metric_id: `3121943`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_show_user_days_days__id_3121943.md`
- internal_share_all_cnt/user
  - metric_id: `3121944`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_all_cnt_user__id_3121944.md`
- internal_share_all_days/days
  - metric_id: `3121945`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_all_days_days__id_3121945.md`
- internal_share_all_cnt/share_show_user_cnt
  - metric_id: `3121946`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_all_cnt_share_show_user_cnt__id_3121946.md`
- share_show_video_user_cnt/user
  - metric_id: `3121947`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_show_video_user_cnt_user__id_3121947.md`
- internal_share_video_cnt/user
  - metric_id: `3121948`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_video_cnt_user__id_3121948.md`
- internal_share_video_cnt/share_show_video_user_cnt
  - metric_id: `3121949`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_video_cnt_share_show_video_user_cnt__id_3121949.md`
- share_show_comment_user_cnt/user
  - metric_id: `3121950`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_show_comment_user_cnt_user__id_3121950.md`
- internal_share_comment_cnt/user
  - metric_id: `3121951`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_comment_cnt_user__id_3121951.md`
- internal_share_comment_cnt/share_show_comment_user_cnt
  - metric_id: `3121952`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_comment_cnt_share_show_comment_user_cnt__id_3121952.md`
- share_show_live_user_cnt/user
  - metric_id: `3121953`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_show_live_user_cnt_user__id_3121953.md`
- internal_share_live_cnt/user
  - metric_id: `3121954`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_live_cnt_user__id_3121954.md`
- internal_share_live_cnt/share_show_live_user_cnt
  - metric_id: `3121955`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_live_cnt_share_show_live_user_cnt__id_3121955.md`
- share_show_profile_user_cnt/user
  - metric_id: `3121956`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_show_profile_user_cnt_user__id_3121956.md`
- internal_share_profile_cnt/user
  - metric_id: `3121957`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_profile_cnt_user__id_3121957.md`
- internal_share_profile_cnt/share_show_profile_user_cnt
  - metric_id: `3121958`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_profile_cnt_share_show_profile_user_cnt__id_3121958.md`
- share_show_other_user_cnt/user
  - metric_id: `3121959`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_show_other_user_cnt_user__id_3121959.md`
- internal_share_other_cnt/user
  - metric_id: `3121960`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_other_cnt_user__id_3121960.md`
- internal_share_other_cnt/share_show_other_user_cnt
  - metric_id: `3121961`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_other_cnt_share_show_other_user_cnt__id_3121961.md`
- internal_share_all_uv/share_show_user_uv
  - metric_id: `3121962`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_all_uv_share_show_user_uv__id_3121962.md`
- share_show_video_user_uv/user
  - metric_id: `3121963`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_show_video_user_uv_user__id_3121963.md`
- internal_share_video_uv/user
  - metric_id: `3121964`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_video_uv_user__id_3121964.md`
- internal_share_video_uv/share_show_video_user_uv
  - metric_id: `3121965`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_video_uv_share_show_video_user_uv__id_3121965.md`
- share_show_comment_user_uv/user
  - metric_id: `3121966`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_show_comment_user_uv_user__id_3121966.md`
- internal_share_comment_uv/user
  - metric_id: `3121967`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_comment_uv_user__id_3121967.md`
- internal_share_comment_uv/share_show_comment_user_uv
  - metric_id: `3121968`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_comment_uv_share_show_comment_user_uv__id_3121968.md`
- share_show_live_user_uv/user
  - metric_id: `3121969`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_show_live_user_uv_user__id_3121969.md`
- internal_share_live_uv/user
  - metric_id: `3121970`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_live_uv_user__id_3121970.md`
- internal_share_live_uv/share_show_live_user_uv
  - metric_id: `3121971`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_live_uv_share_show_live_user_uv__id_3121971.md`
- share_show_profile_user_uv/user
  - metric_id: `3121972`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_show_profile_user_uv_user__id_3121972.md`
- internal_share_profile_uv/user
  - metric_id: `3121973`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_profile_uv_user__id_3121973.md`
- internal_share_profile_uv/share_show_profile_user_uv
  - metric_id: `3121974`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_profile_uv_share_show_profile_user_uv__id_3121974.md`
- share_show_other_user_uv/user
  - metric_id: `3121975`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_show_other_user_uv_user__id_3121975.md`
- internal_share_other_uv/user
  - metric_id: `3121976`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_other_uv_user__id_3121976.md`
- internal_share_other_uv/share_show_other_user_uv
  - metric_id: `3121977`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_other_uv_share_show_other_user_uv__id_3121977.md`

## Auto Definitions (Excerpt)

### Metric: base_user (3121941)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Key filters:
  - 分享 stage - 区分曝光与发送
  - chat destination - 识别明确流向聊天的 subset
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_all_cnt/share_show_user_cnt
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_all_cnt` (type: `pv`)
- Denominator: `T4:share_show_user_cnt` (type: `pv`)
- Description: 站内分享CTR | internal_share_all_cnt/share_show_user_cnt
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: pv / pv
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `metric_type = conversion` - share send / share_show ratio
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - `internal_share_all` 仍是 umbrella aggregate family，尚未映射到唯一 raw event contract。
  - 这类比值/转化指标依赖 broad share exposure 与 send family 的 aggregate tables，不应误读成单一 DM event。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_all_cnt/user (3121944)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_all_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均站内分享次数 | internal_share_all_cnt/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: pv / base_user
- Key filters:
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - `internal_share_all` 仍是 umbrella aggregate family，尚未映射到唯一 raw event contract。
  - 可确认的 DM raw-event 证据主要是 `share_video_to_chat` subset，不能外推为整个 umbrella。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_all_days/days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_all_cnt` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_days`)
- Description: 站内分享渗透 | internal_share_all_days/days
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: action_days / base_days
- Key filters:
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - `internal_share_all` 仍是 umbrella aggregate family，尚未映射到唯一 raw event contract。
  - 可确认的 DM raw-event 证据主要是 `share_video_to_chat` subset，不能外推为整个 umbrella。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_all_uv/share_show_user_uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_all_cnt` (type: `uv`)
- Denominator: `T4:share_show_user_cnt` (type: `uv`)
- Description: 站内分享uv_CTR | internal_share_all_uv/share_show_user_uv
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: uv / uv
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `metric_type = conversion` - share send / share_show ratio
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - `internal_share_all` 仍是 umbrella aggregate family，尚未映射到唯一 raw event contract。
  - 这类比值/转化指标依赖 broad share exposure 与 send family 的 aggregate tables，不应误读成单一 DM event。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_comment_cnt/share_show_comment_user_cnt
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_comment_cnt` (type: `pv`)
- Denominator: `T4:share_show_comment_user_cnt` (type: `pv`)
- Description: 站内分享评论CTR | internal_share_comment_cnt/share_show_comment_user_cnt
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: pv / pv
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `metric_type = conversion` - share send / share_show ratio
  - `content_type = comment` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_comment_cnt/user (3121951)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_comment_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均站内分享评论次数 | share_show_comment_user_cnt/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: pv / base_user
- Key filters:
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `content_type = comment` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_comment_uv/share_show_comment_user_uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_comment_cnt` (type: `uv`)
- Denominator: `T4:share_show_comment_user_cnt` (type: `uv`)
- Description: 评论站内分享uv_CTR | internal_share_comment_uv/share_show_comment_user_uv
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: uv / uv
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `metric_type = conversion` - share send / share_show ratio
  - `content_type = comment` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_comment_uv/user (3121967)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_comment_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 评论站内分享uv渗透率｜internal_share_comment_uv/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: uv / base_user
- Key filters:
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `content_type = comment` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_live_cnt/share_show_live_user_cnt
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_live_cnt` (type: `pv`)
- Denominator: `T4:share_show_live_user_cnt` (type: `pv`)
- Description: 站内分享直播CTR | internal_share_live_cnt/share_show_live_user_cnt
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: pv / pv
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `metric_type = conversion` - share send / share_show ratio
  - `content_type = live` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_live_cnt/user (3121954)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_live_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均站内分享直播次数 | internal_share_live_cnt/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: pv / base_user
- Key filters:
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `content_type = live` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_live_uv/share_show_live_user_uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_live_cnt` (type: `uv`)
- Denominator: `T4:share_show_live_user_cnt` (type: `uv`)
- Description: 直播站内分享uv_CTR | internal_share_live_uv/share_show_live_user_uv
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: uv / uv
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `metric_type = conversion` - share send / share_show ratio
  - `content_type = live` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_live_uv/user (3121970)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_live_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 直播站内分享uv渗透率｜internal_share_live_uv/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: uv / base_user
- Key filters:
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `content_type = live` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_other_cnt/share_show_other_user_cnt
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_other_for_libra_cnt` (type: `pv`)
- Denominator: `T4:share_show_other_user_for_libra_cnt` (type: `pv`)
- Description: 站内分享其他CTR | internal_share_other_cnt/share_show_other_user_cnt
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: pv / pv
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `metric_type = conversion` - share send / share_show ratio
  - `content_type = other` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_other_cnt/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_other_for_libra_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均站内分享其他次数 | internal_share_other_cnt/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: pv / base_user
- Key filters:
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `content_type = other` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_other_uv/share_show_other_user_uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_other_for_libra_cnt` (type: `uv`)
- Denominator: `T4:share_show_other_user_for_libra_cnt` (type: `uv`)
- Description: 评论站内分享uv_CTR | internal_share_other_uv/share_show_other_user_uv
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: uv / uv
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `metric_type = conversion` - share send / share_show ratio
  - `content_type = other` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_other_uv/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_other_for_libra_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 评论站内分享uv渗透率｜internal_share_other_uv/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: uv / base_user
- Key filters:
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `content_type = other` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_profile_cnt/share_show_profile_user_cnt
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_profile_cnt` (type: `pv`)
- Denominator: `T4:share_show_profile_user_cnt` (type: `pv`)
- Description: 站内分享主页CTR | internal_share_profile_cnt/share_show_profile_user_cnt
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: pv / pv
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `metric_type = conversion` - share send / share_show ratio
  - `content_type = profile` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_profile_cnt/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_profile_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均站内分享主页次数 | internal_share_profile_cnt/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: pv / base_user
- Key filters:
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `content_type = profile` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_profile_uv/share_show_profile_user_uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_profile_cnt` (type: `uv`)
- Denominator: `T4:share_show_profile_user_cnt` (type: `uv`)
- Description: 主页站内分享uv_CTR | internal_share_profile_uv/share_show_profile_user_uv
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: uv / uv
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `metric_type = conversion` - share send / share_show ratio
  - `content_type = profile` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_profile_uv/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_profile_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 主页站内分享uv渗透率｜internal_share_profile_uv/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: uv / base_user
- Key filters:
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `content_type = profile` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_video_cnt/share_show_video_user_cnt
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_video_cnt` (type: `pv`)
- Denominator: `T4:share_show_video_user_cnt` (type: `pv`)
- Description: 站内分享视频CTR | internal_share_video_cnt/share_show_video_user_cnt
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: pv / pv
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `metric_type = conversion` - share send / share_show ratio
  - `content_type = video` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_video_cnt/user (3121948)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_video_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均站内分享视频次数 | internal_share_video_cnt/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: pv / base_user
- Key filters:
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `content_type = video` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_video_uv/share_show_video_user_uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_video_cnt` (type: `uv`)
- Denominator: `T4:share_show_video_user_cnt` (type: `uv`)
- Description: 视频站内分享uv_CTR | internal_share_video_uv/share_show_video_user_uv
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: uv / uv
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `metric_type = conversion` - share send / share_show ratio
  - `content_type = video` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_video_uv/user (3121964)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:internal_share_video_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 视频站内分享uv渗透率｜internal_share_video_uv/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: uv / base_user
- Key filters:
  - `share_stage = internal_share` - share send stage (umbrella aggregate)
  - `content_type = video` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: share_show_comment_user_cnt/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:share_show_comment_user_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均评论分享面板头像展现用户数 | internal_share_comment_cnt/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: pv / base_user
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `content_type = comment` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: share_show_comment_user_uv/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:share_show_comment_user_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 评论站内分享面板展示好友uv渗透率｜share_show_comment_user_uv/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: uv / base_user
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `content_type = comment` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: share_show_live_user_cnt/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:share_show_live_user_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均直播分享面板头像展现用户数 | share_show_live_user_cnt/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: pv / base_user
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `content_type = live` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: share_show_live_user_uv/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:share_show_live_user_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 直播站内分享面板展示好友uv渗透率｜share_show_live_user_uv/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: uv / base_user
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `content_type = live` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: share_show_other_user_cnt/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7050036
- Digest: [[digests/digest_7050036_internal_share_all]]
- Numerator: `T4:share_show_other_user_for_libra_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均其他分享面板头像展现用户数 | share_show_other_user_cnt/user
- Provenance: `raw/libra/libra_metric_group_7050036.json`
- Aggregation: pv / base_user
- Key filters:
  - `share_stage = share_show` - broad share exposure stage
  - `content_type = other` - typed share bucket
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - umbrella `internal_share_all` 仍未映射到唯一 raw event contract
  - 需补 broad share 面板和发送事件 schema，才能整体升级

<!-- AUTO-GENERATED:metric_fields:end -->

> truncated: 7 more metrics omitted from the auto excerpt.
