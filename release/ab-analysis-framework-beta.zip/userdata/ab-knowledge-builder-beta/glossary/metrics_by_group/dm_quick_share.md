# Metrics By Group | DM Quick Share

group_id: 7047592
canonical_name: DM Quick Share
tags: metric-group, dm
wiki_digests: [[digests/digest_7047592_dm_quick_share]]
wiki_matrices: [[digests/event_metric_matrix_7047592_dm_quick_share]]

## Metrics

- base_user
  - metric_id: `2188266`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_2188266.md`
- quick_share_btn_show_cnt/User
  - metric_id: `2188267`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_quick_share_btn_show_cnt_user__id_2188267.md`
- quick_share_btn_click_cnt/User
  - metric_id: `2188268`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_quick_share_btn_click_cnt_user__id_2188268.md`
- quick_share_btn_share_cnt/User
  - metric_id: `2188269`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_quick_share_btn_share_cnt_user__id_2188269.md`
- like_quick_share_btn_show_cnt/User
  - metric_id: `2188270`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_like_quick_share_btn_show_cnt_user__id_2188270.md`
- like_quick_share_btn_click_cnt/User
  - metric_id: `2188271`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_like_quick_share_btn_click_cnt_user__id_2188271.md`
- loop_quick_share_btn_show_cnt/User
  - metric_id: `2188272`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_loop_quick_share_btn_show_cnt_user__id_2188272.md`
- loop_quick_share_btn_click_cnt/User
  - metric_id: `2188273`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_loop_quick_share_btn_click_cnt_user__id_2188273.md`
- watch_quick_share_btn_show_cnt/User
  - metric_id: `2188274`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_watch_quick_share_btn_show_cnt_user__id_2188274.md`
- watch_quick_share_btn_click_cnt/User
  - metric_id: `2188275`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_watch_quick_share_btn_click_cnt_user__id_2188275.md`
- repost_quick_share_btn_show_cnt/User
  - metric_id: `2188276`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_repost_quick_share_btn_show_cnt_user__id_2188276.md`
- repost_quick_share_btn_click_cnt/User
  - metric_id: `2188277`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_repost_quick_share_btn_click_cnt_user__id_2188277.md`
- favourite_quick_share_btn_show_cnt/User
  - metric_id: `2188278`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_favourite_quick_share_btn_show_cnt_user__id_2188278.md`
- favourite_quick_share_btn_click_cnt/User
  - metric_id: `2188279`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_favourite_quick_share_btn_click_cnt_user__id_2188279.md`
- quick_share_btn_show_uv/User
  - metric_id: `2188280`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_quick_share_btn_show_uv_user__id_2188280.md`
- quick_share_btn_click_uv/User
  - metric_id: `2188281`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_quick_share_btn_click_uv_user__id_2188281.md`
- quick_share_btn_share_uv/User
  - metric_id: `2188282`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_quick_share_btn_share_uv_user__id_2188282.md`
- like_quick_share_btn_show_uv/User
  - metric_id: `2188283`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_like_quick_share_btn_show_uv_user__id_2188283.md`
- like_quick_share_btn_click_uv/User
  - metric_id: `2188284`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_like_quick_share_btn_click_uv_user__id_2188284.md`
- loop_quick_share_btn_show_uv/User
  - metric_id: `2188285`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_loop_quick_share_btn_show_uv_user__id_2188285.md`
- loop_quick_share_btn_click_uv/User
  - metric_id: `2188286`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_loop_quick_share_btn_click_uv_user__id_2188286.md`
- watch_quick_share_btn_show_uv/User
  - metric_id: `2188287`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_watch_quick_share_btn_show_uv_user__id_2188287.md`
- watch_quick_share_btn_click_uv/User
  - metric_id: `2188288`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_watch_quick_share_btn_click_uv_user__id_2188288.md`
- repost_quick_share_btn_show_uv/User
  - metric_id: `2188289`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_repost_quick_share_btn_show_uv_user__id_2188289.md`
- repost_quick_share_btn_click_uv/User
  - metric_id: `2188290`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_repost_quick_share_btn_click_uv_user__id_2188290.md`
- favourite_quick_share_btn_show_uv/User
  - metric_id: `2188291`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_favourite_quick_share_btn_show_uv_user__id_2188291.md`
- favourite_quick_share_btn_click_uv/User
  - metric_id: `2188292`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_favourite_quick_share_btn_click_uv_user__id_2188292.md`
- quick_share_btn_click_uv/quick_share_btn_show_uv
  - metric_id: `2188293`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_quick_share_btn_click_uv_quick_share_btn_show_uv__id_2188293.md`
- like_quick_share_btn_click_uv/like_quick_share_btn_show_uv
  - metric_id: `2188294`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_like_quick_share_btn_click_uv_like_quick_share_btn_show_uv__id_2188294.md`
- loop_quick_share_btn_click_uv/loop_quick_share_btn_show_uv
  - metric_id: `2188295`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_loop_quick_share_btn_click_uv_loop_quick_share_btn_show_uv__id_2188295.md`
- watch_quick_share_btn_click_uv/watch_quick_share_btn_show_uv
  - metric_id: `2188296`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_watch_quick_share_btn_click_uv_watch_quick_share_btn_show_uv__id_2188296.md`
- repost_quick_share_btn_click_uv/repost_quick_share_btn_show_uv
  - metric_id: `2188297`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_repost_quick_share_btn_click_uv_repost_quick_share_btn_show_uv__id_2188297.md`
- favourite_quick_share_btn_click_uv/favourite_quick_share_btn_show_uv
  - metric_id: `2188298`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_favourite_quick_share_btn_click_uv_favourite_quick_share_btn_show_uv__id_2188298.md`
- quick_share_btn_click_cnt/quick_share_btn_show_cnt
  - metric_id: `2188299`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_quick_share_btn_click_cnt_quick_share_btn_show_cnt__id_2188299.md`
- like_quick_share_btn_click_cnt/like_quick_share_btn_show_cnt
  - metric_id: `2188300`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_like_quick_share_btn_click_cnt_like_quick_share_btn_show_cnt__id_2188300.md`
- loop_quick_share_btn_click_cnt/loop_quick_share_btn_show_cnt
  - metric_id: `2188301`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_loop_quick_share_btn_click_cnt_loop_quick_share_btn_show_cnt__id_2188301.md`
- watch_quick_share_btn_click_cnt/watch_quick_share_btn_show_cnt
  - metric_id: `2188302`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_watch_quick_share_btn_click_cnt_watch_quick_share_btn_show_cnt__id_2188302.md`
- repost_quick_share_btn_click_cnt/repost_quick_share_btn_show_cnt
  - metric_id: `2188303`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_repost_quick_share_btn_click_cnt_repost_quick_share_btn_show_cnt__id_2188303.md`
- favourite_quick_share_btn_click_cnt/favourite_quick_share_btn_show_cnt
  - metric_id: `2188304`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_favourite_quick_share_btn_click_cnt_favourite_quick_share_btn_show_cnt__id_2188304.md`

## Auto Definitions (Excerpt)

### Metric: base_user (2188266)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: favourite_quick_share_btn_click_cnt/favourite_quick_share_btn_show_cnt
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:favourite_quick_share_btn_click_cnt` (type: `pv`)
- Denominator: `T2:favourite_quick_share_btn_show_cnt` (type: `pv`)
- Description: 收藏时机-快捷分享框pctr
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: pv / pv
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: favourite_quick_share_btn_click_cnt/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:favourite_quick_share_btn_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 收藏触发时机-人均快捷分享框点击次数
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: favourite_quick_share_btn_click_uv/favourite_quick_share_btn_show_uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:favourite_quick_share_btn_click_cnt` (type: `uv`)
- Denominator: `T2:favourite_quick_share_btn_show_cnt` (type: `uv`)
- Description: 收藏时机-快捷分享框uctr
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: uv / uv
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: favourite_quick_share_btn_click_uv/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:favourite_quick_share_btn_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 收藏触发时机-快捷分享框点击渗透
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: favourite_quick_share_btn_show_cnt/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:favourite_quick_share_btn_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 收藏触发时机-人均快捷分享框展示次数
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: favourite_quick_share_btn_show_uv/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:favourite_quick_share_btn_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 收藏触发时机-快捷分享框展示渗透
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: like_quick_share_btn_click_cnt/like_quick_share_btn_show_cnt
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:like_quick_share_btn_click_cnt` (type: `pv`)
- Denominator: `T2:like_quick_share_btn_show_cnt` (type: `pv`)
- Description: 点赞时机-快捷分享框pctr
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: pv / pv
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: like_quick_share_btn_click_cnt/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:like_quick_share_btn_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 点赞触发时机-人均快捷分享框点击次数
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: like_quick_share_btn_click_uv/like_quick_share_btn_show_uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:like_quick_share_btn_click_cnt` (type: `uv`)
- Denominator: `T2:like_quick_share_btn_show_cnt` (type: `uv`)
- Description: 点赞时机-快捷分享框uctr
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: uv / uv
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: like_quick_share_btn_click_uv/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:like_quick_share_btn_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 点赞触发时机-快捷分享框点击渗透
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: like_quick_share_btn_show_cnt/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:like_quick_share_btn_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 点赞触发时机-人均快捷分享框展示次数
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: like_quick_share_btn_show_uv/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:like_quick_share_btn_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 点赞触发时机-快捷分享框展示渗透
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: loop_quick_share_btn_click_cnt/loop_quick_share_btn_show_cnt
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:loop_quick_share_btn_click_cnt` (type: `pv`)
- Denominator: `T2:loop_quick_share_btn_show_cnt` (type: `pv`)
- Description: 完播时机-快捷分享框pctr
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: pv / pv
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: loop_quick_share_btn_click_cnt/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:loop_quick_share_btn_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 完播触发时机-人均快捷分享框点击次数
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: loop_quick_share_btn_click_uv/loop_quick_share_btn_show_uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:loop_quick_share_btn_click_cnt` (type: `uv`)
- Denominator: `T2:loop_quick_share_btn_show_cnt` (type: `uv`)
- Description: 完播时机-快捷分享框uctr
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: uv / uv
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: loop_quick_share_btn_click_uv/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:loop_quick_share_btn_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 完播触发时机-快捷分享框点击渗透
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: loop_quick_share_btn_show_cnt/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:loop_quick_share_btn_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 完播触发时机-人均快捷分享框展示次数
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: loop_quick_share_btn_show_uv/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:loop_quick_share_btn_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 完播触发时机-快捷分享框展示渗透
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: quick_share_btn_click_cnt/quick_share_btn_show_cnt
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:quick_share_btn_click_cnt` (type: `pv`)
- Denominator: `T2:quick_share_btn_show_cnt` (type: `pv`)
- Description: 快捷分享框pctr
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: pv / pv
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: quick_share_btn_click_cnt/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:quick_share_btn_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均快捷分享框点击次数
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: quick_share_btn_click_uv/quick_share_btn_show_uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:quick_share_btn_click_cnt` (type: `uv`)
- Denominator: `T2:quick_share_btn_show_cnt` (type: `uv`)
- Description: 快捷分享框uctr
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: uv / uv
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: quick_share_btn_click_uv/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:quick_share_btn_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 快捷分享框点击渗透
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: quick_share_btn_share_cnt/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:quick_share_btn_share_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均快捷分享框分享次数
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: quick_share_btn_share_uv/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:quick_share_btn_share_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 快捷分享框分享渗透
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: quick_share_btn_show_cnt/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:quick_share_btn_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均快捷分享框展示次数
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: quick_share_btn_show_uv/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:quick_share_btn_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 快捷分享框展示渗透
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: repost_quick_share_btn_click_cnt/repost_quick_share_btn_show_cnt
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:repost_quick_share_btn_click_cnt` (type: `pv`)
- Denominator: `T2:repost_quick_share_btn_show_cnt` (type: `pv`)
- Description: repost时机-快捷分享框pctr
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: pv / pv
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: repost_quick_share_btn_click_cnt/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:repost_quick_share_btn_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: repost触发时机-人均快捷分享框点击次数
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: repost_quick_share_btn_click_uv/repost_quick_share_btn_show_uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7047592
- Digest: [[digests/digest_7047592_dm_quick_share]]
- Numerator: `T2:repost_quick_share_btn_click_cnt` (type: `uv`)
- Denominator: `T2:repost_quick_share_btn_show_cnt` (type: `uv`)
- Description: repost时机-快捷分享框uctr
- Provenance: `raw/libra/libra_metric_group_7047592.json`
- Aggregation: uv / uv
- Key filters:
  - `action_type = show/click`, `platform is null` - 约束快捷按钮曝光 / 点击
  - `panel_source = quick_share_button`, `platform in chat/chat_head/chat_list/chat_forward` - 约束快捷分享发送到 DM 侧 chat target
  - shared-feed neighbors - 旁证 broader share ecosystem，不作为 core direct mapping
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-device-df]]
  - [[tables/table_musically-mid-social-interaction-activeness-bitmap-user-df]]
- Boundary notes:
  - Quick-share button / panel aggregates are confirmed at share aggregate table level.
  - Producer SQL now proves the core button funnel:

<!-- AUTO-GENERATED:metric_fields:end -->

> truncated: 9 more metrics omitted from the auto excerpt.
