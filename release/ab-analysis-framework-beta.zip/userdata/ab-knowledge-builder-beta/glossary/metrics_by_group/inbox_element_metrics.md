# Metrics By Group | Inbox Element Metrics

group_id: 7019895
canonical_name: Inbox Element Metrics
tags: metric-group, dm
wiki_digests: [[digests/digest_7019895_inbox_element_metrics]]
wiki_matrices: [[digests/event_metric_matrix_7019895_inbox_element_metrics]]

## Metrics

- Enter_inbox_user/U
  - metric_id: `3212635`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_enter_inbox_user_u__id_3212635.md`
- Enter_inbox_pv/U
  - metric_id: `3212636`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_enter_inbox_pv_u__id_3212636.md`
- inbox_story_show_user/dau
  - metric_id: `3212637`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_story_show_user_dau__id_3212637.md`
- inbox_story_show_pv/dau
  - metric_id: `3212638`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_story_show_pv_dau__id_3212638.md`
- inbox_story_click_user/dau
  - metric_id: `3212639`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_story_click_user_dau__id_3212639.md`
- inbox_story_click_pv/dau
  - metric_id: `3212640`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_story_click_pv_dau__id_3212640.md`
- inbox_activity_show_user/dau
  - metric_id: `3212641`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_activity_show_user_dau__id_3212641.md`
- inbox_activity_show_pv/dau
  - metric_id: `3212642`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_activity_show_pv_dau__id_3212642.md`
- inbox_activity_click_user/dau
  - metric_id: `3212643`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_activity_click_user_dau__id_3212643.md`
- inbox_activity_click_pv/dau
  - metric_id: `3212644`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_activity_click_pv_dau__id_3212644.md`
- inbox_followers_show_user/dau
  - metric_id: `3212645`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_followers_show_user_dau__id_3212645.md`
- inbox_followers_show_pv/dau
  - metric_id: `3212646`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_followers_show_pv_dau__id_3212646.md`
- inbox_followers_click_user/dau
  - metric_id: `3212647`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_followers_click_user_dau__id_3212647.md`
- inbox_followers_click_pv/dau
  - metric_id: `3212648`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_followers_click_pv_dau__id_3212648.md`
- inbox_concats_show_user/dau
  - metric_id: `3212649`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_concats_show_user_dau__id_3212649.md`
- inbox_concats_show_pv/dau
  - metric_id: `3212650`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_concats_show_pv_dau__id_3212650.md`
- inbox_concats_click_user/dau
  - metric_id: `3212651`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_concats_click_user_dau__id_3212651.md`
- inbox_concats_click_pv/dau
  - metric_id: `3212652`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_concats_click_pv_dau__id_3212652.md`
- inbox_request_show_user/dau
  - metric_id: `3212653`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_request_show_user_dau__id_3212653.md`
- inbox_request_show_pv/dau
  - metric_id: `3212654`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_request_show_pv_dau__id_3212654.md`
- inbox_request_click_user/dau
  - metric_id: `3212655`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_request_click_user_dau__id_3212655.md`
- inbox_request_click_pv/dau
  - metric_id: `3212656`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_request_click_pv_dau__id_3212656.md`
- inbox_recommend_show_user/dau
  - metric_id: `3212657`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_recommend_show_user_dau__id_3212657.md`
- inbox_recommend_show_pv/dau
  - metric_id: `3212658`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_recommend_show_pv_dau__id_3212658.md`
- inbox_recommend_click_user/dau
  - metric_id: `3212659`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_recommend_click_user_dau__id_3212659.md`
- inbox_recommend_click_pv/dau
  - metric_id: `3212660`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_recommend_click_pv_dau__id_3212660.md`
- inbox_system_show_user/dau
  - metric_id: `3212661`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_system_show_user_dau__id_3212661.md`
- inbox_system_show_pv/dau
  - metric_id: `3212662`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_system_show_pv_dau__id_3212662.md`
- inbox_system_click_user/dau
  - metric_id: `3212663`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_system_click_user_dau__id_3212663.md`
- inbox_system_click_pv/dau
  - metric_id: `3212664`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_system_click_pv_dau__id_3212664.md`
- inbox_dm_show_user/dau
  - metric_id: `3212665`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_dm_show_user_dau__id_3212665.md`
- inbox_dm_show_pv/dau
  - metric_id: `3212666`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_dm_show_pv_dau__id_3212666.md`
- inbox_dm_click_user/dau
  - metric_id: `3212667`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_dm_click_user_dau__id_3212667.md`
- inbox_dm_click_pv/dau
  - metric_id: `3212668`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_dm_click_pv_dau__id_3212668.md`
- inbox_story_click_user/show_user
  - metric_id: `3212669`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_story_click_user_show_user__id_3212669.md`
- inbox_story_click_pv/show_pv
  - metric_id: `3212670`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_story_click_pv_show_pv__id_3212670.md`
- inbox_activity_click_user/show_user
  - metric_id: `3212671`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_activity_click_user_show_user__id_3212671.md`
- inbox_activity_click_pv/show_pv
  - metric_id: `3212672`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_activity_click_pv_show_pv__id_3212672.md`
- inbox_followers_click_user/show_user
  - metric_id: `3212673`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_followers_click_user_show_user__id_3212673.md`
- inbox_followers_click_pv/show_pv
  - metric_id: `3212674`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_followers_click_pv_show_pv__id_3212674.md`
- inbox_concats_click_user/show_user
  - metric_id: `3212675`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_concats_click_user_show_user__id_3212675.md`
- inbox_concats_click_pv/show_pv
  - metric_id: `3212676`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_concats_click_pv_show_pv__id_3212676.md`
- inbox_request_click_user/show_user
  - metric_id: `3212677`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_request_click_user_show_user__id_3212677.md`
- inbox_request_click_pv/show_pv
  - metric_id: `3212678`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_request_click_pv_show_pv__id_3212678.md`
- inbox_recommend_click_user/show_user
  - metric_id: `3212679`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_recommend_click_user_show_user__id_3212679.md`
- inbox_recommend_click_pv/show_pv
  - metric_id: `3212680`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_recommend_click_pv_show_pv__id_3212680.md`
- inbox_system_click_user/show_user
  - metric_id: `3212681`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_system_click_user_show_user__id_3212681.md`
- inbox_system_click_pv/show_pv
  - metric_id: `3212682`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_system_click_pv_show_pv__id_3212682.md`
- inbox_dm_click_user/show_user
  - metric_id: `3212683`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_dm_click_user_show_user__id_3212683.md`
- inbox_dm_click_pv/show_pv
  - metric_id: `3212684`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_dm_click_pv_show_pv__id_3212684.md`
- Inbox
  - metric_id: `3212689`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox__id_3212689.md`

## Auto Definitions (Excerpt)

### Metric: Enter_inbox_pv/U (3212636)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:enter_inbox_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: enter inbox count per user
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Enter_inbox_user/U (3212635)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:enter_inbox_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: enter inbox penetration
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox (3212689)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_skylight_click_cnt` (type: `pv`)
- Denominator: `T1:inbox_skylight_show_cnt` (type: `pv`)
- Description: (inbox_skylight_click_cnt) pv / (inbox_skylight_show_cnt) pv
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_activity_click_pv/dau (3212644)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_activity_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox activity click count per user
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_activity_click_pv/show_pv (3212672)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_activity_click_cnt` (type: `pv`)
- Denominator: `T1:inbox_activity_show_cnt` (type: `pv`)
- Description: inbox_activity_click_pv/show_pv
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: pv / pv
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_activity_click_user/dau (3212643)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_activity_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox activity click penetration
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_activity_click_user/show_user (3212671)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_activity_click_cnt` (type: `uv`)
- Denominator: `T1:inbox_activity_show_cnt` (type: `uv`)
- Description: inbox_activity_click_user/show_user
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: uv / uv
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_activity_show_pv/dau (3212642)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_activity_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox activity show count per user
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_activity_show_user/dau (3212641)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_activity_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox activity show penetration
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_concats_click_pv/dau (3212652)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_contacts_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox concats click count per user
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_concats_click_pv/show_pv (3212676)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_contacts_click_cnt` (type: `pv`)
- Denominator: `T1:inbox_contacts_show_cnt` (type: `pv`)
- Description: inbox_concats_click_pv/show_pv
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: pv / pv
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_concats_click_user/dau (3212651)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_contacts_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox concats click penetration
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_concats_click_user/show_user (3212675)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_contacts_click_cnt` (type: `uv`)
- Denominator: `T1:inbox_contacts_show_cnt` (type: `uv`)
- Description: inbox_concats_click_user/show_user
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: uv / uv
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_concats_show_pv/dau (3212650)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_contacts_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox concats show count per user
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_concats_show_user/dau (3212649)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_contacts_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox concats show penetration
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_dm_click_pv/dau (3212668)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_dm_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox dm click count per user
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_dm_click_pv/show_pv (3212684)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_dm_click_cnt` (type: `pv`)
- Denominator: `T1:inbox_dm_show_cnt` (type: `pv`)
- Description: inbox_dm_click_pv/show_pv
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: pv / pv
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_dm_click_user/dau (3212667)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_dm_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox dm click penetration
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_dm_click_user/show_user (3212683)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_dm_click_cnt` (type: `uv`)
- Denominator: `T1:inbox_dm_show_cnt` (type: `uv`)
- Description: inbox_dm_click_user/show_user
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: uv / uv
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_dm_show_pv/dau (3212666)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_dm_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox dm show count per user
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_dm_show_user/dau (3212665)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_dm_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox dm show penetration
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_followers_click_pv/dau (3212648)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_followers_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox followers click count per user
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_followers_click_pv/show_pv (3212674)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_followers_click_cnt` (type: `pv`)
- Denominator: `T1:inbox_followers_show_cnt` (type: `pv`)
- Description: inbox_followers_click_pv/show_pv
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: pv / pv
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_followers_click_user/dau (3212647)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_followers_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox followers click penetration
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_followers_click_user/show_user (3212673)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_followers_click_cnt` (type: `uv`)
- Denominator: `T1:inbox_followers_show_cnt` (type: `uv`)
- Description: inbox_followers_click_user/show_user
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: uv / uv
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_followers_show_pv/dau (3212646)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_followers_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox followers show count per user
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_followers_show_user/dau (3212645)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_followers_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox followers show penetration
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_recommend_click_pv/dau (3212660)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_recommend_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox recommend click count per user
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: pv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_recommend_click_pv/show_pv (3212680)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_recommend_click_cnt` (type: `pv`)
- Denominator: `T1:inbox_recommend_show_cnt` (type: `pv`)
- Description: inbox_recommend_click_pv/show_pv
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: pv / pv
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: inbox_recommend_click_user/dau (3212659)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019895
- Digest: [[digests/digest_7019895_inbox_element_metrics]]
- Numerator: `T1:inbox_recommend_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox recommend click penetration
- Provenance: `raw/libra/libra_metric_group_7019895.json`
- Aggregation: uv / base_user
- Key filters:
  - `enter_from = notification_page` - 锁定 DM inbox 元素 show / click
  - `event = enter_homepage_message` - 锁定 inbox 入口次数
  - `action_type`, `cell_type` - 区分 activity / followers / recommend / system 子分支
  - `element`, `message` - 区分组件层和消息层
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
- Boundary notes:
  - Inbox element metrics are confirmed at device-level inbox surface aggregate table level.
  - `inbox_story_show/click` 子分支已独立提升到 raw-event-contract 层：[[events/event_story_show]], [[events/event_story_click]]

<!-- AUTO-GENERATED:metric_fields:end -->

> truncated: 21 more metrics omitted from the auto excerpt.
