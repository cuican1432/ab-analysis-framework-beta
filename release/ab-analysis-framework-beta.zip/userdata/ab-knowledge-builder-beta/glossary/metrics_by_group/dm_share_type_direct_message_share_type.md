# Metrics By Group | DM_Share_Type | direct message share type

group_id: 7046339
canonical_name: DM_Share_Type | direct message share type
tags: metric-group, dm
wiki_digests: [[digests/digest_7046339_dm_share_type]]
wiki_matrices: [[digests/event_metric_matrix_7046339_dm_share_type]]

## Metrics

- generalized_share_cnt/user
  - metric_id: `2188254`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_generalized_share_cnt_user__id_2188254.md`
- generalized_share_uv/user
  - metric_id: `2188255`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_generalized_share_uv_user__id_2188255.md`
- internal_share_all_uv/user
  - metric_id: `2188256`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_all_uv_user__id_2188256.md`
- internal_share_video_uv/user
  - metric_id: `2188257`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_video_uv_user__id_2188257.md`
- internal_share_comment_uv/user
  - metric_id: `2188258`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_comment_uv_user__id_2188258.md`
- internal_share_live_uv/user
  - metric_id: `2188259`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_live_uv_user__id_2188259.md`
- internal_share_page_uv/user
  - metric_id: `2188260`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_page_uv_user__id_2188260.md`
- internal_share_all_cnt/user
  - metric_id: `2188261`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_all_cnt_user__id_2188261.md`
- internal_share_video_cnt/user
  - metric_id: `2188262`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_video_cnt_user__id_2188262.md`
- internal_share_comment_cnt/user
  - metric_id: `2188263`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_comment_cnt_user__id_2188263.md`
- internal_share_live_cnt/user
  - metric_id: `2188264`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_live_cnt_user__id_2188264.md`
- internal_share_page_cnt/user
  - metric_id: `2188265`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_page_cnt_user__id_2188265.md`

## Auto Definitions (Excerpt)

### Metric: generalized_share_cnt/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046339
- Digest: [[digests/digest_7046339_dm_share_type]]
- Numerator: `T1:generalized_share_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 广义分享次数（站内分享视频+站外分享视频+Repost）
- Provenance: `raw/libra/libra_metric_group_7046339.json`
- Key filters:
  - `share_scope = generalized_share` - broader than internal share; includes external/repost
- Source tables (from digest):
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `generalized_share` 比 `internal_share_all` 更宽，除站内 share 外还包含 external share / repost。
  - `generalized_share` 的 external share / repost 上游事件边界仍未完全展开。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: generalized_share_uv/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046339
- Digest: [[digests/digest_7046339_dm_share_type]]
- Numerator: `T1:generalized_share_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 广义分享渗透（站内分享视频+站外分享视频+Repost）
- Provenance: `raw/libra/libra_metric_group_7046339.json`
- Key filters:
  - `share_scope = generalized_share` - broader than internal share; includes external/repost
- Source tables (from digest):
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `generalized_share` 比 `internal_share_all` 更宽，除站内 share 外还包含 external share / repost。
  - `generalized_share` 的 external share / repost 上游事件边界仍未完全展开。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_all_cnt/user (2188261)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046339
- Digest: [[digests/digest_7046339_dm_share_type]]
- Numerator: `T1:internal_share_all_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 总体站内分享次数
- Provenance: `raw/libra/libra_metric_group_7046339.json`
- Key filters:
  - `share_scope = internal_share_all` - umbrella internal share bucket
- Source tables (from digest):
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `internal_share_all` 是 umbrella aggregate，不等于单一 raw event contract。
  - 当前最强可复用 raw-event 证据仍是 `share_video_to_chat + content_type`，它只覆盖其中一个明确子集。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_all_uv/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046339
- Digest: [[digests/digest_7046339_dm_share_type]]
- Numerator: `T1:internal_share_all_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 总体站内分享渗透
- Provenance: `raw/libra/libra_metric_group_7046339.json`
- Key filters:
  - `share_scope = internal_share_all` - umbrella internal share bucket
- Source tables (from digest):
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `internal_share_all` 是 umbrella aggregate，不等于单一 raw event contract。
  - 当前最强可复用 raw-event 证据仍是 `share_video_to_chat + content_type`，它只覆盖其中一个明确子集。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_comment_cnt/user (2188263)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046339
- Digest: [[digests/digest_7046339_dm_share_type]]
- Numerator: `T1:internal_share_comment_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 站内分享评论次数
- Provenance: `raw/libra/libra_metric_group_7046339.json`
- Key filters:
  - `content_type = comment` - typed internal share bucket
  - `share_scope = internal_share` - typed internal-share branch
- Source tables (from digest):
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - typed bucket 已由 producer SQL 和 `content_type = video/comment/live/profile` 对齐确认。
  - `page` 在 producer SQL 侧实际更接近 `profile` 桶。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_comment_uv/user (2188258)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046339
- Digest: [[digests/digest_7046339_dm_share_type]]
- Numerator: `T1:internal_share_comment_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 站内分享评论渗透
- Provenance: `raw/libra/libra_metric_group_7046339.json`
- Key filters:
  - `content_type = comment` - typed internal share bucket
  - `share_scope = internal_share` - typed internal-share branch
- Source tables (from digest):
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - typed bucket 已由 producer SQL 和 `content_type = video/comment/live/profile` 对齐确认。
  - `page` 在 producer SQL 侧实际更接近 `profile` 桶。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_live_cnt/user (2188264)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046339
- Digest: [[digests/digest_7046339_dm_share_type]]
- Numerator: `T1:internal_share_live_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 站内分享直播次数
- Provenance: `raw/libra/libra_metric_group_7046339.json`
- Key filters:
  - `content_type = live` - typed internal share bucket
  - `share_scope = internal_share` - typed internal-share branch
- Source tables (from digest):
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - typed bucket 已由 producer SQL 和 `content_type = video/comment/live/profile` 对齐确认。
  - `page` 在 producer SQL 侧实际更接近 `profile` 桶。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_live_uv/user (2188259)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046339
- Digest: [[digests/digest_7046339_dm_share_type]]
- Numerator: `T1:internal_share_live_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 站内分享直播渗透
- Provenance: `raw/libra/libra_metric_group_7046339.json`
- Key filters:
  - `content_type = live` - typed internal share bucket
  - `share_scope = internal_share` - typed internal-share branch
- Source tables (from digest):
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - typed bucket 已由 producer SQL 和 `content_type = video/comment/live/profile` 对齐确认。
  - `page` 在 producer SQL 侧实际更接近 `profile` 桶。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_page_cnt/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046339
- Digest: [[digests/digest_7046339_dm_share_type]]
- Numerator: `T1:internal_share_page_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 站内分享个人页次数
- Provenance: `raw/libra/libra_metric_group_7046339.json`
- Key filters:
  - `content_type = profile` - typed internal share page/profile bucket
  - `share_scope = internal_share` - typed internal-share branch
- Source tables (from digest):
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - typed bucket 已由 producer SQL 和 `content_type = video/comment/live/profile` 对齐确认。
  - `page` 在 producer SQL 侧实际更接近 `profile` 桶。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_page_uv/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046339
- Digest: [[digests/digest_7046339_dm_share_type]]
- Numerator: `T1:internal_share_page_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 站内分享个人页渗透
- Provenance: `raw/libra/libra_metric_group_7046339.json`
- Key filters:
  - `content_type = profile` - typed internal share page/profile bucket
  - `share_scope = internal_share` - typed internal-share branch
- Source tables (from digest):
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - typed bucket 已由 producer SQL 和 `content_type = video/comment/live/profile` 对齐确认。
  - `page` 在 producer SQL 侧实际更接近 `profile` 桶。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_video_cnt/user (2188262)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046339
- Digest: [[digests/digest_7046339_dm_share_type]]
- Numerator: `T1:internal_share_video_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 站内分享视频次数
- Provenance: `raw/libra/libra_metric_group_7046339.json`
- Key filters:
  - `content_type = video` - typed internal share bucket
  - `share_scope = internal_share` - typed internal-share branch
- Source tables (from digest):
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - typed bucket 已由 producer SQL 和 `content_type = video/comment/live/profile` 对齐确认。
  - `page` 在 producer SQL 侧实际更接近 `profile` 桶。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: internal_share_video_uv/user (2188257)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046339
- Digest: [[digests/digest_7046339_dm_share_type]]
- Numerator: `T1:internal_share_video_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 站内分享视频渗透
- Provenance: `raw/libra/libra_metric_group_7046339.json`
- Key filters:
  - `content_type = video` - typed internal share bucket
  - `share_scope = internal_share` - typed internal-share branch
- Source tables (from digest):
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - typed bucket 已由 producer SQL 和 `content_type = video/comment/live/profile` 对齐确认。
  - `page` 在 producer SQL 侧实际更接近 `profile` 桶。

<!-- AUTO-GENERATED:metric_fields:end -->
