# Metrics By Group | TnS DM Private Sender Metrics - Conv Level

group_id: 7043978
canonical_name: TnS DM Private Sender Metrics - Conv Level
tags: metric-group, dm
wiki_digests: [[digests/digest_7043978_tns_dm_private_sender_metrics_conv_level]]
wiki_matrices: [[digests/event_metric_matrix_7043978_tns_dm_private_sender_metrics_conv_level]]

## Metrics

- ban_rate_conv
  - metric_id: `916536`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_ban_rate_conv__id_916536.md`
- notice_rate_conv
  - metric_id: `916537`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notice_rate_conv__id_916537.md`
- feedback_rate_conv
  - metric_id: `916538`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_rate_conv__id_916538.md`
- feedback_success_rate_conv
  - metric_id: `916539`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_success_rate_conv__id_916539.md`
- feedback_appeal_rate_conv
  - metric_id: `916540`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_appeal_rate_conv__id_916540.md`
- feedback_appeal_success_rate_conv
  - metric_id: `916541`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_appeal_success_rate_conv__id_916541.md`
- report_conv_cnt
  - metric_id: `916542`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_conv_cnt__id_916542.md`
- report_appeal_rate_conv
  - metric_id: `916543`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_appeal_rate_conv__id_916543.md`
- report_violate_rate_conv
  - metric_id: `916544`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_violate_rate_conv__id_916544.md`
- report_egregious_rate_conv
  - metric_id: `916545`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_egregious_rate_conv__id_916545.md`
- report_appeal_success_rate_conv
  - metric_id: `916546`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_appeal_success_rate_conv__id_916546.md`
- report_appeal_egregious_rate_conv
  - metric_id: `916547`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_appeal_egregious_rate_conv__id_916547.md`

## Auto Definitions (Excerpt)

### Metric: ban_rate_conv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043978
- Digest: [[digests/digest_7043978_tns_dm_private_sender_metrics_conv_level]]
- Numerator: `T1:ban_private_conv_cnt` (type: `pv`)
- Denominator: `T1:private_conv_cnt` (type: `pv`)
- Description: ban_rate_conv / conv_cnt
- Provenance: `raw/libra/libra_metric_group_7043978.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_appeal_rate_conv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043978
- Digest: [[digests/digest_7043978_tns_dm_private_sender_metrics_conv_level]]
- Numerator: `T1:feedback_appeal_private_conv_cnt` (type: `pv`)
- Denominator: `T1:feedback_private_conv_cnt` (type: `pv`)
- Description: feedback_appeal_rate_conv / conv_cnt
- Provenance: `raw/libra/libra_metric_group_7043978.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_appeal_success_rate_conv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043978
- Digest: [[digests/digest_7043978_tns_dm_private_sender_metrics_conv_level]]
- Numerator: `T1:feedback_appeal_success_group_conv_cnt` (type: `pv`)
- Denominator: `T1:feedback_appeal_private_conv_cnt` (type: `pv`)
- Description: feedback_appeal_success_rate_conv / conv_cnt
- Provenance: `raw/libra/libra_metric_group_7043978.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_rate_conv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043978
- Digest: [[digests/digest_7043978_tns_dm_private_sender_metrics_conv_level]]
- Numerator: `T1:feedback_private_conv_cnt` (type: `pv`)
- Denominator: `T1:ban_private_conv_cnt` (type: `pv`)
- Description: feedback_rate_conv / conv_cnt
- Provenance: `raw/libra/libra_metric_group_7043978.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_success_rate_conv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043978
- Digest: [[digests/digest_7043978_tns_dm_private_sender_metrics_conv_level]]
- Numerator: `T1:feedback_success_private_conv_cnt` (type: `pv`)
- Denominator: `T1:feedback_private_conv_cnt` (type: `pv`)
- Description: feedback_success_rate_conv / conv_cnt
- Provenance: `raw/libra/libra_metric_group_7043978.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: notice_rate_conv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043978
- Digest: [[digests/digest_7043978_tns_dm_private_sender_metrics_conv_level]]
- Numerator: `T1:notice_private_conv_cnt` (type: `pv`)
- Denominator: `T1:private_conv_cnt` (type: `pv`)
- Description: notice_rate_conv / conv_cnt
- Provenance: `raw/libra/libra_metric_group_7043978.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_appeal_egregious_rate_conv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043978
- Digest: [[digests/digest_7043978_tns_dm_private_sender_metrics_conv_level]]
- Numerator: `T1:report_appeal_egregious_private_conv_cnt` (type: `pv`)
- Denominator: `T1:report_appeal_private_conv_cnt` (type: `pv`)
- Description: report_appeal_egregious_rate_conv / conv_cnt
- Provenance: `raw/libra/libra_metric_group_7043978.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_appeal_rate_conv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043978
- Digest: [[digests/digest_7043978_tns_dm_private_sender_metrics_conv_level]]
- Numerator: `T1:report_appeal_private_conv_cnt` (type: `pv`)
- Denominator: `T1:report_private_msg_usr_cnt` (type: `pv`)
- Description: report_appeal_rate_conv / conv_cnt
- Provenance: `raw/libra/libra_metric_group_7043978.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_appeal_success_rate_conv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043978
- Digest: [[digests/digest_7043978_tns_dm_private_sender_metrics_conv_level]]
- Numerator: `T1:report_appeal_success_private_conv_cnt` (type: `pv`)
- Denominator: `T1:report_appeal_private_conv_cnt` (type: `pv`)
- Description: report_appeal_success_rate_conv / conv_cnt
- Provenance: `raw/libra/libra_metric_group_7043978.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_conv_cnt
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043978
- Digest: [[digests/digest_7043978_tns_dm_private_sender_metrics_conv_level]]
- Numerator: `T1:report_private_msg_usr_cnt` (type: `pv`)
- Denominator: `T1:private_conv_cnt` (type: `pv`)
- Description: report_conv_cnt
- Provenance: `raw/libra/libra_metric_group_7043978.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_egregious_rate_conv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043978
- Digest: [[digests/digest_7043978_tns_dm_private_sender_metrics_conv_level]]
- Numerator: `T1:report_egregious_private_conv_cnt` (type: `pv`)
- Denominator: `T1:report_private_msg_usr_cnt` (type: `pv`)
- Description: report_egregious_rate_conv / conv_cnt
- Provenance: `raw/libra/libra_metric_group_7043978.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_violate_rate_conv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043978
- Digest: [[digests/digest_7043978_tns_dm_private_sender_metrics_conv_level]]
- Numerator: `T1:report_violate_private_conv_cnt` (type: `pv`)
- Denominator: `T1:report_private_msg_usr_cnt` (type: `pv`)
- Description: report_violate_rate_conv / conv_cnt
- Provenance: `raw/libra/libra_metric_group_7043978.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->
