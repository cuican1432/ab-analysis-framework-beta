# Metrics By Group | [DM] DM by Msg Type

group_id: 7015262
canonical_name: [DM] DM by Msg Type
tags: metric-group, dm
wiki_digests: [[digests/digest_7015262_dm_by_msg_type]]
wiki_matrices: [[digests/event_metric_matrix_7015262_dm_by_msg_type]]

## Metrics

- User
  - metric_id: `3156321`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base-user__id_3156321.md`
- User
  - metric_id: `3156321`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_user__id_3156321.md`
- Send Text Days/Days
  - metric_id: `3156322`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_text_days_days__id_3156322.md`
- Send Text Days/User
  - metric_id: `3156323`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_text_days_user__id_3156323.md`
- Send Text/User
  - metric_id: `3156324`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_text_user__id_3156324.md`
- Send Emoji Days/Days
  - metric_id: `3156325`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_emoji_days_days__id_3156325.md`
- Send Emoji Days/User
  - metric_id: `3156326`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_emoji_days_user__id_3156326.md`
- Send Emoji/User
  - metric_id: `3156327`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_emoji_user__id_3156327.md`
- Send Text_emoji Days/Days
  - metric_id: `3156328`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_text_emoji_days_days__id_3156328.md`
- Send Text_emoji Days/User
  - metric_id: `3156329`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_text_emoji_days_user__id_3156329.md`
- Send Text_emoji/User
  - metric_id: `3156330`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_text_emoji_user__id_3156330.md`
- Send Share_video Days/Days
  - metric_id: `3156331`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_share_video_days_days__id_3156331.md`
- Send Share_video Days/User
  - metric_id: `3156332`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_share_video_days_user__id_3156332.md`
- Send Share_video/User
  - metric_id: `3156333`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_share_video_user__id_3156333.md`
- Send Share_comment Days/Days
  - metric_id: `3156334`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_share_comment_days_days__id_3156334.md`
- Send Share_comment Days/User
  - metric_id: `3156335`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_share_comment_days_user__id_3156335.md`
- Send Share_comment/User
  - metric_id: `3156336`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_share_comment_user__id_3156336.md`
- Send Share_live Days/Days
  - metric_id: `3156337`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_share_live_days_days__id_3156337.md`
- Send Share_live Days/User
  - metric_id: `3156338`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_share_live_days_user__id_3156338.md`
- Send Share_live/User
  - metric_id: `3156339`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_share_live_user__id_3156339.md`
- Send Sticker Days/Days
  - metric_id: `3156340`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_sticker_days_days__id_3156340.md`
- Send Sticker Days/User
  - metric_id: `3156341`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_sticker_days_user__id_3156341.md`
- Send Sticker/User
  - metric_id: `3156342`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_sticker_user__id_3156342.md`
- Send Voice_message Days/Days
  - metric_id: `3156343`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_voice_message_days_days__id_3156343.md`
- Send Voice_message Days/User
  - metric_id: `3156344`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_voice_message_days_user__id_3156344.md`
- Send Voice_message/User
  - metric_id: `3156345`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_voice_message_user__id_3156345.md`
- Send Camera Days/Days
  - metric_id: `3156346`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_camera_days_days__id_3156346.md`
- Send Camera Days/User
  - metric_id: `3156347`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_camera_days_user__id_3156347.md`
- Send Camera/User
  - metric_id: `3156348`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_camera_user__id_3156348.md`
- Send Share_profile Days/Days
  - metric_id: `3156349`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_share_profile_days_days__id_3156349.md`
- Send Share_profile Days/User
  - metric_id: `3156350`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_share_profile_days_user__id_3156350.md`
- Send Share_profile/User
  - metric_id: `3156351`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_share_profile_user__id_3156351.md`

## Auto Definitions (Excerpt)

### Metric: User (3156321)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = Text` - `text`
  - `message_type = Emoji` - `emoji`
  - `message_type = Text_emoji` - `text_emoji`
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Camera Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_camera_cnt` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send camera penetration
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type in {private_image, private_video, photo, video}` - camera bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Camera Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_camera_cnt` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send camera days per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type in {private_image, private_video, photo, video}` - camera bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Camera/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_camera_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send camera count per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type in {private_image, private_video, photo, video}` - camera bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Emoji Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_emoji_cnt` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send emoji penetration
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = emoji` - emoji bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Emoji Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_emoji_cnt` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send emoji days per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = emoji` - emoji bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Emoji/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_emoji_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send emoji count per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = emoji` - emoji bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Share_comment Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_share_comment_cnt` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send shared video penetration
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = share_comment` - share_comment bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Share_comment Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_share_comment_cnt` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send shared video days per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = share_comment` - share_comment bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Share_comment/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_share_comment_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send shared video count per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = share_comment` - share_comment bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Share_live Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_share_live_cnt` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send shared video penetration
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = share_live_highlight` - share_live bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Share_live Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_share_live_cnt` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send shared video days per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = share_live_highlight` - share_live bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Share_live/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_share_live_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send shared video count per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = share_live_highlight` - share_live bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Share_profile Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_page_cnt` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send share profile penetration
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type ~= page` - share_profile/page-like bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Share_profile Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_page_cnt` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send share profile days per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type ~= page` - share_profile/page-like bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Share_profile/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_page_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send share profile count per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type ~= page` - share_profile/page-like bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Share_video Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_share_video_cnt` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send shared video penetration
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = share_video` - share_video bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Share_video Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_share_video_cnt` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send shared video days per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = share_video` - share_video bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Share_video/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_share_video_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send shared video count per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = share_video` - share_video bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Sticker Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_all_sticker_cnt` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send sticker penetration
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = sticker` - sticker bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Sticker Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_all_sticker_cnt` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send sticker days per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = sticker` - sticker bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Sticker/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_all_sticker_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send sticker count per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = sticker` - sticker bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Text Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_text_cnt` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send text penetration
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = text` - text bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Text Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_text_cnt` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send text days per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = text` - text bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Text_emoji Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_text_emoji_cnt` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send text_emoji penetration
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = text` - text bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Text_emoji Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_text_emoji_cnt` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send text_emoji days per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = text` - text bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Text_emoji/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_text_emoji_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send text_emoji count per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = text` - text bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Text/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_text_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send text count per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = text` - text bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Voice_message Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_voice_message_cnt` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send voice message penetration
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = voice_message` - voice message bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Voice_message Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015262
- Digest: [[digests/digest_7015262_dm_by_msg_type]]
- Numerator: `T0:send_voice_message_cnt` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send voice message days per user
- Provenance: `raw/libra/libra_metric_group_7015262.json`
- Key filters:
  - `message_type = voice_message` - voice message bucket
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 各消息类型 bucket 与 ByteIO `message_type` 枚举值的精确对齐仍需补 canonical 参数页

<!-- AUTO-GENERATED:metric_fields:end -->

> truncated: 2 more metrics omitted from the auto excerpt.
