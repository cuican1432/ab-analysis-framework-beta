# Metrics By Group | [DM] DM Permission

group_id: 7042278
canonical_name: [DM] DM Permission
tags: metric-group, dm
wiki_digests: [[digests/digest_7042278_dm_permission]]
wiki_matrices: [[digests/event_metric_matrix_7042278_dm_permission]]

## Metrics

- base_user
  - metric_id: `763142`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_763142.md`
- on_ratio
  - metric_id: `763143`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_on_ratio__id_763143.md`
- off_ratio
  - metric_id: `763144`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_off_ratio__id_763144.md`
- unknown_ratio
  - metric_id: `763145`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_unknown_ratio__id_763145.md`
- everyone_ratio
  - metric_id: `763146`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_everyone_ratio__id_763146.md`
- suggested_friends_ratio
  - metric_id: `763147`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_suggested_friends_ratio__id_763147.md`
- friends_ratio
  - metric_id: `763148`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_friends_ratio__id_763148.md`
- no_one_ratio
  - metric_id: `763149`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_no_one_ratio__id_763149.md`
- disabled_ratio
  - metric_id: `763150`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_disabled_ratio__id_763150.md`
- on_to_off_user/user
  - metric_id: `763151`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_on_to_off_user_user__id_763151.md`
- unknown_to_off_user/user
  - metric_id: `763152`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_unknown_to_off_user_user__id_763152.md`
- off_to_on_user/user
  - metric_id: `763153`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_off_to_on_user_user__id_763153.md`
- unknown_to_on_uv/user
  - metric_id: `763154`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_unknown_to_on_uv_user__id_763154.md`

## Auto Definitions (Excerpt)

### Metric: base_user (763142)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7042278
- Digest: [[digests/digest_7042278_dm_permission]]
- Numerator: `user` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7042278.json`
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: disabled_ratio
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7042278
- Digest: [[digests/digest_7042278_dm_permission]]
- Numerator: `T1:permission_disable` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Proportion of users with Disabled permission
- Provenance: `raw/libra/libra_metric_group_7042278.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: everyone_ratio
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7042278
- Digest: [[digests/digest_7042278_dm_permission]]
- Numerator: `T1:permission_everyone` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Proportion of users with Everyone enabled
- Provenance: `raw/libra/libra_metric_group_7042278.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: friends_ratio
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7042278
- Digest: [[digests/digest_7042278_dm_permission]]
- Numerator: `T1:permission_friend` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Proportion of users with Friends permission
- Provenance: `raw/libra/libra_metric_group_7042278.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: no_one_ratio
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7042278
- Digest: [[digests/digest_7042278_dm_permission]]
- Numerator: `T1:permission_no_one` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Proportion of users with No_one permission
- Provenance: `raw/libra/libra_metric_group_7042278.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: off_ratio
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7042278
- Digest: [[digests/digest_7042278_dm_permission]]
- Numerator: `T1:permission_disable_or_no_one` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Proportion of users with DM permission disabled or set to no_one
- Provenance: `raw/libra/libra_metric_group_7042278.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: off_to_on_user/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7042278
- Digest: [[digests/digest_7042278_dm_permission]]
- Numerator: `T1:permission_off_to_on` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Number of users that opt from OFF to ON DM permissions
- Provenance: `raw/libra/libra_metric_group_7042278.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: on_ratio
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7042278
- Digest: [[digests/digest_7042278_dm_permission]]
- Numerator: `T1:permmission_enable` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Proportion of users with DM permission enabled (friends, suggested friends, everyone)
- Provenance: `raw/libra/libra_metric_group_7042278.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: on_to_off_user/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7042278
- Digest: [[digests/digest_7042278_dm_permission]]
- Numerator: `T1:permission_on_to_off` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Number of users that opt from ON to OFF DM permissions
- Provenance: `raw/libra/libra_metric_group_7042278.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: suggested_friends_ratio
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7042278
- Digest: [[digests/digest_7042278_dm_permission]]
- Numerator: `T1:permission_suggest_friend` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Proportion of users with Suggested Friends permission
- Provenance: `raw/libra/libra_metric_group_7042278.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: unknown_ratio
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7042278
- Digest: [[digests/digest_7042278_dm_permission]]
- Numerator: `T1:permission_unknown` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Proportion of users with unknown permission
- Provenance: `raw/libra/libra_metric_group_7042278.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: unknown_to_off_user/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7042278
- Digest: [[digests/digest_7042278_dm_permission]]
- Numerator: `T1:permission_unknown_to_off` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Number of users that opt from unknown to OFF DM permissions
- Provenance: `raw/libra/libra_metric_group_7042278.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: unknown_to_on_uv/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7042278
- Digest: [[digests/digest_7042278_dm_permission]]
- Numerator: `T1:permission_unknown_to_on` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Number of users that opt from unknown to ON DM permissions
- Provenance: `raw/libra/libra_metric_group_7042278.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->
