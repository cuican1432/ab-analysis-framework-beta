# Metrics By Group | [DM] DM by Link

group_id: 7027819
canonical_name: [DM] DM by Link
tags: metric-group, dm
wiki_digests: [[digests/digest_7027819_dm_by_link]]
wiki_matrices: [[digests/event_metric_matrix_7027819_dm_by_link]]

## Metrics

- User
  - metric_id: `2779920`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base-user__id_2779920.md`
- base_user
  - metric_id: `2779920`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_2779920.md`
- User
  - metric_id: `2779920`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_user__id_2779920.md`
- relation pairs cnt
  - metric_id: `2779921`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_relation_pairs_cnt__id_2779921.md`
- t+7 receiver send or receive message pairs/pairs cnt
  - metric_id: `2779922`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_t_7_receiver_send_or_receive_message_pairs_pairs_cnt__id_2779922.md`
- t+7 receiver send or reveive message users/receiver users
  - metric_id: `2779923`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_t_7_receiver_send_or_reveive_message_users_receiver_users__id_2779923.md`
- t+7 receiver share or be shared pairs/pairs cnt
  - metric_id: `2779924`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_t_7_receiver_share_or_be_shared_pairs_pairs_cnt__id_2779924.md`
- t+7 receiver share or be shared users/receiver users
  - metric_id: `2779925`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_t_7_receiver_share_or_be_shared_users_receiver_users__id_2779925.md`
- t+7 receiver send or receive message pv/receiver users
  - metric_id: `2779926`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_t_7_receiver_send_or_receive_message_pv_receiver_users__id_2779926.md`
- t+7 receiver share or be shared pv/receiver users
  - metric_id: `2779927`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_t_7_receiver_share_or_be_shared_pv_receiver_users__id_2779927.md`

## Auto Definitions (Excerpt)

### Metric: User (2779920)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7027819
- Digest: [[digests/digest_7027819_dm_by_link]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7027819.json`
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-link-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: base_user (2779920)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7027819
- Digest: [[digests/digest_7027819_dm_by_link]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7027819.json`
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-link-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: relation pairs cnt
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7027819
- Digest: [[digests/digest_7027819_dm_by_link]]
- Numerator: `T1:link_launch_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `-`)
- Description: relation pairs cnt
- Provenance: `raw/libra/libra_metric_group_7027819.json`
- Aggregation: pv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-link-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: t+7 receiver send or receive message pairs/pairs cnt
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7027819
- Digest: [[digests/digest_7027819_dm_by_link]]
- Numerator: `T1:link_launch_with_dm_7d_pair_cnt` (type: `pv`)
- Denominator: `T1:link_launch_pair_cnt` (type: `pv`)
- Description: t+7 receiver send or receive message pairs/pairs cnt
- Provenance: `raw/libra/libra_metric_group_7027819.json`
- Aggregation: pv / pv
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-link-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: t+7 receiver send or receive message pv/receiver users
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7027819
- Digest: [[digests/digest_7027819_dm_by_link]]
- Numerator: `T1:link_launch_with_dm_7d_cnt` (type: `pv`)
- Denominator: `T1:link_launch_pair_cnt` (type: `uv`)
- Description: t+7 receiver send or receive message pv/user
- Provenance: `raw/libra/libra_metric_group_7027819.json`
- Aggregation: pv / uv
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-link-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: t+7 receiver send or reveive message users/receiver users
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7027819
- Digest: [[digests/digest_7027819_dm_by_link]]
- Numerator: `T1:link_launch_with_dm_7d_pair_cnt` (type: `uv`)
- Denominator: `T1:link_launch_pair_cnt` (type: `uv`)
- Description: t+7 receiver send or reveive message users/receiver users
- Provenance: `raw/libra/libra_metric_group_7027819.json`
- Aggregation: uv / uv
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-link-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: t+7 receiver share or be shared pairs/pairs cnt
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7027819
- Digest: [[digests/digest_7027819_dm_by_link]]
- Numerator: `T1:link_launch_with_internal_video_share_7d_pair_cnt` (type: `pv`)
- Denominator: `T1:link_launch_pair_cnt` (type: `pv`)
- Description: t+7 receiver share or shared pairs/pairs cnt
- Provenance: `raw/libra/libra_metric_group_7027819.json`
- Aggregation: pv / pv
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-link-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: t+7 receiver share or be shared pv/receiver users
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7027819
- Digest: [[digests/digest_7027819_dm_by_link]]
- Numerator: `T1:link_launch_with_internal_video_share_7d_cnt` (type: `pv`)
- Denominator: `T1:link_launch_pair_cnt` (type: `uv`)
- Description: t+7 receiver share or be shared pv/user
- Provenance: `raw/libra/libra_metric_group_7027819.json`
- Aggregation: pv / uv
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-link-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: t+7 receiver share or be shared users/receiver users
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7027819
- Digest: [[digests/digest_7027819_dm_by_link]]
- Numerator: `T1:link_launch_with_internal_video_share_7d_pair_cnt` (type: `uv`)
- Denominator: `T1:link_launch_pair_cnt` (type: `uv`)
- Description: t+7 receiver share or be shared users/receiver users
- Provenance: `raw/libra/libra_metric_group_7027819.json`
- Aggregation: uv / uv
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-link-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: User (2779920)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7027819
- Digest: [[digests/digest_7027819_dm_by_link]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7027819.json`
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-user-link-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->
