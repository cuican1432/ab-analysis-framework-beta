# Metrics By Group | [IM] DM Camera Metrics

group_id: 7036186
canonical_name: [IM] DM Camera Metrics
tags: metric-group, dm
wiki_digests: [[digests/digest_7036186_dm_camera]]
wiki_matrices: [[digests/event_metric_matrix_7036186_dm_camera]]

## Metrics

- Send Camera Message uv/au
  - metric_id: `2005309`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_camera_message_uv_au__id_2005309.md`
- Send Camera Message pv/uv
  - metric_id: `2005310`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_camera_message_pv_uv__id_2005310.md`
- Send Camera Message Shooting uv/au
  - metric_id: `2005311`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_camera_message_shooting_uv_au__id_2005311.md`
- Send Camera Message Shooting pv/uv
  - metric_id: `2005312`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_camera_message_shooting_pv_uv__id_2005312.md`
- Send Camera Message Upload uv/au
  - metric_id: `2005313`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_camera_message_upload_uv_au__id_2005313.md`
- Send Camera Message Upload pv/uv
  - metric_id: `2005314`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_camera_message_upload_pv_uv__id_2005314.md`
- Send Camera Effects message uv/au
  - metric_id: `2005315`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_camera_effects_message_uv_au__id_2005315.md`
- Enter DM Camera video shoot page uv/au
  - metric_id: `2005316`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_enter_dm_camera_video_shoot_page_uv_au__id_2005316.md`
- Enter DM Camera video edit page uv/au
  - metric_id: `2005317`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_enter_dm_camera_video_edit_page_uv_au__id_2005317.md`

## Auto Definitions (Excerpt)

### Metric: Enter DM Camera video edit page uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7036186
- Digest: [[digests/digest_7036186_dm_camera]]
- Numerator: `T2:enter_video_edit_page_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Enter video edit page from a DM Camera entrance (not including main posting flow)
- Provenance: `raw/libra/libra_metric_group_7036186.json`
- Field family: `camera_entrance`
- Aggregation: `uv/base_user`
- Meaning: 进入相机编辑页的用户覆盖
- Key filters:
  - `message_type` - 约束 camera send-side 分支，当前可复用值以 `private_image`、`private_video` 及相关 camera-style image/video 类型为主
  - `chat_type` - 区分 private / group camera 发送
  - entrance buckets - 区分 inbox / page / video_detail / main_posting 等入口
  - `if_shoot` - 区分 shoot-path send
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `show_camera_icon_effect` targeted ByteIO probe 当前未命中，不能被直接提升成 canonical event

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Enter DM Camera video shoot page uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7036186
- Digest: [[digests/digest_7036186_dm_camera]]
- Numerator: `T2:enter_video_shoot_page_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Enter video shoot page from a DM Camera entrance (not including main posting flow)
- Provenance: `raw/libra/libra_metric_group_7036186.json`
- Field family: `camera_entrance`
- Aggregation: `uv/base_user`
- Meaning: 进入相机拍摄页的用户覆盖
- Key filters:
  - `message_type` - 约束 camera send-side 分支，当前可复用值以 `private_image`、`private_video` 及相关 camera-style image/video 类型为主
  - `chat_type` - 区分 private / group camera 发送
  - entrance buckets - 区分 inbox / page / video_detail / main_posting 等入口
  - `if_shoot` - 区分 shoot-path send
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `show_camera_icon_effect` targeted ByteIO probe 当前未命中，不能被直接提升成 canonical event

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Camera Effects message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7036186
- Digest: [[digests/digest_7036186_dm_camera]]
- Numerator: `T2:send_effect_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera message with effects uv/au
- Provenance: `raw/libra/libra_metric_group_7036186.json`
- Field family: `camera_creation_path`
- Aggregation: `uv/base_user`
- Meaning: 带特效路径的相机发送覆盖
- Key filters:
  - `message_type` - 约束 camera send-side 分支，当前可复用值以 `private_image`、`private_video` 及相关 camera-style image/video 类型为主
  - `chat_type` - 区分 private / group camera 发送
  - entrance buckets - 区分 inbox / page / video_detail / main_posting 等入口
  - `if_shoot` - 区分 shoot-path send
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `show_camera_icon_effect` targeted ByteIO probe 当前未命中，不能被直接提升成 canonical event

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Camera Message pv/uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7036186
- Digest: [[digests/digest_7036186_dm_camera]]
- Numerator: `T2:send_camera_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera message pv/uv
- Provenance: `raw/libra/libra_metric_group_7036186.json`
- Field family: `camera_send_completion`
- Aggregation: `pv/base_user`
- Meaning: 人均相机发送强度
- Key filters:
  - `message_type` - 约束 camera send-side 分支，当前可复用值以 `private_image`、`private_video` 及相关 camera-style image/video 类型为主
  - `chat_type` - 区分 private / group camera 发送
  - entrance buckets - 区分 inbox / page / video_detail / main_posting 等入口
  - `if_shoot` - 区分 shoot-path send
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `show_camera_icon_effect` targeted ByteIO probe 当前未命中，不能被直接提升成 canonical event

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Camera Message Shooting pv/uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7036186
- Digest: [[digests/digest_7036186_dm_camera]]
- Numerator: `T2:send_message_by_shoot_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera shoot message pv/uv
- Provenance: `raw/libra/libra_metric_group_7036186.json`
- Key filters:
  - `message_type` - 约束 camera send-side 分支，当前可复用值以 `private_image`、`private_video` 及相关 camera-style image/video 类型为主
  - `chat_type` - 区分 private / group camera 发送
  - entrance buckets - 区分 inbox / page / video_detail / main_posting 等入口
  - `if_shoot` - 区分 shoot-path send
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `show_camera_icon_effect` targeted ByteIO probe 当前未命中，不能被直接提升成 canonical event

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Camera Message Shooting uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7036186
- Digest: [[digests/digest_7036186_dm_camera]]
- Numerator: `T2:send_message_by_shoot_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera shoot message uv/au
- Provenance: `raw/libra/libra_metric_group_7036186.json`
- Field family: `camera_creation_path`
- Aggregation: `uv/base_user`
- Meaning: 拍摄路径的相机发送覆盖
- Key filters:
  - `message_type` - 约束 camera send-side 分支，当前可复用值以 `private_image`、`private_video` 及相关 camera-style image/video 类型为主
  - `chat_type` - 区分 private / group camera 发送
  - entrance buckets - 区分 inbox / page / video_detail / main_posting 等入口
  - `if_shoot` - 区分 shoot-path send
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `show_camera_icon_effect` targeted ByteIO probe 当前未命中，不能被直接提升成 canonical event

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Camera Message Upload pv/uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7036186
- Digest: [[digests/digest_7036186_dm_camera]]
- Numerator: `T2:send_message_by_upload_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera upload message pv/uv
- Provenance: `raw/libra/libra_metric_group_7036186.json`
- Key filters:
  - `message_type` - 约束 camera send-side 分支，当前可复用值以 `private_image`、`private_video` 及相关 camera-style image/video 类型为主
  - `chat_type` - 区分 private / group camera 发送
  - entrance buckets - 区分 inbox / page / video_detail / main_posting 等入口
  - `if_shoot` - 区分 shoot-path send
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `show_camera_icon_effect` targeted ByteIO probe 当前未命中，不能被直接提升成 canonical event

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Camera Message Upload uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7036186
- Digest: [[digests/digest_7036186_dm_camera]]
- Numerator: `T2:send_message_by_upload_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera upload message uv/au
- Provenance: `raw/libra/libra_metric_group_7036186.json`
- Field family: `camera_creation_path`
- Aggregation: `uv/base_user`
- Meaning: 上传路径的相机发送覆盖
- Key filters:
  - `message_type` - 约束 camera send-side 分支，当前可复用值以 `private_image`、`private_video` 及相关 camera-style image/video 类型为主
  - `chat_type` - 区分 private / group camera 发送
  - entrance buckets - 区分 inbox / page / video_detail / main_posting 等入口
  - `if_shoot` - 区分 shoot-path send
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `show_camera_icon_effect` targeted ByteIO probe 当前未命中，不能被直接提升成 canonical event

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Camera Message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7036186
- Digest: [[digests/digest_7036186_dm_camera]]
- Numerator: `T2:send_camera_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera message uv/au
- Provenance: `raw/libra/libra_metric_group_7036186.json`
- Field family: `camera_send_completion`
- Aggregation: `uv/base_user`
- Meaning: 有相机发送行为的用户覆盖
- Key filters:
  - `message_type` - 约束 camera send-side 分支，当前可复用值以 `private_image`、`private_video` 及相关 camera-style image/video 类型为主
  - `chat_type` - 区分 private / group camera 发送
  - entrance buckets - 区分 inbox / page / video_detail / main_posting 等入口
  - `if_shoot` - 区分 shoot-path send
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `show_camera_icon_effect` targeted ByteIO probe 当前未命中，不能被直接提升成 canonical event

<!-- AUTO-GENERATED:metric_fields:end -->
