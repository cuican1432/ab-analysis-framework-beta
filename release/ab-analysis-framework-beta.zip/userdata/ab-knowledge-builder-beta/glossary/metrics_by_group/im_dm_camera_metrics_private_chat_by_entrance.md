# Metrics By Group | [IM] DM Camera Metrics Private Chat by entrance

group_id: 7054234
canonical_name: [IM] DM Camera Metrics Private Chat by entrance
tags: metric-group, dm
wiki_digests: [[digests/digest_7054234_dm_camera_private_chat_by_entrance]]
wiki_matrices: [[digests/event_metric_matrix_7054234_dm_camera_private_chat_by_entrance]]

## Metrics

- Private Chat Send Message from inbox entrance uv/au
  - metric_id: `2005348`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_send_message_from_inbox_entrance_uv_au__id_2005348.md`
- Private Chat Send Message from chat page entrance uv/au
  - metric_id: `2005349`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_send_message_from_chat_page_entrance_uv_au__id_2005349.md`
- Private Chat Send Message from try effect entrance uv/au
  - metric_id: `2005350`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_send_message_from_try_effect_entrance_uv_au__id_2005350.md`
- Private Chat Send Message from video detail entrance uv/au
  - metric_id: `2005351`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_send_message_from_video_detail_entrance_uv_au__id_2005351.md`
- Private Chat Send Message from main posting entrance uv/au
  - metric_id: `2005352`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_send_message_from_main_posting_entrance_uv_au__id_2005352.md`
- Private Chat Send Message from chat upload entrance uv/au
  - metric_id: `2005353`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_send_message_from_chat_upload_entrance_uv_au__id_2005353.md`
- Private Chat Click DM Camera shooting entrance uv/au
  - metric_id: `2005354`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_click_dm_camera_shooting_entrance_uv_au__id_2005354.md`
- Private Chat Click try effect entrance uv/au
  - metric_id: `2005355`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_click_try_effect_entrance_uv_au__id_2005355.md`
- Private Chat Click video detail entrance uv/au
  - metric_id: `2005356`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_click_video_detail_entrance_uv_au__id_2005356.md`
- Private Chat Click inbox camera icon entrance uv/au
  - metric_id: `2005357`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_click_inbox_camera_icon_entrance_uv_au__id_2005357.md`
- Private Chat Click chat page entrance uv/au
  - metric_id: `2005358`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_click_chat_page_entrance_uv_au__id_2005358.md`
- Private Chat Click chat page upload entrance uv/au
  - metric_id: `2005359`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_click_chat_page_upload_entrance_uv_au__id_2005359.md`

## Auto Definitions (Excerpt)

### Metric: Private Chat Click chat page entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054234
- Digest: [[digests/digest_7054234_dm_camera_private_chat_by_entrance]]
- Numerator: `T2:private_chat_page_camera_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click chat page entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054234.json`
- Field family: `camera_private_entrance_click`
- Aggregation: `uv/base_user`
- Meaning: 私聊 chat page 入口点击覆盖
- Key filters:
  - `chat_type = private` - 将整个包限定在私聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看私聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Click chat page upload entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054234
- Digest: [[digests/digest_7054234_dm_camera_private_chat_by_entrance]]
- Numerator: `T2:private_chat_album_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click chat page upload entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054234.json`
- Key filters:
  - `chat_type = private` - 将整个包限定在私聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看私聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Click DM Camera shooting entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054234
- Digest: [[digests/digest_7054234_dm_camera_private_chat_by_entrance]]
- Numerator: `T2:private_chat_camera_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click DM Camera Shooting entrance uv/au (exclude main posting flow)
- Provenance: `raw/libra/libra_metric_group_7054234.json`
- Key filters:
  - `chat_type = private` - 将整个包限定在私聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看私聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Click inbox camera icon entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054234
- Digest: [[digests/digest_7054234_dm_camera_private_chat_by_entrance]]
- Numerator: `T2:private_chat_inbox_camera_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click inbox camera icon entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054234.json`
- Field family: `camera_private_entrance_click`
- Aggregation: `uv/base_user`
- Meaning: 私聊 inbox 入口点击覆盖
- Key filters:
  - `chat_type = private` - 将整个包限定在私聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看私聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Click try effect entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054234
- Digest: [[digests/digest_7054234_dm_camera_private_chat_by_entrance]]
- Numerator: `T2:private_chat_try_effect_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click try effect entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054234.json`
- Key filters:
  - `chat_type = private` - 将整个包限定在私聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看私聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Click video detail entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054234
- Digest: [[digests/digest_7054234_dm_camera_private_chat_by_entrance]]
- Numerator: `T2:private_chat_video_detail_camera_entrance_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Click video detail entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054234.json`
- Field family: `camera_private_entrance_click`
- Aggregation: `uv/base_user`
- Meaning: 私聊 video detail 入口点击覆盖
- Key filters:
  - `chat_type = private` - 将整个包限定在私聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看私聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Send Message from chat page entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054234
- Digest: [[digests/digest_7054234_dm_camera_private_chat_by_entrance]]
- Numerator: `T2:private_chat_page_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send Message from chat page entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054234.json`
- Field family: `camera_private_entrance_send`
- Aggregation: `uv/base_user`
- Meaning: 私聊 chat page 入口发送覆盖
- Key filters:
  - `chat_type = private` - 将整个包限定在私聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看私聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Send Message from chat upload entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054234
- Digest: [[digests/digest_7054234_dm_camera_private_chat_by_entrance]]
- Numerator: `T2:private_chat_page_upload_entrance_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send message from chat page upload entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054234.json`
- Key filters:
  - `chat_type = private` - 将整个包限定在私聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看私聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Send Message from inbox entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054234
- Digest: [[digests/digest_7054234_dm_camera_private_chat_by_entrance]]
- Numerator: `T2:private_chat_inbox_camera_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send Message from inbox entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054234.json`
- Field family: `camera_private_entrance_send`
- Aggregation: `uv/base_user`
- Meaning: 私聊 inbox 入口发送覆盖
- Key filters:
  - `chat_type = private` - 将整个包限定在私聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看私聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Send Message from main posting entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054234
- Digest: [[digests/digest_7054234_dm_camera_private_chat_by_entrance]]
- Numerator: `T2:private_chat_main_posting_camera_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send Message from main posting entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054234.json`
- Key filters:
  - `chat_type = private` - 将整个包限定在私聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看私聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Send Message from try effect entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054234
- Digest: [[digests/digest_7054234_dm_camera_private_chat_by_entrance]]
- Numerator: `T2:private_chat_try_effect_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send Message from try effect entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054234.json`
- Key filters:
  - `chat_type = private` - 将整个包限定在私聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看私聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Send Message from video detail entrance uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054234
- Digest: [[digests/digest_7054234_dm_camera_private_chat_by_entrance]]
- Numerator: `T2:private_chat_video_detail_entrance_send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send Message from video detail entrance uv/au
- Provenance: `raw/libra/libra_metric_group_7054234.json`
- Field family: `camera_private_entrance_send`
- Aggregation: `uv/base_user`
- Meaning: 私聊 video detail 入口发送覆盖
- Key filters:
  - `chat_type = private` - 将整个包限定在私聊相机场景
  - entrance bucket - 做入口归因
  - cohort cuts - 看私聊相机入口在不同人群中的差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->
