# Metrics By Group | [IM] DM Camera Metrics Private Chat

group_id: 7054231
canonical_name: [IM] DM Camera Metrics Private Chat
tags: metric-group, dm
wiki_digests: [[digests/digest_7054231_dm_camera_private_chat]]
wiki_matrices: [[digests/event_metric_matrix_7054231_dm_camera_private_chat]]

## Metrics

- Private Chat Send Camera Message uv/au
  - metric_id: `2005332`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_send_camera_message_uv_au__id_2005332.md`
- Private Chat Send Camera Message pv/uv
  - metric_id: `2005333`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_send_camera_message_pv_uv__id_2005333.md`
- Private Chat Send Camera Message Shooting uv/au
  - metric_id: `2005334`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_send_camera_message_shooting_uv_au__id_2005334.md`
- Private Chat Send Camera Message Shooting pv/uv
  - metric_id: `2005335`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_send_camera_message_shooting_pv_uv__id_2005335.md`
- Private Chat Send Camera Message Upload uv/au
  - metric_id: `2005336`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_send_camera_message_upload_uv_au__id_2005336.md`
- Private Chat Send Camera Message Upload pv/uv
  - metric_id: `2005337`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_send_camera_message_upload_pv_uv__id_2005337.md`
- Private Chat Send Camera Effects message uv/au
  - metric_id: `2005338`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_send_camera_effects_message_uv_au__id_2005338.md`
- Private Chat Send Camera Effects message pv/au
  - metric_id: `2005339`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_send_camera_effects_message_pv_au__id_2005339.md`

## Auto Definitions (Excerpt)

### Metric: Private Chat Send Camera Effects message pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054231
- Digest: [[digests/digest_7054231_dm_camera_private_chat]]
- Numerator: `T2:private_chat_send_effect_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera message with effects pv/au
- Provenance: `raw/libra/libra_metric_group_7054231.json`
- Key filters:
  - `chat_type = private` - 将所有 camera 指标限定为私聊场景
  - creation mode - 比较私聊创作路径差异
  - cohort cuts - 看私聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Send Camera Effects message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054231
- Digest: [[digests/digest_7054231_dm_camera_private_chat]]
- Numerator: `T2:private_chat_send_effect_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera message with effects uv/au
- Provenance: `raw/libra/libra_metric_group_7054231.json`
- Field family: `camera_private_creation_path`
- Aggregation: `uv/base_user`
- Meaning: 私聊特效路径发送覆盖
- Key filters:
  - `chat_type = private` - 将所有 camera 指标限定为私聊场景
  - creation mode - 比较私聊创作路径差异
  - cohort cuts - 看私聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Send Camera Message pv/uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054231
- Digest: [[digests/digest_7054231_dm_camera_private_chat]]
- Numerator: `T2:private_chat_send_camera_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera message pv/uv
- Provenance: `raw/libra/libra_metric_group_7054231.json`
- Field family: `camera_private_send_completion`
- Aggregation: `pv/base_user`
- Meaning: 私聊 camera 人均发送强度
- Key filters:
  - `chat_type = private` - 将所有 camera 指标限定为私聊场景
  - creation mode - 比较私聊创作路径差异
  - cohort cuts - 看私聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Send Camera Message Shooting pv/uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054231
- Digest: [[digests/digest_7054231_dm_camera_private_chat]]
- Numerator: `T2:private_chat_send_message_by_shoot_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera shoot message pv/uv
- Provenance: `raw/libra/libra_metric_group_7054231.json`
- Key filters:
  - `chat_type = private` - 将所有 camera 指标限定为私聊场景
  - creation mode - 比较私聊创作路径差异
  - cohort cuts - 看私聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Send Camera Message Shooting uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054231
- Digest: [[digests/digest_7054231_dm_camera_private_chat]]
- Numerator: `T2:private_chat_send_message_by_shoot_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera shoot message uv/au
- Provenance: `raw/libra/libra_metric_group_7054231.json`
- Field family: `camera_private_creation_path`
- Aggregation: `uv/base_user`
- Meaning: 私聊拍摄路径发送覆盖
- Key filters:
  - `chat_type = private` - 将所有 camera 指标限定为私聊场景
  - creation mode - 比较私聊创作路径差异
  - cohort cuts - 看私聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Send Camera Message Upload pv/uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054231
- Digest: [[digests/digest_7054231_dm_camera_private_chat]]
- Numerator: `T2:private_chat_send_message_by_upload_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera upload message pv/uv
- Provenance: `raw/libra/libra_metric_group_7054231.json`
- Key filters:
  - `chat_type = private` - 将所有 camera 指标限定为私聊场景
  - creation mode - 比较私聊创作路径差异
  - cohort cuts - 看私聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Send Camera Message Upload uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054231
- Digest: [[digests/digest_7054231_dm_camera_private_chat]]
- Numerator: `T2:private_chat_send_message_by_upload_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera upload message uv/au
- Provenance: `raw/libra/libra_metric_group_7054231.json`
- Field family: `camera_private_creation_path`
- Aggregation: `uv/base_user`
- Meaning: 私聊上传路径发送覆盖
- Key filters:
  - `chat_type = private` - 将所有 camera 指标限定为私聊场景
  - creation mode - 比较私聊创作路径差异
  - cohort cuts - 看私聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat Send Camera Message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054231
- Digest: [[digests/digest_7054231_dm_camera_private_chat]]
- Numerator: `T2:private_chat_send_camera_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera message uv/au
- Provenance: `raw/libra/libra_metric_group_7054231.json`
- Field family: `camera_private_send_completion`
- Aggregation: `uv/base_user`
- Meaning: 私聊 camera 发送用户覆盖
- Key filters:
  - `chat_type = private` - 将所有 camera 指标限定为私聊场景
  - creation mode - 比较私聊创作路径差异
  - cohort cuts - 看私聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->
