# Metrics By Group | internal share funnel metrics

group_id: 7029593
canonical_name: internal share funnel metrics
tags: metric-group, dm
wiki_digests: [[digests/digest_7029593_internal_share_funnel_metrics]]
wiki_matrices: [[digests/event_metric_matrix_7029593_internal_share_funnel_metrics]]

## Metrics

- base_user
  - metric_id: `2285266`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_2285266.md`
- share send pv/vv
  - metric_id: `2285267`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_send_pv_vv__id_2285267.md`
- enter share panel uv/au
  - metric_id: `2285268`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_enter_share_panel_uv_au__id_2285268.md`
- share head show uv/au
  - metric_id: `2285269`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_head_show_uv_au__id_2285269.md`
- share head click uv/au
  - metric_id: `2285270`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_head_click_uv_au__id_2285270.md`
- share send uv/au
  - metric_id: `2285271`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_send_uv_au__id_2285271.md`
- share head show/enter share panel uv
  - metric_id: `2285272`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_head_show_enter_share_panel_uv__id_2285272.md`
- share head click/show uv
  - metric_id: `2285273`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_head_click_show_uv__id_2285273.md`
- share send/head click uv
  - metric_id: `2285274`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_send_head_click_uv__id_2285274.md`
- enter share panel pv/au
  - metric_id: `2285275`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_enter_share_panel_pv_au__id_2285275.md`
- share head show pv/au
  - metric_id: `2285276`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_head_show_pv_au__id_2285276.md`
- share head click pv/au
  - metric_id: `2285277`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_head_click_pv_au__id_2285277.md`
- share send pv/au
  - metric_id: `2285278`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_send_pv_au__id_2285278.md`
- share head show pv/enter share panel pv
  - metric_id: `2285279`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_head_show_pv_enter_share_panel_pv__id_2285279.md`
- share head click pv/show pv
  - metric_id: `2285280`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_head_click_pv_show_pv__id_2285280.md`
- share send pv/head click pv
  - metric_id: `2285281`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_send_pv_head_click_pv__id_2285281.md`
- click share enter share panel uv/au
  - metric_id: `2285282`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_enter_share_panel_uv_au__id_2285282.md`
- click share share head show uv/au
  - metric_id: `2285283`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_share_head_show_uv_au__id_2285283.md`
- click share share head click uv/au
  - metric_id: `2285284`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_share_head_click_uv_au__id_2285284.md`
- click share share send uv/au
  - metric_id: `2285285`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_share_send_uv_au__id_2285285.md`
- click share share head show/enter share panel uv
  - metric_id: `2285286`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_share_head_show_enter_share_panel_uv__id_2285286.md`
- click share share head click/show uv
  - metric_id: `2285287`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_share_head_click_show_uv__id_2285287.md`
- click share share send/head click uv
  - metric_id: `2285288`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_share_send_head_click_uv__id_2285288.md`
- click share enter share panel pv/au
  - metric_id: `2285289`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_enter_share_panel_pv_au__id_2285289.md`
- click share share head show pv/au
  - metric_id: `2285290`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_share_head_show_pv_au__id_2285290.md`
- click share share head click pv/au
  - metric_id: `2285291`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_share_head_click_pv_au__id_2285291.md`
- click share share send pv/au
  - metric_id: `2285292`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_share_send_pv_au__id_2285292.md`
- click share share head show/enter share panel pv
  - metric_id: `2285293`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_share_head_show_enter_share_panel_pv__id_2285293.md`
- click share share head click/show pv
  - metric_id: `2285294`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_share_head_click_show_pv__id_2285294.md`
- click share share send/head click pv
  - metric_id: `2285295`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_share_send_head_click_pv__id_2285295.md`
- long press enter share panel uv/au
  - metric_id: `2285296`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_enter_share_panel_uv_au__id_2285296.md`
- long press share head show uv/au
  - metric_id: `2285297`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_head_show_uv_au__id_2285297.md`
- long press share head click uv/au
  - metric_id: `2285298`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_head_click_uv_au__id_2285298.md`
- long press share send uv/au
  - metric_id: `2285299`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_send_uv_au__id_2285299.md`
- long press share head show/enter share panel uv
  - metric_id: `2285300`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_head_show_enter_share_panel_uv__id_2285300.md`
- long press share head click/show uv
  - metric_id: `2285301`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_head_click_show_uv__id_2285301.md`
- long press share send/head click uv
  - metric_id: `2285302`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_send_head_click_uv__id_2285302.md`
- long press enter share panel pv/au
  - metric_id: `2285303`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_enter_share_panel_pv_au__id_2285303.md`
- long press share head show pv/au
  - metric_id: `2285304`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_head_show_pv_au__id_2285304.md`
- long press share head click pv/au
  - metric_id: `2285305`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_head_click_pv_au__id_2285305.md`
- long press share send pv/au
  - metric_id: `2285306`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_send_pv_au__id_2285306.md`
- long press share head show/enter share panel pv
  - metric_id: `2285307`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_head_show_enter_share_panel_pv__id_2285307.md`
- long press share head click/show pv
  - metric_id: `2285308`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_head_click_show_pv__id_2285308.md`
- long press share send/head click pv
  - metric_id: `2285309`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_send_head_click_pv__id_2285309.md`

## Auto Definitions (Excerpt)

### Metric: base_user (2285266)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share enter share panel pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:click_share_enter_share_panel_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: click share enter share panel pv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: pv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share enter share panel uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:click_share_enter_share_panel_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: click share enter share panel uv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: uv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share share head click pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:click_share_click_user_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: click share share head click pv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: pv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share share head click/show pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:click_share_click_user_cnt` (type: `pv`)
- Denominator: `T1:click_share_show_user_cnt` (type: `pv`)
- Description: click share share head click/show pv
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: pv / pv
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share share head click/show uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:click_share_click_user_cnt` (type: `uv`)
- Denominator: `T1:click_share_show_user_cnt` (type: `uv`)
- Description: click share share head click/show uv
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: uv / uv
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share share head click uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:click_share_click_user_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: click share share head click uv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: uv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share share head show/enter share panel pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:click_share_show_user_cnt` (type: `pv`)
- Denominator: `T1:click_share_enter_share_panel_cnt` (type: `pv`)
- Description: click share share head show/enter share panel pv
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: pv / pv
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share share head show/enter share panel uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:click_share_show_user_cnt` (type: `uv`)
- Denominator: `T1:click_share_enter_share_panel_cnt` (type: `uv`)
- Description: click share share head show/enter share panel uv
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: uv / uv
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share share head show pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:click_share_show_user_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: click share share head show pv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: pv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share share head show uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:click_share_show_user_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: click share share head show uv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: uv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share share send/head click pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:click_share_internal_share_cnt` (type: `pv`)
- Denominator: `T1:click_share_click_user_cnt` (type: `pv`)
- Description: click share share send/head click pv
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: pv / pv
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share share send/head click uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:click_share_internal_share_cnt` (type: `uv`)
- Denominator: `T1:click_share_click_user_cnt` (type: `uv`)
- Description: click share share send/head click uv
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: uv / uv
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share share send pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:click_share_internal_share_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: click share share send pv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: pv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share share send uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:click_share_internal_share_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: click share share send uv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: uv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: enter share panel pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:enter_share_panel_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: enter share panel pv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: pv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: enter share panel uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:enter_share_panel_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: enter share panel uv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: uv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press enter share panel pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:long_press_enter_share_panel_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: long press enter share panel pv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: pv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press enter share panel uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:long_press_enter_share_panel_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: long press enter share panel uv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: uv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share head click pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:long_press_click_user_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: long press share head click pv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: pv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share head click/show pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:long_press_click_user_cnt` (type: `pv`)
- Denominator: `T1:long_press_show_user_cnt` (type: `pv`)
- Description: long press share head click/show pv
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: pv / pv
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share head click/show uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:long_press_click_user_cnt` (type: `uv`)
- Denominator: `T1:click_share_show_user_cnt` (type: `uv`)
- Description: long press share head click/show uv
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: uv / uv
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share head click uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:long_press_click_user_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: long press share head click uv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: uv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share head show/enter share panel pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:long_press_show_user_cnt` (type: `pv`)
- Denominator: `T1:long_press_enter_share_panel_cnt` (type: `pv`)
- Description: long press share head show/enter share panel pv
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: pv / pv
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share head show/enter share panel uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:long_press_show_user_cnt` (type: `uv`)
- Denominator: `T1:long_press_enter_share_panel_cnt` (type: `uv`)
- Description: long press share head show/enter share panel uv
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: uv / uv
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share head show pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:long_press_show_user_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: long press share head show pv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: pv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share head show uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:long_press_show_user_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: long press share head show uv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: uv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share send/head click pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:long_press_internal_share_cnt` (type: `pv`)
- Denominator: `T1:long_press_click_user_cnt` (type: `pv`)
- Description: long press share send/head click pv
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: pv / pv
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share send/head click uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:long_press_internal_share_cnt` (type: `uv`)
- Denominator: `T1:long_press_click_user_cnt` (type: `uv`)
- Description: long press share send/head click uv
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: uv / uv
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share send pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7029593
- Digest: [[digests/digest_7029593_internal_share_funnel_metrics]]
- Numerator: `T1:long_press_internal_share_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: long press share send pv/au
- Provenance: `raw/libra/libra_metric_group_7029593.json`
- Aggregation: pv / base_user
- Key filters:
  - `head` - 区分候选曝光和点击
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - This group is proven at broad share-funnel aggregate level across panel entry, head show, head click, and share send.
  - It is broader than a single DM event contract and should stay at aggregate family confidence.

<!-- AUTO-GENERATED:metric_fields:end -->

> truncated: 14 more metrics omitted from the auto excerpt.
