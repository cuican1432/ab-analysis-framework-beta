# Metrics By Group | [IM] Group Chat 3d Retention metrics

group_id: 7049585
canonical_name: [IM] Group Chat 3d Retention metrics
tags: metric-group, dm
wiki_digests: [[digests/digest_7049585_dm_group_chat_3d_retention]]
wiki_matrices: [[digests/event_metric_matrix_7049585_dm_group_chat_3d_retention]]

## Metrics

- base_user
  - metric_id: `2780320`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_2780320.md`
- 3d retention
  - metric_id: `2780321`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_3d_retention__id_2780321.md`
- Share panel main 3d retention
  - metric_id: `2780322`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_panel_main_3d_retention__id_2780322.md`
- Share panel create group 3d retention
  - metric_id: `2780323`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_panel_create_group_3d_retention__id_2780323.md`
- Inbox (top left) 3d retention
  - metric_id: `2780324`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_top_left_3d_retention__id_2780324.md`
- Inbox (multi-mention) 3d retention
  - metric_id: `2780325`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_multi_mention_3d_retention__id_2780325.md`
- Inbox (multi-link) 3d retention
  - metric_id: `2780326`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_multi_link_3d_retention__id_2780326.md`
- Inbox (cluster) 3d retention
  - metric_id: `2780327`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_cluster_3d_retention__id_2780327.md`
- Private Chat 3d retention
  - metric_id: `2780328`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_private_chat_3d_retention__id_2780328.md`
- Live 3d retention
  - metric_id: `2780329`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_live_3d_retention__id_2780329.md`
- AI group shot 3d retention
  - metric_id: `2780330`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_ai_group_shot_3d_retention__id_2780330.md`
- Others
  - metric_id: `2780331`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_others__id_2780331.md`

## Auto Definitions (Excerpt)

### Metric: 3d retention (2780321)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049585
- Digest: [[digests/digest_7049585_dm_group_chat_3d_retention]]
- Numerator: `T1:new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T1:new_group_chat` (type: `pv`)
- Description: 3d retention
- Provenance: `raw/libra/libra_metric_group_7049585.json`
- Field family: `group_chat_retention_3d_core`
- Aggregation: `pv/pv`
- Meaning: 全量新建群在 3d 窗口后的留存率
- Key filters:
  - `3d` - 指定早期留存窗口
  - creation-source prefix - 比较不同建群来源质量
  - cohort scope - 本组面向全量新建群 cohort
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-3d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-3d]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: AI group shot 3d retention (2780330)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049585
- Digest: [[digests/digest_7049585_dm_group_chat_3d_retention]]
- Numerator: `T1:ai_group_shot_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T1:ai_group_shot_new_group_chat` (type: `pv`)
- Provenance: `raw/libra/libra_metric_group_7049585.json`
- Key filters:
  - `3d` - 指定早期留存窗口
  - creation-source prefix - 比较不同建群来源质量
  - cohort scope - 本组面向全量新建群 cohort
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-3d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-3d]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: base_user (2780320)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049585
- Digest: [[digests/digest_7049585_dm_group_chat_3d_retention]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7049585.json`
- Key filters:
  - `3d` - 指定早期留存窗口
  - creation-source prefix - 比较不同建群来源质量
  - cohort scope - 本组面向全量新建群 cohort
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-3d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-3d]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox (cluster) 3d retention (2780327)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049585
- Digest: [[digests/digest_7049585_dm_group_chat_3d_retention]]
- Numerator: `T1:inbox_cluster_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T1:inbox_cluster_new_group_chat` (type: `pv`)
- Provenance: `raw/libra/libra_metric_group_7049585.json`
- Key filters:
  - `3d` - 指定早期留存窗口
  - creation-source prefix - 比较不同建群来源质量
  - cohort scope - 本组面向全量新建群 cohort
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-3d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-3d]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox (multi-link) 3d retention (2780326)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049585
- Digest: [[digests/digest_7049585_dm_group_chat_3d_retention]]
- Numerator: `T1:inbox_multi_link_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T1:inbox_multi_link_new_group_chat` (type: `pv`)
- Provenance: `raw/libra/libra_metric_group_7049585.json`
- Key filters:
  - `3d` - 指定早期留存窗口
  - creation-source prefix - 比较不同建群来源质量
  - cohort scope - 本组面向全量新建群 cohort
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-3d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-3d]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox (multi-mention) 3d retention (2780325)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049585
- Digest: [[digests/digest_7049585_dm_group_chat_3d_retention]]
- Numerator: `T1:inbox_multi_mention_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T1:inbox_multi_mention_new_group_chat` (type: `pv`)
- Provenance: `raw/libra/libra_metric_group_7049585.json`
- Key filters:
  - `3d` - 指定早期留存窗口
  - creation-source prefix - 比较不同建群来源质量
  - cohort scope - 本组面向全量新建群 cohort
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-3d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-3d]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox (top left) 3d retention (2780324)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049585
- Digest: [[digests/digest_7049585_dm_group_chat_3d_retention]]
- Numerator: `T1:inbox_top_left_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T1:inbox_top_left_new_group_chat` (type: `pv`)
- Provenance: `raw/libra/libra_metric_group_7049585.json`
- Field family: `group_chat_retention_3d_source_quality`
- Aggregation: `pv/pv`
- Meaning: inbox top-left 来源的 3d 留存率
- Key filters:
  - `3d` - 指定早期留存窗口
  - creation-source prefix - 比较不同建群来源质量
  - cohort scope - 本组面向全量新建群 cohort
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-3d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-3d]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Live 3d retention (2780329)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049585
- Digest: [[digests/digest_7049585_dm_group_chat_3d_retention]]
- Numerator: `T1:live_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T1:live_new_group_chat` (type: `pv`)
- Provenance: `raw/libra/libra_metric_group_7049585.json`
- Field family: `group_chat_retention_3d_source_quality`
- Aggregation: `pv/pv`
- Meaning: live 来源建群的 3d 留存率
- Key filters:
  - `3d` - 指定早期留存窗口
  - creation-source prefix - 比较不同建群来源质量
  - cohort scope - 本组面向全量新建群 cohort
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-3d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-3d]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Others (2780331)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049585
- Digest: [[digests/digest_7049585_dm_group_chat_3d_retention]]
- Numerator: `T1:other_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T1:other_new_group_chat` (type: `pv`)
- Description: As long as not in above categories
- Provenance: `raw/libra/libra_metric_group_7049585.json`
- Key filters:
  - `3d` - 指定早期留存窗口
  - creation-source prefix - 比较不同建群来源质量
  - cohort scope - 本组面向全量新建群 cohort
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-3d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-3d]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Private Chat 3d retention (2780328)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049585
- Digest: [[digests/digest_7049585_dm_group_chat_3d_retention]]
- Numerator: `T1:private_chat_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T1:private_chat_new_group_chat` (type: `pv`)
- Provenance: `raw/libra/libra_metric_group_7049585.json`
- Field family: `group_chat_retention_3d_source_quality`
- Aggregation: `pv/pv`
- Meaning: private-chat 来源建群的 3d 留存率
- Key filters:
  - `3d` - 指定早期留存窗口
  - creation-source prefix - 比较不同建群来源质量
  - cohort scope - 本组面向全量新建群 cohort
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-3d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-3d]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Share panel create group 3d retention (2780323)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049585
- Digest: [[digests/digest_7049585_dm_group_chat_3d_retention]]
- Numerator: `T1:share_panel_create_group_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T1:share_panel_create_group_new_group_chat` (type: `pv`)
- Description: Share panel: create group button
- Provenance: `raw/libra/libra_metric_group_7049585.json`
- Field family: `group_chat_retention_3d_source_quality`
- Aggregation: `pv/pv`
- Meaning: share panel create-group 来源的 3d 留存率
- Key filters:
  - `3d` - 指定早期留存窗口
  - creation-source prefix - 比较不同建群来源质量
  - cohort scope - 本组面向全量新建群 cohort
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-3d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-3d]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Share panel main 3d retention (2780322)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049585
- Digest: [[digests/digest_7049585_dm_group_chat_3d_retention]]
- Numerator: `T1:share_panel_main_new_group_chat_ret_3d` (type: `pv`)
- Denominator: `T1:share_panel_main_new_group_chat` (type: `pv`)
- Description: Share panel: create group and share (normal)
- Provenance: `raw/libra/libra_metric_group_7049585.json`
- Field family: `group_chat_retention_3d_source_quality`
- Aggregation: `pv/pv`
- Meaning: 主 share panel 建群来源的 3d 留存率
- Key filters:
  - `3d` - 指定早期留存窗口
  - creation-source prefix - 比较不同建群来源质量
  - cohort scope - 本组面向全量新建群 cohort
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-3d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-3d]]

<!-- AUTO-GENERATED:metric_fields:end -->
