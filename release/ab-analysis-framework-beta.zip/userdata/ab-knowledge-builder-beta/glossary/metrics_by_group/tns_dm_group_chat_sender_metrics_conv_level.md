# Metrics By Group | TnS DM Group Chat Sender Metrics - Conv Level

group_id: 7043980
canonical_name: TnS DM Group Chat Sender Metrics - Conv Level
tags: metric-group, dm
wiki_digests: [[digests/digest_7043980_tns_dm_group_chat_sender_metrics_conv_level]]
wiki_matrices: [[digests/event_metric_matrix_7043980_tns_dm_group_chat_sender_metrics_conv_level]]

## Metrics

- ban_rate_groupcov
  - metric_id: `916524`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_ban_rate_groupcov__id_916524.md`
- notice_rate_groupcov
  - metric_id: `916525`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notice_rate_groupcov__id_916525.md`
- feedback_rate_groupcov
  - metric_id: `916526`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_rate_groupcov__id_916526.md`
- feedback_success_rate_groupcov
  - metric_id: `916527`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_success_rate_groupcov__id_916527.md`
- feedback_appeal_rate_groupcov
  - metric_id: `916528`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_appeal_rate_groupcov__id_916528.md`
- feedback_appeal_success_rate_groupcov
  - metric_id: `916529`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_appeal_success_rate_groupcov__id_916529.md`
- report_rate_groupcov
  - metric_id: `916530`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_rate_groupcov__id_916530.md`
- report_violate_rate_groupcov
  - metric_id: `916531`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_violate_rate_groupcov__id_916531.md`
- report_egregious_rate_groupcov
  - metric_id: `916532`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_egregious_rate_groupcov__id_916532.md`
- report_appeal_rate_groupcov
  - metric_id: `916533`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_appeal_rate_groupcov__id_916533.md`
- report_appeal_success_rate_groupcov
  - metric_id: `916534`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_appeal_success_rate_groupcov__id_916534.md`
- report_appeal_egregious_rate_groupcov
  - metric_id: `916535`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_appeal_egregious_rate_groupcov__id_916535.md`

## Auto Definitions (Excerpt)

### Metric: ban_rate_groupcov
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043980
- Digest: [[digests/digest_7043980_tns_dm_group_chat_sender_metrics_conv_level]]
- Numerator: `T1:ban_group_conv_cnt` (type: `pv`)
- Denominator: `T1:group_conv_cnt` (type: `pv`)
- Description: ban_groupcov_cnt / groupcov_cnt
- Provenance: `raw/libra/libra_metric_group_7043980.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_appeal_rate_groupcov
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043980
- Digest: [[digests/digest_7043980_tns_dm_group_chat_sender_metrics_conv_level]]
- Numerator: `T1:feedback_appeal_group_conv_cnt` (type: `pv`)
- Denominator: `T1:feedback_group_conv_cnt` (type: `pv`)
- Description: feedback_appeal_groupcov_cnt / groupcov_cnt
- Provenance: `raw/libra/libra_metric_group_7043980.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_appeal_success_rate_groupcov
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043980
- Digest: [[digests/digest_7043980_tns_dm_group_chat_sender_metrics_conv_level]]
- Numerator: `T1:feedback_appeal_success_group_conv_cnt` (type: `pv`)
- Denominator: `T1:feedback_appeal_group_conv_cnt` (type: `pv`)
- Description: feedback_appeal_success_groupcov_cnt / groupcov_cnt
- Provenance: `raw/libra/libra_metric_group_7043980.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_rate_groupcov
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043980
- Digest: [[digests/digest_7043980_tns_dm_group_chat_sender_metrics_conv_level]]
- Numerator: `T1:feedback_group_conv_cnt` (type: `pv`)
- Denominator: `T1:ban_group_conv_cnt` (type: `pv`)
- Description: feedback_groupcov_cnt / groupcov_cnt
- Provenance: `raw/libra/libra_metric_group_7043980.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_success_rate_groupcov
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043980
- Digest: [[digests/digest_7043980_tns_dm_group_chat_sender_metrics_conv_level]]
- Numerator: `T1:feedback_success_group_conv_cnt` (type: `pv`)
- Denominator: `T1:feedback_group_conv_cnt` (type: `pv`)
- Description: feedback_success_groupcov_cnt / groupcov_cnt
- Provenance: `raw/libra/libra_metric_group_7043980.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: notice_rate_groupcov
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043980
- Digest: [[digests/digest_7043980_tns_dm_group_chat_sender_metrics_conv_level]]
- Numerator: `T1:notice_group_conv_cnt` (type: `pv`)
- Denominator: `T1:group_conv_cnt` (type: `pv`)
- Description: notice_groupcov_cnt / groupcov_cnt
- Provenance: `raw/libra/libra_metric_group_7043980.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_appeal_egregious_rate_groupcov
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043980
- Digest: [[digests/digest_7043980_tns_dm_group_chat_sender_metrics_conv_level]]
- Numerator: `T1:report_appeal_egregious_group_conv_cnt` (type: `pv`)
- Denominator: `T1:report_appeal_group_conv_cnt` (type: `pv`)
- Description: report_appeal_egregious_groupcov_cnt / groupcov_cnt
- Provenance: `raw/libra/libra_metric_group_7043980.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_appeal_rate_groupcov
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043980
- Digest: [[digests/digest_7043980_tns_dm_group_chat_sender_metrics_conv_level]]
- Numerator: `T1:report_appeal_group_conv_cnt` (type: `pv`)
- Denominator: `T1:report_group_msg_usr_cnt` (type: `pv`)
- Description: report_appeal_groupcov_cnt / groupcov_cnt
- Provenance: `raw/libra/libra_metric_group_7043980.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_appeal_success_rate_groupcov
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043980
- Digest: [[digests/digest_7043980_tns_dm_group_chat_sender_metrics_conv_level]]
- Numerator: `T1:report_appeal_success_group_conv_cnt` (type: `pv`)
- Denominator: `T1:report_appeal_group_conv_cnt` (type: `pv`)
- Description: report_appeal_success_groupcov_cnt / groupcov_cnt
- Provenance: `raw/libra/libra_metric_group_7043980.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_egregious_rate_groupcov
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043980
- Digest: [[digests/digest_7043980_tns_dm_group_chat_sender_metrics_conv_level]]
- Numerator: `T1:report_egregious_group_conv_cnt` (type: `pv`)
- Denominator: `T1:report_group_msg_usr_cnt` (type: `pv`)
- Description: report_egregious_groupcov_cnt / groupcov_cnt
- Provenance: `raw/libra/libra_metric_group_7043980.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_rate_groupcov
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043980
- Digest: [[digests/digest_7043980_tns_dm_group_chat_sender_metrics_conv_level]]
- Numerator: `T1:report_group_msg_usr_cnt` (type: `pv`)
- Denominator: `T1:group_conv_cnt` (type: `pv`)
- Description: report_groupcov_cnt / groupcov_cnt
- Provenance: `raw/libra/libra_metric_group_7043980.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_violate_rate_groupcov
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043980
- Digest: [[digests/digest_7043980_tns_dm_group_chat_sender_metrics_conv_level]]
- Numerator: `T1:report_violate_group_conv_cnt` (type: `pv`)
- Denominator: `T1:report_group_msg_usr_cnt` (type: `pv`)
- Description: report_violate_groupcov_cnt / groupcov_cnt
- Provenance: `raw/libra/libra_metric_group_7043980.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->
