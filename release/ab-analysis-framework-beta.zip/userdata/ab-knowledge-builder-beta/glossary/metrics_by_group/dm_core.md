# Metrics By Group | DM Core

group_id: 7018203
canonical_name: DM Core
tags: metric-group, dm
wiki_digests: [[digests/digest_7018203_dm_core]]
wiki_matrices: [[digests/event_metric_matrix_7018203_dm_core]]

## Metrics

- User
  - metric_id: `3399674`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base-user__id_3399674.md`
- User
  - metric_id: `3399674`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_user__id_3399674.md`
- Send Message Days/Days
  - metric_id: `3399675`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_message_days_days__id_3399675.md`
- Send Message Days/User
  - metric_id: `3399676`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_message_days_user__id_3399676.md`
- Send Message PV/User
  - metric_id: `3399677`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_message_pv_user__id_3399677.md`
- Like Message Days/Days
  - metric_id: `3399678`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_like_message_days_days__id_3399678.md`
- Like Message Days/User
  - metric_id: `3399679`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_like_message_days_user__id_3399679.md`
- Like Message PV/User
  - metric_id: `3399680`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_like_message_pv_user__id_3399680.md`
- Internal Share Days/Days
  - metric_id: `3399681`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_days_days__id_3399681.md`
- Internal Share Days/User
  - metric_id: `3399682`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_days_user__id_3399682.md`
- Internal Share PV/User
  - metric_id: `3399683`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_internal_share_pv_user__id_3399683.md`
- Chat Play PV/User
  - metric_id: `3399684`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_chat_play_pv_user__id_3399684.md`
- Stay Duration/User
  - metric_id: `3399685`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_stay_duration_user__id_3399685.md`
- Enter Chat PV/User
  - metric_id: `3399686`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_enter_chat_pv_user__id_3399686.md`
- Send Message Conversation Cnt/User
  - metric_id: `3399687`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_message_conversation_cnt_user__id_3399687.md`
- Enter Chat Conversation Cnt/User
  - metric_id: `3399688`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_enter_chat_conversation_cnt_user__id_3399688.md`
- New Send Message PV/User
  - metric_id: `3399689`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_new_send_message_pv_user__id_3399689.md`
- New Enter Chat PV/User
  - metric_id: `3399690`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_new_enter_chat_pv_user__id_3399690.md`

## Auto Definitions (Excerpt)

### Metric: User (3399674)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Key filters:
  - `send_message` - `send_message_cnt`
  - `like_message` - `like_message_cnt`
  - `enter_chat` - `enter_chat_cnt`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Chat Play PV/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:chat_vv` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: video play count in chat per user
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `chat_vv`
- Meaning: 人均聊天页视频播放次数
- Key filters:
  - `event_family = chat_video_play` - `chat_vv`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - `chat_vv` 已提升为 event family canonical page，但还未拿到更细的 ByteIO raw event 名

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Enter Chat Conversation Cnt/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:enter_chat_ucnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: number of conversations that user enters per user
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `enter_chat_ucnt`
- Meaning: 人均进入过的会话数
- Key filters:
  - `event_family = enter_chat` - `enter_chat_cnt` / `enter_chat_ucnt`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Enter Chat PV/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:enter_chat_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: enter chat count per user
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `enter_chat_cnt`
- Meaning: 人均进入会话次数
- Key filters:
  - `event_family = enter_chat` - `enter_chat_cnt` / `enter_chat_ucnt`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Internal Share Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:share_video_to_chat_cnt` (type: `base_days`)
- Denominator: `T0:app_id` (type: `action_days`)
- Description: internal share days per days
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `share_video_to_chat_cnt`
- Meaning: 分享视频到会话活跃天数占比
- Key filters:
  - `event_family = share_video_to_chat` - `share_video_to_chat_cnt`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Internal Share Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:share_video_to_chat_cnt` (type: `base_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: internal share days per user
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `share_video_to_chat_cnt`
- Meaning: 人均分享视频到会话活跃天数
- Key filters:
  - `event_family = share_video_to_chat` - `share_video_to_chat_cnt`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Internal Share PV/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:share_video_to_chat_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: internal share count per user
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `share_video_to_chat_cnt`
- Meaning: 人均分享视频到会话次数
- Key filters:
  - `event_family = share_video_to_chat` - `share_video_to_chat_cnt`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Like Message Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:like_message_cnt` (type: `base_days`)
- Denominator: `T0:app_id` (type: `action_days`)
- Description: like message days per days
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `like_message_cnt`
- Meaning: 点赞消息活跃天数占基准活跃天比例
- Key filters:
  - `event_family = like_message` - `like_message_cnt`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Like Message Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:like_message_cnt` (type: `base_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: like message days per user
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `like_message_cnt`
- Meaning: 人均点赞消息活跃天数
- Key filters:
  - `event_family = like_message` - `like_message_cnt`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Like Message PV/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:like_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: like message count per user
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `like_message_cnt`
- Meaning: 人均点赞消息次数
- Key filters:
  - `event_family = like_message` - `like_message_cnt`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: New Enter Chat PV/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:is_enter_chat_first_active` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: enter chat for the first time count per user
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `is_enter_chat_first_active`
- Meaning: 人均首次发生进入会话活跃的强度
- Key filters:
  - `event_family = enter_chat` - `enter_chat_cnt` / `enter_chat_ucnt`
  - `first_active = enter_chat` - first enter-chat activation slice
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - `New Send Message PV/User` / `New Enter Chat PV/User` 的“first active”字段仍需补充更细 trigger 说明

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: New Send Message PV/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:is_send_message_first_active` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message for the first time count per user
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `is_send_message_first_active`
- Meaning: 人均首次发生发送活跃的强度
- Key filters:
  - `event_family = send_message` - `send_message_cnt`
  - `first_active = send_message` - first send-message activation slice
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - `New Send Message PV/User` / `New Enter Chat PV/User` 的“first active”字段仍需补充更细 trigger 说明

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Message Conversation Cnt/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:send_message_chat_ucnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: number of conversations that user sends message per user
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `send_message_chat_ucnt`
- Meaning: 人均发生发送行为的会话数
- Key filters:
  - `event_family = send_message` - `send_message_cnt`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Message Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:send_message_cnt` (type: `base_days`)
- Denominator: `T0:app_id` (type: `action_days`)
- Description: send message days per days
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `send_message_cnt`
- Meaning: 发送消息活跃天数占基准活跃天比例
- Key filters:
  - `event_family = send_message` - `send_message_cnt`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Message Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:send_message_cnt` (type: `base_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message days per user
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `send_message_cnt`
- Meaning: 人均发送消息活跃天数
- Key filters:
  - `event_family = send_message` - `send_message_cnt`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Message PV/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:send_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message count per user
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `send_message_cnt`
- Meaning: 人均发送消息次数
- Key filters:
  - `event_family = send_message` - `send_message_cnt`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Stay Duration/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `T0:chat_stay_duration` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: stay duration in chat per user
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Field family: `chat_stay_duration`
- Meaning: 人均聊天页停留时长
- Key filters:
  - `event_family = chat_stay_duration` - `chat_stay_duration`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - `chat_stay_duration` 已提升为 event family canonical page，但还未拿到更细的 ByteIO raw event 名

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: User (3399674)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7018203
- Digest: [[digests/digest_7018203_dm_core]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7018203.json`
- Key filters:
  - `send_message` - `send_message_cnt`
  - `like_message` - `like_message_cnt`
  - `enter_chat` - `enter_chat_cnt`
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->
