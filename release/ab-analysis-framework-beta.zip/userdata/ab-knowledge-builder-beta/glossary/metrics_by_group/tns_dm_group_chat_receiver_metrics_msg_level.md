# Metrics By Group | TnS DM Group Chat Receiver Metrics - Msg Level

group_id: 7043981
canonical_name: TnS DM Group Chat Receiver Metrics - Msg Level
tags: metric-group, dm
wiki_digests: [[digests/digest_7043981_tns_dm_group_chat_receiver_metrics_msg_level]]
wiki_matrices: [[digests/event_metric_matrix_7043981_tns_dm_group_chat_receiver_metrics_msg_level]]

## Metrics

- report_rate
  - metric_id: `916553`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_rate__id_916553.md`
- report_violate_rate_groupmsg
  - metric_id: `916554`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_violate_rate_groupmsg__id_916554.md`
- report_egregious_rate_groupmsg
  - metric_id: `916555`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_egregious_rate_groupmsg__id_916555.md`
- violation_rate
  - metric_id: `916556`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_violation_rate__id_916556.md`
- egregious_rate
  - metric_id: `916557`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_egregious_rate__id_916557.md`

## Auto Definitions (Excerpt)

### Metric: egregious_rate (916557)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043981
- Digest: [[digests/digest_7043981_tns_dm_group_chat_receiver_metrics_msg_level]]
- Numerator: `T2:report_egregrious_group_msg_cnt_2` (type: `pv`)
- Denominator: `T2:group_msg_cnt_2` (type: `pv`)
- Description: Reported Egregious Rate % at Msg Level for Group Chat. Denominator: Group Msg Count. Use this to describe egregious leakage for group chat. report_egregious_groupmsg_cnt / group_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043981.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-receiver-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_egregious_rate_groupmsg (916555)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043981
- Digest: [[digests/digest_7043981_tns_dm_group_chat_receiver_metrics_msg_level]]
- Numerator: `T2:report_egregrious_group_msg_cnt_2` (type: `pv`)
- Denominator: `T2:report_group_msg_cnt_2` (type: `pv`)
- Description: Reported Egregious Rate % at Msg Level for Group Chat. Denominator: Reported Group Msg Count. report_egregious_groupmsg_cnt / report_group_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043981.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-receiver-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_rate (916553)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043981
- Digest: [[digests/digest_7043981_tns_dm_group_chat_receiver_metrics_msg_level]]
- Numerator: `T2:report_group_msg_cnt_2` (type: `pv`)
- Denominator: `T2:group_msg_cnt_2` (type: `pv`)
- Description: Report Rate % at Msg Level for Group Chat. report_group_msg_cnt / group_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043981.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-receiver-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_violate_rate_groupmsg (916554)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043981
- Digest: [[digests/digest_7043981_tns_dm_group_chat_receiver_metrics_msg_level]]
- Numerator: `T2:report_violate_group_msg_cnt_2` (type: `pv`)
- Denominator: `T2:report_group_msg_cnt_2` (type: `pv`)
- Description: Reported Violation Rate % at Msg Level for Group Chat. Denominator: Reported Group Msg Count. report_violated_group_msg_cnt / report_group_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043981.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-receiver-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: violation_rate (916556)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043981
- Digest: [[digests/digest_7043981_tns_dm_group_chat_receiver_metrics_msg_level]]
- Numerator: `T2:report_violate_group_msg_cnt_2` (type: `pv`)
- Denominator: `T2:group_msg_cnt_2` (type: `pv`)
- Description: Reported Violation Rate % at Msg Level for Group Chat. Denominator: Group Msg Count. Use this to describe violation leakage for group chat. report_violated_group_msg_cnt / group_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043981.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-receiver-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->
