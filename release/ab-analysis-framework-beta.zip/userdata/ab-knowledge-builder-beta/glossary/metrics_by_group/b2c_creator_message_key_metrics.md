# Metrics By Group | [B2C] Creator Message Key Metrics

group_id: 7049566
canonical_name: [B2C] Creator Message Key Metrics
tags: metric-group, dm
wiki_digests: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
wiki_matrices: [[digests/event_metric_matrix_7049566_b2c_creator_message_key_metrics]]

## Metrics

- base_user
  - metric_id: `3160691`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_3160691.md`
- Creator Conv DM 2-way penetration
  - metric_id: `3160692`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_creator_conv_dm_2_way_penetration__id_3160692.md`
- Creator Conv DM penetration
  - metric_id: `3160693`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_creator_conv_dm_penetration__id_3160693.md`
- C2Cr DM penetration
  - metric_id: `3160694`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2cr_dm_penetration__id_3160694.md`
- C2Cr DM pv / DAU
  - metric_id: `3160695`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2cr_dm_pv_dau__id_3160695.md`
- C2Cr DM pair / DAU
  - metric_id: `3160696`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2cr_dm_pair_dau__id_3160696.md`
- C2Cr DM pair / uv
  - metric_id: `3160697`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2cr_dm_pair_uv__id_3160697.md`
- C2Cr conv 1h response rate
  - metric_id: `3160698`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2cr_conv_1h_response_rate__id_3160698.md`
- C2Cr conv 7h response rate
  - metric_id: `3160699`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2cr_conv_7h_response_rate__id_3160699.md`
- C2Cr conv 24h response rate
  - metric_id: `3160700`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2cr_conv_24h_response_rate__id_3160700.md`
- Cr2C DM penetration
  - metric_id: `3160701`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_dm_penetration__id_3160701.md`
- Cr2C DM pv / DAU
  - metric_id: `3160702`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_dm_pv_dau__id_3160702.md`
- Cr2C DM pair / DAU
  - metric_id: `3160703`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_dm_pair_dau__id_3160703.md`
- Cr2C DM pair / uv
  - metric_id: `3160704`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_dm_pair_uv__id_3160704.md`
- Cr2C conv 1h response rate
  - metric_id: `3160705`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_conv_1h_response_rate__id_3160705.md`
- Cr2C conv 7h response rate
  - metric_id: `3160706`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_conv_7h_response_rate__id_3160706.md`
- Cr2C conv 24h response rate
  - metric_id: `3160707`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_conv_24h_response_rate__id_3160707.md`
- Cr2C MuF DM penetration
  - metric_id: `3160708`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_muf_dm_penetration__id_3160708.md`
- Cr2C MuF DM pv / DAU
  - metric_id: `3160709`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_muf_dm_pv_dau__id_3160709.md`
- Cr2C MuF DM pair / DAU
  - metric_id: `3160710`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_muf_dm_pair_dau__id_3160710.md`
- Cr2C MuF DM pair / uv
  - metric_id: `3160711`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_muf_dm_pair_uv__id_3160711.md`
- Cr2C MuF conv 1h response rate
  - metric_id: `3160712`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_muf_conv_1h_response_rate__id_3160712.md`
- Cr2C MuF conv 7h response rate
  - metric_id: `3160713`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_muf_conv_7h_response_rate__id_3160713.md`
- Cr2C MuF conv 24h response rate
  - metric_id: `3160714`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_muf_conv_24h_response_rate__id_3160714.md`
- Cr2C Non MuF DM penetration
  - metric_id: `3160715`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_non_muf_dm_penetration__id_3160715.md`
- Cr2C Non MuF DM pv / DAU
  - metric_id: `3160716`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_non_muf_dm_pv_dau__id_3160716.md`
- Cr2C Non MuF DM pair / DAU
  - metric_id: `3160717`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_non_muf_dm_pair_dau__id_3160717.md`
- Cr2C Non MuF DM pair / uv
  - metric_id: `3160718`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_non_muf_dm_pair_uv__id_3160718.md`
- Cr2C Non MuF conv 1h response rate
  - metric_id: `3160719`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_non_muf_conv_1h_response_rate__id_3160719.md`
- Cr2C Non MuF conv 7h response rate
  - metric_id: `3160720`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_non_muf_conv_7h_response_rate__id_3160720.md`
- Cr2C Non MuF conv 24h response rate
  - metric_id: `3160721`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_non_muf_conv_24h_response_rate__id_3160721.md`
- Creator Publish penetration
  - metric_id: `3160722`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_creator_publish_penetration__id_3160722.md`
- Cr2C DM Report rate
  - metric_id: `3160723`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_dm_report_rate__id_3160723.md`
- C2Cr DM Report Message rate
  - metric_id: `3160724`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2cr_dm_report_message_rate__id_3160724.md`
- Creator Conv DM Report Message rate
  - metric_id: `3160725`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_creator_conv_dm_report_message_rate__id_3160725.md`
- Cr2C DM Violative Message rate
  - metric_id: `3160726`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_dm_violative_message_rate__id_3160726.md`
- C2Cr DM Violative Message rate
  - metric_id: `3160727`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2cr_dm_violative_message_rate__id_3160727.md`
- Creator Conv DM Violative Message rate
  - metric_id: `3160728`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_creator_conv_dm_violative_message_rate__id_3160728.md`
- Creator Conv DM 2+Round penetration
  - metric_id: `3160729`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_creator_conv_dm_2_round_penetration__id_3160729.md`
- Creator Conv DM 2+Round pair / au
  - metric_id: `3160730`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_creator_conv_dm_2_round_pair_au__id_3160730.md`
- Creator Conv DM 2-way Days / Days
  - metric_id: `3160731`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_creator_conv_dm_2_way_days_days__id_3160731.md`
- Creator Conv DM Days / Days
  - metric_id: `3160732`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_creator_conv_dm_days_days__id_3160732.md`
- C2Cr DM Days / Days
  - metric_id: `3160733`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2cr_dm_days_days__id_3160733.md`
- Cr2C DM Days / Days
  - metric_id: `3160734`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_dm_days_days__id_3160734.md`
- Cr2C MuF DM Days / Days
  - metric_id: `3160735`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_muf_dm_days_days__id_3160735.md`
- Cr2C Non MuF DM Days / Days
  - metric_id: `3160736`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_non_muf_dm_days_days__id_3160736.md`
- Creator Publish Days / Days
  - metric_id: `3160737`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_creator_publish_days_days__id_3160737.md`
- Creator Conv DM 2+Round Days / Days
  - metric_id: `3160738`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_creator_conv_dm_2_round_days_days__id_3160738.md`
- 【含AI】创作者双向私信 Days / Days
  - metric_id: `3160739`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_ai_days_days__id_3160739.md`
- 【含AI】*
  - metric_id: `3160740`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_ai__id_3160740.md`
- Cr2C 陌生人会话中AI 回复占比
  - metric_id: `3160741`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cr2c_ai__id_3160741.md`
- 【含AI】Creator Conv DM 2+Round penetration
  - metric_id: `3160742`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_ai_creator_conv_dm_2_round_penetration__id_3160742.md`
- 【含AI】Creator Conv DM 2+Round pair / au
  - metric_id: `3160743`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_ai_creator_conv_dm_2_round_pair_au__id_3160743.md`
- 【含AI】Creator Conv DM 2+Round Days / Days
  - metric_id: `3160744`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_ai_creator_conv_dm_2_round_days_days__id_3160744.md`

## Auto Definitions (Excerpt)

### Metric: 【含AI】*
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T10:include_ai_reply_dual_pair_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Creator双向私信会话渗透
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: 【含AI】Creator Conv DM 2+Round Days / Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T10:include_ai_reply_engaged_chat_ucnt` (type: `action_days`)
- Denominator: `T5:base_action_days` (type: `action_days`)
- Description: 【含AI】Creator对话超过两轮的 Days / Active Days： 对话超过两轮：用户对创作者发至少一条消息 + 创作者回复用户至少一条消息+ 用户再次对创作者发至少一条消息
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: 【含AI】Creator Conv DM 2+Round pair / au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T10:include_ai_reply_engaged_chat_ucnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 【含AI】Creator对话超过两轮的人均pair： 对话超过两轮：用户对创作者发至少一条消息 + 创作者回复用户至少一条消息+ 用户再次对创作者发至少一条消息
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: 【含AI】Creator Conv DM 2+Round penetration
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T10:include_ai_reply_engaged_chat_ucnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 【含AI】Creator对话超过两轮的渗透： 对话超过两轮：用户对创作者发至少一条消息 + 创作者回复用户至少一条消息+ 用户再次对创作者发至少一条消息
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Field family: `creator_ai_reply`
- Aggregation: `uv/base_user`
- Meaning: 含 AI 回复时 2+轮创作者会话渗透率
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: 【含AI】创作者双向私信 Days / Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T10:include_ai_reply_dual_pair_cnt` (type: `action_days`)
- Denominator: `T5:base_action_days` (type: `action_days`)
- Description: Creator双向私信会话 Days/Active Days
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: base_user (3160691)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2Cr conv 1h response rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T2:c2cr_message_responded_1h_chat_ucnt` (type: `pv`)
- Denominator: `T2:c2cr_send_or_like_message_chat_ucnt` (type: `pv`)
- Description: C2Cr会话1h回复率
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Field family: `creator_conv_response`
- Aggregation: `pv/pv`
- Meaning: 用户到创作者 1 小时响应率
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = c2cr` - consumer to creator
  - `response_window = 1h` - response-time slice
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2Cr conv 24h response rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T2:c2cr_message_responded_24h_chat_ucnt` (type: `pv`)
- Denominator: `T2:c2cr_send_or_like_message_chat_ucnt` (type: `pv`)
- Description: C2Cr会话24h回复率
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = c2cr` - consumer to creator
  - `response_window = 24h` - response-time slice
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2Cr conv 7h response rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T2:c2cr_message_responded_7h_chat_ucnt` (type: `pv`)
- Denominator: `T2:c2cr_send_or_like_message_chat_ucnt` (type: `pv`)
- Description: C2Cr会话7h回复率
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = c2cr` - consumer to creator
  - `response_window = 7h` - response-time slice
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2Cr DM Days / Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T1:c2cr_send_or_like_message_cnt` (type: `action_days`)
- Denominator: `T5:base_action_days` (type: `action_days`)
- Description: C2Cr私信 Days / Active Days
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = c2cr` - consumer to creator
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2Cr DM pair / DAU
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T1:c2cr_send_or_like_message_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: C2Cr人均私信pair数
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = c2cr` - consumer to creator
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2Cr DM pair / uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T1:c2cr_send_or_like_message_pair_cnt` (type: `pv`)
- Denominator: `T1:c2cr_send_or_like_message_pair_cnt` (type: `uv`)
- Description: C2Cr平均私信pair数
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = c2cr` - consumer to creator
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2Cr DM penetration
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T1:c2cr_send_or_like_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: C2Cr私信渗透
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = c2cr` - consumer to creator
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2Cr DM pv / DAU
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T1:c2cr_send_or_like_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: C2Cr人均私信频次
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = c2cr` - consumer to creator
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2Cr DM Report Message rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T1:c2cr_reported_msg_cnt` (type: `pv`)
- Denominator: `T5:send_message_by_private_cnt` (type: `pv`)
- Description: C给Cr发信息，C被举报。
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = c2cr` - consumer to creator
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2Cr DM Violative Message rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T1:c2cr_tcs_reported_violated_msg_cnt_mul_1m` (type: `pv`)
- Denominator: `T5:send_message_by_private_cnt` (type: `pv`)
- Description: C给Cr发信息，C违规。
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = c2cr` - consumer to creator
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cr2C 陌生人会话中AI 回复占比
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T10:cr2c_ai_reply_send_message_chat_ucnt` (type: `pv`)
- Denominator: `T10:cr2c_include_ai_reply_stranger_send_message_chat_ucnt` (type: `pv`)
- Description: AI 回复过的会话数 /（AI+创作者）回复的会话总数，分母仅统计创作者设置的 AI可见范围的会话（relation_tag = 0/4），看AI 能帮创作者回复多少消息
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = cr2c` - creator to consumer
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cr2C conv 1h response rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T2:cr2c_message_responded_1h_chat_ucnt` (type: `pv`)
- Denominator: `T2:cr2c_send_or_like_message_chat_ucnt` (type: `pv`)
- Description: Cr2C会话1h回复率
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Field family: `creator_conv_response`
- Aggregation: `pv/pv`
- Meaning: 创作者到用户 1 小时响应率
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = cr2c` - creator to consumer
  - `response_window = 1h` - response-time slice
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cr2C conv 24h response rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T2:cr2c_message_responded_24h_chat_ucnt` (type: `pv`)
- Denominator: `T2:cr2c_send_or_like_message_chat_ucnt` (type: `pv`)
- Description: Cr2C会话24h回复率
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = cr2c` - creator to consumer
  - `response_window = 24h` - response-time slice
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cr2C conv 7h response rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T2:cr2c_message_responded_7h_chat_ucnt` (type: `pv`)
- Denominator: `T2:cr2c_send_or_like_message_chat_ucnt` (type: `pv`)
- Description: Cr2C会话7h回复率
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = cr2c` - creator to consumer
  - `response_window = 7h` - response-time slice
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cr2C DM Days / Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T1:cr2c_send_or_like_message_cnt` (type: `action_days`)
- Denominator: `T5:base_action_days` (type: `action_days`)
- Description: Cr2C私信 Days / Active Days
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = cr2c` - creator to consumer
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cr2C DM pair / DAU
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T1:cr2c_send_or_like_message_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Cr2C人均私信pair数
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = cr2c` - creator to consumer
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cr2C DM pair / uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T1:cr2c_send_or_like_message_pair_cnt` (type: `pv`)
- Denominator: `T1:cr2c_send_or_like_message_pair_cnt` (type: `uv`)
- Description: Cr2C平均私信pair数
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = cr2c` - creator to consumer
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cr2C DM penetration
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T1:cr2c_send_or_like_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Cr2C私信渗透
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = cr2c` - creator to consumer
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cr2C DM pv / DAU
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T1:cr2c_send_or_like_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Cr2C人均私信频次
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = cr2c` - creator to consumer
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cr2C DM Report rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T1:cr2c_reported_msg_cnt` (type: `pv`)
- Denominator: `T5:send_message_by_private_cnt` (type: `pv`)
- Description: Cr给C发信息， Cr被举报。
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = cr2c` - creator to consumer
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cr2C DM Violative Message rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T1:cr2c_tcs_reported_violated_msg_cnt_mul_1m` (type: `pv`)
- Denominator: `T5:send_message_by_private_cnt` (type: `pv`)
- Description: Cr给C发信息，Cr违规 。
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = cr2c` - creator to consumer
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cr2C MuF conv 1h response rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T2:cr2c_muf_message_responded_1h_chat_ucnt` (type: `pv`)
- Denominator: `T2:cr2c_muf_send_or_like_message_chat_ucnt` (type: `pv`)
- Description: Cr2C会话1h回复率(MuF)
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = cr2c` - creator to consumer
  - `relationship_bucket = muf` - mutual-follow slice
  - `response_window = 1h` - response-time slice
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cr2C MuF conv 24h response rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T2:cr2c_muf_message_responded_24h_chat_ucnt` (type: `pv`)
- Denominator: `T2:cr2c_muf_send_or_like_message_chat_ucnt` (type: `pv`)
- Description: Cr2C会话24h回复率(MuF)
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = cr2c` - creator to consumer
  - `relationship_bucket = muf` - mutual-follow slice
  - `response_window = 24h` - response-time slice
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cr2C MuF conv 7h response rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049566
- Digest: [[digests/digest_7049566_b2c_creator_message_key_metrics]]
- Numerator: `T2:cr2c_muf_message_responded_7h_chat_ucnt` (type: `pv`)
- Denominator: `T2:cr2c_muf_send_or_like_message_chat_ucnt` (type: `pv`)
- Description: Cr2C会话7h回复率(MuF)
- Provenance: `raw/libra/libra_metric_group_7049566.json`
- Key filters:
  - `is_creator = true` - creator conversation slice
  - `direction = cr2c` - creator to consumer
  - `relationship_bucket = muf` - mutual-follow slice
  - `response_window = 7h` - response-time slice
- Source tables (from digest):
  - [[tables/table_musically-dm-social-im-cr2c-user-di]]
  - [[tables/table_musically-dm-social-im-cr2c-message-responded-user-di]]
  - [[tables/table_musically-mds-fact-user-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-dm-social-im-creator-user-di]]
  - [[tables/table_musically-mds-dim-user-social-ext]]
  - [[tables/table_musically-dim-uint-im-cr2c-user]]

<!-- AUTO-GENERATED:metric_fields:end -->

> truncated: 24 more metrics omitted from the auto excerpt.
