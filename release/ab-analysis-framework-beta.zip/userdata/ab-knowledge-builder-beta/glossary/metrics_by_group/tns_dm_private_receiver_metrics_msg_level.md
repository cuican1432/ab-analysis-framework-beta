# Metrics By Group | TnS DM Private Receiver Metrics - Msg Level

group_id: 7043983
canonical_name: TnS DM Private Receiver Metrics - Msg Level
tags: metric-group, dm
wiki_digests: [[digests/digest_7043983_tns_dm_private_receiver_metrics_msg_level]]
wiki_matrices: [[digests/event_metric_matrix_7043983_tns_dm_private_receiver_metrics_msg_level]]

## Metrics

- report_rate
  - metric_id: `916548`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_rate__id_916548.md`
- report_violate_rate_msg
  - metric_id: `916549`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_violate_rate_msg__id_916549.md`
- report_egregious_rate_msg
  - metric_id: `916550`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_egregious_rate_msg__id_916550.md`
- violate_rate
  - metric_id: `916551`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_violate_rate__id_916551.md`
- egregious_rate
  - metric_id: `916552`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_egregious_rate__id_916552.md`

## Auto Definitions (Excerpt)

### Metric: egregious_rate (916552)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043983
- Digest: [[digests/digest_7043983_tns_dm_private_receiver_metrics_msg_level]]
- Numerator: `T2:report_egregrious_private_msg_cnt_2` (type: `pv`)
- Denominator: `T2:private_msg_cnt_2` (type: `pv`)
- Description: Report Egregious Rate % at Msg Level. Denominator: private msg. Use this for describing egregious message leakage. report_egregious_msg_cnt / private_msg
- Provenance: `raw/libra/libra_metric_group_7043983.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-receiver-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_egregious_rate_msg (916550)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043983
- Digest: [[digests/digest_7043983_tns_dm_private_receiver_metrics_msg_level]]
- Numerator: `T2:report_egregrious_private_msg_cnt_2` (type: `pv`)
- Denominator: `T2:report_private_msg_cnt_2` (type: `pv`)
- Description: Report Egregious Rate % at Msg Level. Denominator: reported msg. report_egregious_msg_cnt /report_private_msg
- Provenance: `raw/libra/libra_metric_group_7043983.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-receiver-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_rate (916548)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043983
- Digest: [[digests/digest_7043983_tns_dm_private_receiver_metrics_msg_level]]
- Numerator: `T2:report_private_msg_cnt_2` (type: `pv`)
- Denominator: `T2:private_msg_cnt_2` (type: `pv`)
- Description: Report Rate % at Msg Level. report_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043983.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-receiver-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_violate_rate_msg (916549)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043983
- Digest: [[digests/digest_7043983_tns_dm_private_receiver_metrics_msg_level]]
- Numerator: `T2:report_violate_private_msg_cnt_2` (type: `pv`)
- Denominator: `T2:report_private_msg_cnt_2` (type: `pv`)
- Description: Report Violation Rate % at Msg Level. Denominator: reported msg. report_violate_msg_cnt /report_private_msg
- Provenance: `raw/libra/libra_metric_group_7043983.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-receiver-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: violate_rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043983
- Digest: [[digests/digest_7043983_tns_dm_private_receiver_metrics_msg_level]]
- Numerator: `T2:report_violate_private_msg_cnt_2` (type: `pv`)
- Denominator: `T2:private_msg_cnt_2` (type: `pv`)
- Description: Report Violation Rate % at Msg Level. Denominator: private msg. Use this for describing violation message leakage. report_violate_msg_cnt / private_msg
- Provenance: `raw/libra/libra_metric_group_7043983.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-receiver-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->
