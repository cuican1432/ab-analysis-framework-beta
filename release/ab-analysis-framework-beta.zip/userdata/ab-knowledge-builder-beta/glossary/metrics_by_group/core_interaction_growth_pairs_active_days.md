# Metrics By Group | Core Interaction Growth Pairs Active Days

group_id: 7049143
canonical_name: Core Interaction Growth Pairs Active Days
tags: metric-group, dm
wiki_digests: [[digests/digest_7049143_core_interaction_growth_pairs_active_days]]
wiki_matrices: [[digests/event_metric_matrix_7049143_core_interaction_growth_pairs_active_days]]

## Metrics

- base_user
  - metric_id: `1532131`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_1532131.md`
- Core interaction Pair Active Days
  - metric_id: `1532132`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_pair_active_days__id_1532132.md`
- Core interaction New Pair Active Days
  - metric_id: `1532133`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_new_pair_active_days__id_1532133.md`
- Core interaction Retained Pair Active Days
  - metric_id: `1532134`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_retained_pair_active_days__id_1532134.md`
- Core interaction Resurrected Pair Active Days
  - metric_id: `1532135`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_resurrected_pair_active_days__id_1532135.md`

## Auto Definitions (Excerpt)

### Metric: base_user (1532131)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049143
- Digest: [[digests/digest_7049143_core_interaction_growth_pairs_active_days]]
- Numerator: `user` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7049143.json`
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Core-interaction growth-pairs activeness metrics are confirmed at pair aggregate table level.
  - Raw-event contract is not separated from the pair aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction New Pair Active Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049143
- Digest: [[digests/digest_7049143_core_interaction_growth_pairs_active_days]]
- Numerator: `T2:core_interactive_muf_new_pair_cnt` (type: `cross_days_action`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Core interaction New Pair Active Days
- Provenance: `raw/libra/libra_metric_group_7049143.json`
- Aggregation: cross_days_action / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Core-interaction growth-pairs activeness metrics are confirmed at pair aggregate table level.
  - Raw-event contract is not separated from the pair aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction Pair Active Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049143
- Digest: [[digests/digest_7049143_core_interaction_growth_pairs_active_days]]
- Numerator: `T2:core_interactive_muf_pair_cnt` (type: `cross_days_action`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Core interaction Pair Active Days
- Provenance: `raw/libra/libra_metric_group_7049143.json`
- Aggregation: cross_days_action / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Core-interaction growth-pairs activeness metrics are confirmed at pair aggregate table level.
  - Raw-event contract is not separated from the pair aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction Resurrected Pair Active Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049143
- Digest: [[digests/digest_7049143_core_interaction_growth_pairs_active_days]]
- Numerator: `T2:core_interactive_muf_resurrected_pair_cnt` (type: `cross_days_action`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Core interaction Resurrected Pair Active Days
- Provenance: `raw/libra/libra_metric_group_7049143.json`
- Aggregation: cross_days_action / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Core-interaction growth-pairs activeness metrics are confirmed at pair aggregate table level.
  - Raw-event contract is not separated from the pair aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction Retained Pair Active Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049143
- Digest: [[digests/digest_7049143_core_interaction_growth_pairs_active_days]]
- Numerator: `T2:core_interactive_muf_retained_pair_cnt` (type: `cross_days_action`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Core interaction Retained Pair Active Days
- Provenance: `raw/libra/libra_metric_group_7049143.json`
- Aggregation: cross_days_action / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Core-interaction growth-pairs activeness metrics are confirmed at pair aggregate table level.
  - Raw-event contract is not separated from the pair aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->
