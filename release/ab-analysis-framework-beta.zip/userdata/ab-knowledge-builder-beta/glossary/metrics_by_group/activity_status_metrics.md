# Metrics By Group | Activity Status Metrics

group_id: 7041665
canonical_name: Activity Status Metrics
tags: metric-group, dm
wiki_digests: [[digests/digest_7041665_activity_status_metrics]]
wiki_matrices: [[digests/event_metric_matrix_7041665_activity_status_metrics]]

## Metrics

- base_user
  - metric_id: `702611`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_702611.md`
- Show pv / Dau
  - metric_id: `702612`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_show_pv_dau__id_702612.md`
- Click pv / Dau
  - metric_id: `702613`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_pv_dau__id_702613.md`
- Inbox top show pv / Dau
  - metric_id: `702614`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_top_show_pv_dau__id_702614.md`
- Inbox top click pv / Dau
  - metric_id: `702615`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_top_click_pv_dau__id_702615.md`
- Inbox top ctr
  - metric_id: `702616`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_top_ctr__id_702616.md`
- Chat cell show pv / Dau
  - metric_id: `702617`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_chat_cell_show_pv_dau__id_702617.md`
- Chat cell click pv / Dau
  - metric_id: `702618`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_chat_cell_click_pv_dau__id_702618.md`
- Chat cell ctr
  - metric_id: `702619`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_chat_cell_ctr__id_702619.md`
- Share panel show pv / Dau
  - metric_id: `702620`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_panel_show_pv_dau__id_702620.md`
- Share panel click pv / Dau
  - metric_id: `702621`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_panel_click_pv_dau__id_702621.md`
- Share panel ctr
  - metric_id: `702622`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_panel_ctr__id_702622.md`
- Long press panel show pv / Dau
  - metric_id: `702623`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_panel_show_pv_dau__id_702623.md`
- Long press panel click pv / Dau
  - metric_id: `702624`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_panel_click_pv_dau__id_702624.md`
- Long press panel ctr
  - metric_id: `702625`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_panel_ctr__id_702625.md`
- Friend online inner push show pv / Dau
  - metric_id: `702626`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_friend_online_inner_push_show_pv_dau__id_702626.md`
- Friend online inner push  click pv / Dau
  - metric_id: `702627`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_friend_online_inner_push_click_pv_dau__id_702627.md`
- Friend online inner push ctr
  - metric_id: `702628`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_friend_online_inner_push_ctr__id_702628.md`
- Cold start inner push show pv / Dau
  - metric_id: `702629`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cold_start_inner_push_show_pv_dau__id_702629.md`
- Cold start inner push  click pv / Dau
  - metric_id: `702630`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cold_start_inner_push_click_pv_dau__id_702630.md`
- Cold start inner push ctr
  - metric_id: `702631`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cold_start_inner_push_ctr__id_702631.md`
- Outer push show pv / Dau
  - metric_id: `702632`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_outer_push_show_pv_dau__id_702632.md`
- Outer push  click pv / Dau
  - metric_id: `702633`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_outer_push_click_pv_dau__id_702633.md`
- Outer push ctr
  - metric_id: `702634`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_outer_push_ctr__id_702634.md`

## Auto Definitions (Excerpt)

### Metric: base_user (702611)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `user` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Chat cell click pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_chat_cell_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 聊天框在线状态点击人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Chat cell ctr
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_chat_cell_click_cnt` (type: `pv`)
- Denominator: `T1:activity_status_chat_cell_show_cnt` (type: `pv`)
- Description: 聊天框在线状态点击率
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / pv
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Chat cell show pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_chat_cell_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 聊天框在线状态展现人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Click pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 在线状态点击人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cold start inner push  click pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_coldstart_push_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 冷启好友在线push点击人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cold start inner push ctr
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_coldstart_push_click_cnt` (type: `pv`)
- Denominator: `T1:activity_status_coldstart_push_show_cnt` (type: `pv`)
- Description: 冷启好友在线push点击率
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / pv
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cold start inner push show pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_coldstart_push_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 冷启好友在线push展现人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Friend online inner push  click pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_online_push_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 好友上线push点击人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Friend online inner push ctr
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_online_push_click_cnt` (type: `pv`)
- Denominator: `T1:activity_status_online_push_show_cnt` (type: `pv`)
- Description: 好友上线push点击率
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / pv
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Friend online inner push show pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_online_push_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 好友上线push展现人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox top click pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_inbox_top_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox天窗在线状态点击人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox top ctr
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_inbox_top_click_cnt` (type: `pv`)
- Denominator: `T1:activity_status_inbox_top_show_cnt` (type: `pv`)
- Description: inbox天窗在线状态点击率
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / pv
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox top show pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_inbox_top_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox天窗在线状态展现人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Long press panel click pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_long_press_panel_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 长按面板在线状态点击人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Long press panel ctr
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_long_press_panel_click_cnt` (type: `pv`)
- Denominator: `T1:activity_status_long_press_panel_show_cnt` (type: `pv`)
- Description: 长按面板在线状态点击率
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / pv
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Long press panel show pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_long_press_panel_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 长按面板在线状态展现人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Outer push  click pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_outer_push_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 站外push点击人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Outer push ctr
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_outer_push_click_cnt` (type: `pv`)
- Denominator: `T1:receive_activity_status_outer_push_cnt` (type: `pv`)
- Description: 站外push点击率
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / pv
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Outer push show pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:receive_activity_status_outer_push_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 站外push展现人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Share panel click pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_share_panel_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 分享面板在线状态点击人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Share panel ctr
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_share_panel_click_cnt` (type: `pv`)
- Denominator: `T1:activity_status_share_panel_show_cnt` (type: `pv`)
- Description: 分享面板在线状态 点击率
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / pv
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Share panel show pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_share_panel_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 分享面板在线状态展现人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Show pv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041665
- Digest: [[digests/digest_7041665_activity_status_metrics]]
- Numerator: `T1:activity_status_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 在线状态展现人均次数
- Provenance: `raw/libra/libra_metric_group_7041665.json`
- Aggregation: pv / base_user
- Key filters:
  - `surface=inbox_top` - 识别顶部入口
  - `surface=chat_cell` - 识别会话卡片位置
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - 若要提升质量，需要继续向更底层 surface event / params tracing 推进

<!-- AUTO-GENERATED:metric_fields:end -->
