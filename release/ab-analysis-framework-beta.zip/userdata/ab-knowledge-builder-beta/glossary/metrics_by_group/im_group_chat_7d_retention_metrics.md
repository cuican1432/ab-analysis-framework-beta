# Metrics By Group | [IM] Group Chat 7d Retention metrics

group_id: 7049633
canonical_name: [IM] Group Chat 7d Retention metrics
tags: metric-group, dm
wiki_digests: [[digests/digest_7049633_dm_group_chat_7d_retention]]
wiki_matrices: [[digests/event_metric_matrix_7049633_dm_group_chat_7d_retention]]

## Metrics

- base_user
  - metric_id: `2780332`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_2780332.md`
- 7d retention
  - metric_id: `2780333`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_7d_retention__id_2780333.md`

## Auto Definitions (Excerpt)

### Metric: 7d retention (2780333)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049633
- Digest: [[digests/digest_7049633_dm_group_chat_7d_retention]]
- Numerator: `T2:new_group_chat_ret_7d` (type: `pv`)
- Denominator: `T2:new_group_chat` (type: `pv`)
- Description: 7d retention
- Provenance: `raw/libra/libra_metric_group_7049633.json`
- Field family: `group_chat_retention_7d_core`
- Aggregation: `pv/pv`
- Meaning: 全量新建群在 7d 窗口后的留存率
- Key filters:
  - `7d` - 指定中窗口留存
  - cohort scope - 本组面向全量新建群 cohort
  - numerator / denominator pair - 拆解 cohort 创建与 survival 变化
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-7d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-7d]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: base_user (2780332)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049633
- Digest: [[digests/digest_7049633_dm_group_chat_7d_retention]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7049633.json`
- Key filters:
  - `7d` - 指定中窗口留存
  - cohort scope - 本组面向全量新建群 cohort
  - numerator / denominator pair - 拆解 cohort 创建与 survival 变化
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-7d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-7d]]

<!-- AUTO-GENERATED:metric_fields:end -->
