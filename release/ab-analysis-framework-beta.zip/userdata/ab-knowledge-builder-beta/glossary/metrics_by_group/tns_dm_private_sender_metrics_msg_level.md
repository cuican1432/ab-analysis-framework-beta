# Metrics By Group | TnS DM Private Sender Metrics - Msg Level

group_id: 7043982
canonical_name: TnS DM Private Sender Metrics - Msg Level
tags: metric-group, dm
wiki_digests: [[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]
wiki_matrices: [[digests/event_metric_matrix_7043982_tns_dm_private_sender_metrics_msg_level]]

## Metrics

- report_rate
  - metric_id: `916496`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_rate__id_916496.md`
- egregious_rate
  - metric_id: `916497`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_egregious_rate__id_916497.md`
- violation_rate
  - metric_id: `916498`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_violation_rate__id_916498.md`
- ban_rate_msg
  - metric_id: `916499`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_ban_rate_msg__id_916499.md`
- notice_rate_msg
  - metric_id: `916500`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notice_rate_msg__id_916500.md`
- feedback_rate_msg
  - metric_id: `916501`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_rate_msg__id_916501.md`
- feedback_success_rate_msg
  - metric_id: `916502`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_success_rate_msg__id_916502.md`
- feedback_appeal_rate_msg
  - metric_id: `916503`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_appeal_rate_msg__id_916503.md`
- feedback_appeal_success_rate_msg
  - metric_id: `916504`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_appeal_success_rate_msg__id_916504.md`
- report_violate_rate_msg
  - metric_id: `916505`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_violate_rate_msg__id_916505.md`
- report_egregious_rate_msg
  - metric_id: `916506`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_egregious_rate_msg__id_916506.md`
- report_appeal_rate_msg
  - metric_id: `916507`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_appeal_rate_msg__id_916507.md`
- report_appeal_success_rate_msg
  - metric_id: `916508`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_appeal_success_rate_msg__id_916508.md`
- report_appeal_egregious_rate_msg
  - metric_id: `916509`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_appeal_egregious_rate_msg__id_916509.md`

## Auto Definitions (Excerpt)

### Metric: ban_rate_msg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043982
- Digest: [[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]
- Numerator: `T1:ban_private_msg_cnt` (type: `pv`)
- Denominator: `T1:private_msg_cnt` (type: `pv`)
- Description: Ban Rate % at Msg Level. ban_msg_cnt / msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043982.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: egregious_rate (916497)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043982
- Digest: [[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]
- Numerator: `T1:report_egregious_private_msg_cnt` (type: `pv`)
- Denominator: `T1:private_msg_cnt` (type: `pv`)
- Description: Report Egregious Rate %. Denominator: private_msg_cnt. User this metric to describe Egregious Leakage. report_egregious_private_msg_cnt / private_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043982.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_appeal_rate_msg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043982
- Digest: [[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]
- Numerator: `T1:feedback_appeal_private_msg_cnt` (type: `pv`)
- Denominator: `T1:feedback_private_msg_cnt` (type: `pv`)
- Description: Feedback Appeal Rate % at Msg Level, Denominator: feedback_private_msg_cnt. When users failed after feedback, they have option to appeal. feedback_appeal_msg_cnt / msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043982.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_appeal_success_rate_msg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043982
- Digest: [[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]
- Numerator: `T1:feedback_appeal_success_private_msg_cnt` (type: `pv`)
- Denominator: `T1:feedback_appeal_private_msg_cnt` (type: `pv`)
- Description: Feedback Appeal Success Rate % at Msg Level, Denominator: feedback_appeal_private_msg_cnt. When users failed after feedback, they have option to appeal. feedback_appeal_success_msg_cnt / msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043982.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_rate_msg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043982
- Digest: [[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]
- Numerator: `T1:feedback_private_msg_cnt` (type: `pv`)
- Denominator: `T1:ban_private_msg_cnt` (type: `pv`)
- Description: Feedback Rate % at Msg Level, Denominator: ban_private_msg_cnt. feedback_msg_cnt / ban_private_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043982.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_success_rate_msg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043982
- Digest: [[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]
- Numerator: `T1:feedback_success_private_msg_cnt` (type: `pv`)
- Denominator: `T1:feedback_private_msg_cnt` (type: `pv`)
- Description: Feedback Success Rate % at Msg Level, Denominator: feedback_private_msg_cnt. feedback_success_msg_cnt / feedback_private_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043982.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: notice_rate_msg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043982
- Digest: [[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]
- Numerator: `T1:notice_private_msg_cnt` (type: `pv`)
- Denominator: `T1:private_msg_cnt` (type: `pv`)
- Description: Notice Rate % at Msg Level. notice_msg_cnt / msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043982.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_appeal_egregious_rate_msg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043982
- Digest: [[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]
- Numerator: `T1:report_appeal_egregious_private_msg_cnt` (type: `pv`)
- Denominator: `T1:report_appeal_private_msg_cnt` (type: `pv`)
- Description: Report Appeal Egregious Rate %. Denominator: report_appeal_private_msg_cnt. Describe egregious among report appeal. report_appeal_egregious_msg_cnt / msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043982.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_appeal_rate_msg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043982
- Digest: [[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]
- Numerator: `T1:report_appeal_private_msg_cnt` (type: `pv`)
- Denominator: `T1:report_private_msg_cnt` (type: `pv`)
- Description: Report Appeal Rate %. Denominator: report_private_msg_cnt. . report_appeal_msg_cnt / report_private_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043982.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_appeal_success_rate_msg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043982
- Digest: [[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]
- Numerator: `T1:report_appeal_success_private_msg_cnt` (type: `pv`)
- Denominator: `T1:report_appeal_private_msg_cnt` (type: `pv`)
- Description: Report Appeal Success Rate %. Denominator: report_appeal_private_msg_cnt. . report_appeal_success_msg_cnt / report_appeal_private_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043982.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_egregious_rate_msg (916506)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043982
- Digest: [[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]
- Numerator: `T1:report_egregious_private_msg_cnt` (type: `pv`)
- Denominator: `T1:report_private_msg_cnt` (type: `pv`)
- Description: Report output Egregious rate %. Denominator: report_private_msg_cnt. report_egregious_msg_cnt / report_private_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043982.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_rate (916496)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043982
- Digest: [[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]
- Numerator: `T1:report_private_msg_cnt` (type: `pv`)
- Denominator: `T1:private_msg_cnt` (type: `pv`)
- Description: Report Rate % at Msg Level. report_msg_cnt / msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043982.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_violate_rate_msg (916505)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043982
- Digest: [[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]
- Numerator: `T1:report_violate_private_msg_cnt` (type: `pv`)
- Denominator: `T1:report_private_msg_cnt` (type: `pv`)
- Description: Report output violation rate % at Msg Level. Denominator: report_private_msg_cnt. report_violate_private_msg_cnt / report_private_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043982.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: violation_rate (916498)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043982
- Digest: [[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]
- Numerator: `T1:report_violate_private_msg_cnt` (type: `pv`)
- Denominator: `T1:private_msg_cnt` (type: `pv`)
- Description: Report Violation Rate %. Denominator: private_msg_cnt. User this metric to describe Violation Leakage. report_violation_private_msg_cnt / private_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043982.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->
