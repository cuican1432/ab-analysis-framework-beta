# Metrics By Group | [DM] MuF DM by Motivation

group_id: 7051462
canonical_name: [DM] MuF DM by Motivation
tags: metric-group, dm
wiki_digests: [[digests/digest_7051462_muf_dm_by_motivation]]
wiki_matrices: [[digests/event_metric_matrix_7051462_muf_dm_by_motivation]]

## Metrics

- MuF Active Chat Days/Days
  - metric_id: `3134259`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_active_chat_days_days__id_3134259.md`
- MuF Active Chat Days/User
  - metric_id: `3134260`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_active_chat_days_user__id_3134260.md`
- MuF Active Chat Pair/User
  - metric_id: `3134261`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_active_chat_pair_user__id_3134261.md`
- MuF Active Chat/User
  - metric_id: `3134262`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_active_chat_user__id_3134262.md`
- MuF Post Interaction Days/Days
  - metric_id: `3134263`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_post_interaction_days_days__id_3134263.md`
- MuF Post Interaction Days/User
  - metric_id: `3134264`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_post_interaction_days_user__id_3134264.md`
- MuF Post Interaction Pair/User
  - metric_id: `3134265`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_post_interaction_pair_user__id_3134265.md`
- MuF Post Interaction/User
  - metric_id: `3134266`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_post_interaction_user__id_3134266.md`
- MuF Share Days/Days
  - metric_id: `3134267`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_share_days_days__id_3134267.md`
- MuF Share Days/User
  - metric_id: `3134268`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_share_days_user__id_3134268.md`
- MuF Share Pair/User
  - metric_id: `3134269`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_share_pair_user__id_3134269.md`
- MuF Share/User
  - metric_id: `3134270`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_share_user__id_3134270.md`

## Auto Definitions (Excerpt)

### Metric: MuF Active Chat Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7051462
- Digest: [[digests/digest_7051462_muf_dm_by_motivation]]
- Numerator: `T1:is_first_motivate_active_chat` (type: `action_days`)
- Denominator: `T1:action_date` (type: `action_days`)
- Description: 首动机是主动聊天的用户渗透
- Provenance: `raw/libra/libra_metric_group_7051462.json`
- Key filters:
  - `bucket = active_chat` - [[events/event_send_message]] family
- Source tables (from digest):
  - `musically.app_abtest_social_im_motivate_di`
  - `musically.app_abtest_social_im_motivate_di_uid`
  - `musically.app_abtest_social_im_motivate_di_did`
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `Post Interaction` 已 canonical 化为 event family，但还未拿到更细的 ByteIO raw event 名
  - motivation label 选择逻辑（first message in session）还需要专门 field-lineage 页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: MuF Active Chat Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7051462
- Digest: [[digests/digest_7051462_muf_dm_by_motivation]]
- Numerator: `T1:is_first_motivate_active_chat` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: muf active chat days per user
- Provenance: `raw/libra/libra_metric_group_7051462.json`
- Key filters:
  - `bucket = active_chat` - [[events/event_send_message]] family
- Source tables (from digest):
  - `musically.app_abtest_social_im_motivate_di`
  - `musically.app_abtest_social_im_motivate_di_uid`
  - `musically.app_abtest_social_im_motivate_di_did`
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `Post Interaction` 已 canonical 化为 event family，但还未拿到更细的 ByteIO raw event 名
  - motivation label 选择逻辑（first message in session）还需要专门 field-lineage 页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: MuF Active Chat Pair/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7051462
- Digest: [[digests/digest_7051462_muf_dm_by_motivation]]
- Numerator: `T1:active_chat_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均主动聊天关系对
- Provenance: `raw/libra/libra_metric_group_7051462.json`
- Key filters:
  - `bucket = active_chat` - [[events/event_send_message]] family
- Source tables (from digest):
  - `musically.app_abtest_social_im_motivate_di`
  - `musically.app_abtest_social_im_motivate_di_uid`
  - `musically.app_abtest_social_im_motivate_di_did`
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `Post Interaction` 已 canonical 化为 event family，但还未拿到更细的 ByteIO raw event 名
  - motivation label 选择逻辑（first message in session）还需要专门 field-lineage 页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: MuF Active Chat/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7051462
- Digest: [[digests/digest_7051462_muf_dm_by_motivation]]
- Numerator: `T1:active_chat_send_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均主动聊天次数
- Provenance: `raw/libra/libra_metric_group_7051462.json`
- Key filters:
  - `bucket = active_chat` - [[events/event_send_message]] family
- Source tables (from digest):
  - `musically.app_abtest_social_im_motivate_di`
  - `musically.app_abtest_social_im_motivate_di_uid`
  - `musically.app_abtest_social_im_motivate_di_did`
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `Post Interaction` 已 canonical 化为 event family，但还未拿到更细的 ByteIO raw event 名
  - motivation label 选择逻辑（first message in session）还需要专门 field-lineage 页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: MuF Post Interaction Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7051462
- Digest: [[digests/digest_7051462_muf_dm_by_motivation]]
- Numerator: `T1:is_first_motivate_post_interact` (type: `action_days`)
- Denominator: `T1:action_date` (type: `action_days`)
- Description: 首动机是发文互动的用户渗透
- Provenance: `raw/libra/libra_metric_group_7051462.json`
- Key filters:
  - `bucket = post_interaction` - [[events/event_family_muf_post_interaction]]
- Source tables (from digest):
  - `musically.app_abtest_social_im_motivate_di`
  - `musically.app_abtest_social_im_motivate_di_uid`
  - `musically.app_abtest_social_im_motivate_di_did`
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `Post Interaction` 已 canonical 化为 event family，但还未拿到更细的 ByteIO raw event 名
  - motivation label 选择逻辑（first message in session）还需要专门 field-lineage 页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: MuF Post Interaction Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7051462
- Digest: [[digests/digest_7051462_muf_dm_by_motivation]]
- Numerator: `T1:is_first_motivate_post_interact` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: post interaction days per user
- Provenance: `raw/libra/libra_metric_group_7051462.json`
- Key filters:
  - `bucket = post_interaction` - [[events/event_family_muf_post_interaction]]
- Source tables (from digest):
  - `musically.app_abtest_social_im_motivate_di`
  - `musically.app_abtest_social_im_motivate_di_uid`
  - `musically.app_abtest_social_im_motivate_di_did`
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `Post Interaction` 已 canonical 化为 event family，但还未拿到更细的 ByteIO raw event 名
  - motivation label 选择逻辑（first message in session）还需要专门 field-lineage 页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: MuF Post Interaction Pair/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7051462
- Digest: [[digests/digest_7051462_muf_dm_by_motivation]]
- Numerator: `T1:post_interact_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均作品互动关系对
- Provenance: `raw/libra/libra_metric_group_7051462.json`
- Key filters:
  - `bucket = post_interaction` - [[events/event_family_muf_post_interaction]]
- Source tables (from digest):
  - `musically.app_abtest_social_im_motivate_di`
  - `musically.app_abtest_social_im_motivate_di_uid`
  - `musically.app_abtest_social_im_motivate_di_did`
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `Post Interaction` 已 canonical 化为 event family，但还未拿到更细的 ByteIO raw event 名
  - motivation label 选择逻辑（first message in session）还需要专门 field-lineage 页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: MuF Post Interaction/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7051462
- Digest: [[digests/digest_7051462_muf_dm_by_motivation]]
- Numerator: `T1:post_interact_send_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均作品互动次数
- Provenance: `raw/libra/libra_metric_group_7051462.json`
- Key filters:
  - `bucket = post_interaction` - [[events/event_family_muf_post_interaction]]
- Source tables (from digest):
  - `musically.app_abtest_social_im_motivate_di`
  - `musically.app_abtest_social_im_motivate_di_uid`
  - `musically.app_abtest_social_im_motivate_di_did`
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `Post Interaction` 已 canonical 化为 event family，但还未拿到更细的 ByteIO raw event 名
  - motivation label 选择逻辑（first message in session）还需要专门 field-lineage 页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: MuF Share Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7051462
- Digest: [[digests/digest_7051462_muf_dm_by_motivation]]
- Numerator: `T1:is_first_motivate_share` (type: `action_days`)
- Denominator: `T1:action_date` (type: `action_days`)
- Description: share days per days
- Provenance: `raw/libra/libra_metric_group_7051462.json`
- Key filters:
  - `bucket = share` - [[events/event_share_video_to_chat]] family
- Source tables (from digest):
  - `musically.app_abtest_social_im_motivate_di`
  - `musically.app_abtest_social_im_motivate_di_uid`
  - `musically.app_abtest_social_im_motivate_di_did`
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `Post Interaction` 已 canonical 化为 event family，但还未拿到更细的 ByteIO raw event 名
  - motivation label 选择逻辑（first message in session）还需要专门 field-lineage 页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: MuF Share Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7051462
- Digest: [[digests/digest_7051462_muf_dm_by_motivation]]
- Numerator: `T1:is_first_motivate_share` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: share days per user
- Provenance: `raw/libra/libra_metric_group_7051462.json`
- Key filters:
  - `bucket = share` - [[events/event_share_video_to_chat]] family
- Source tables (from digest):
  - `musically.app_abtest_social_im_motivate_di`
  - `musically.app_abtest_social_im_motivate_di_uid`
  - `musically.app_abtest_social_im_motivate_di_did`
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `Post Interaction` 已 canonical 化为 event family，但还未拿到更细的 ByteIO raw event 名
  - motivation label 选择逻辑（first message in session）还需要专门 field-lineage 页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: MuF Share Pair/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7051462
- Digest: [[digests/digest_7051462_muf_dm_by_motivation]]
- Numerator: `T1:share_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均分享动机关系对
- Provenance: `raw/libra/libra_metric_group_7051462.json`
- Key filters:
  - `bucket = share` - [[events/event_share_video_to_chat]] family
- Source tables (from digest):
  - `musically.app_abtest_social_im_motivate_di`
  - `musically.app_abtest_social_im_motivate_di_uid`
  - `musically.app_abtest_social_im_motivate_di_did`
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `Post Interaction` 已 canonical 化为 event family，但还未拿到更细的 ByteIO raw event 名
  - motivation label 选择逻辑（first message in session）还需要专门 field-lineage 页

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: MuF Share/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7051462
- Digest: [[digests/digest_7051462_muf_dm_by_motivation]]
- Numerator: `T1:share_send_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均分享动机次数
- Provenance: `raw/libra/libra_metric_group_7051462.json`
- Key filters:
  - `bucket = share` - [[events/event_share_video_to_chat]] family
- Source tables (from digest):
  - `musically.app_abtest_social_im_motivate_di`
  - `musically.app_abtest_social_im_motivate_di_uid`
  - `musically.app_abtest_social_im_motivate_di_did`
  - `musically.edl_direct_message_metric_daily`
  - `musically.adl_user_direct_message_metric_daily`
- Boundary notes:
  - `Post Interaction` 已 canonical 化为 event family，但还未拿到更细的 ByteIO raw event 名
  - motivation label 选择逻辑（first message in session）还需要专门 field-lineage 页

<!-- AUTO-GENERATED:metric_fields:end -->
