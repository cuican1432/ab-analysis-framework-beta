# Metrics By Group | [IM] DM Sticker Metrics

group_id: 7046953
canonical_name: [IM] DM Sticker Metrics
tags: metric-group, dm
wiki_digests: [[digests/digest_7046953_dm_sticker]]
wiki_matrices: [[digests/event_metric_matrix_7046953_dm_sticker]]

## Metrics

- base_user
  - metric_id: `2588068`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_2588068.md`
- Send Sticker pv/au
  - metric_id: `2588069`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_sticker_pv_au__id_2588069.md`
- Send Sticker uv/au
  - metric_id: `2588070`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_sticker_uv_au__id_2588070.md`
- Send Typing Recommendation Sticker pv/au
  - metric_id: `2588071`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_typing_recommendation_sticker_pv_au__id_2588071.md`
- Send Typing Recommendation Sticker uv/au
  - metric_id: `2588072`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_typing_recommendation_sticker_uv_au__id_2588072.md`
- Typing Recommendation UV Keyword Coverage
  - metric_id: `2588073`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_typing_recommendation_uv_keyword_coverage__id_2588073.md`
- Click/Show UV CTR Typing Rec
  - metric_id: `2588074`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_show_uv_ctr_typing_rec__id_2588074.md`
- Send Preshown Sticker pv/au
  - metric_id: `2588075`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_preshown_sticker_pv_au__id_2588075.md`
- Send Preshown Sticker uv/au
  - metric_id: `2588076`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_preshown_sticker_uv_au__id_2588076.md`
- Send Favourites Tab Sticker pv/au
  - metric_id: `2588077`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_favourites_tab_sticker_pv_au__id_2588077.md`
- Send Favourites Tab Sticker uv/au
  - metric_id: `2588078`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_favourites_tab_sticker_uv_au__id_2588078.md`
- Open Sticker Panel pv/au
  - metric_id: `2588079`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_open_sticker_panel_pv_au__id_2588079.md`
- Open Sticker Panel uv/au
  - metric_id: `2588080`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_open_sticker_panel_uv_au__id_2588080.md`
- Save Sticker to Favourite pv/au
  - metric_id: `2588081`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_save_sticker_to_favourite_pv_au__id_2588081.md`
- Save Sticker to Favourite uv/au
  - metric_id: `2588082`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_save_sticker_to_favourite_uv_au__id_2588082.md`
- Send UGC Sticker pv/au
  - metric_id: `2588083`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_ugc_sticker_pv_au__id_2588083.md`
- Send UGC Sticker uv/au
  - metric_id: `2588084`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_ugc_sticker_uv_au__id_2588084.md`
- Send SA pv/au
  - metric_id: `2588085`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_sa_pv_au__id_2588085.md`
- Send SA uv/au
  - metric_id: `2588086`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_sa_uv_au__id_2588086.md`
- Send Big Sticker pv/au
  - metric_id: `2588087`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_big_sticker_pv_au__id_2588087.md`
- Send Big Sticker uv/au
  - metric_id: `2588088`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_big_sticker_uv_au__id_2588088.md`

## Auto Definitions (Excerpt)

### Metric: base_user (2588068)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Click/Show UV CTR Typing Rec
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:keyword_recommendation_click_sticker_cnt` (type: `uv`)
- Denominator: `T1:keyword_recommendation_show_sticker_cnt` (type: `uv`)
- Description: UV Click/Show Typing Recommendation
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Field family: `sticker_typing_recommendation`
- Aggregation: `uv/uv`
- Meaning: 推荐展示后的点击效率
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Open Sticker Panel pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:open_sticker_panel_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Volume of opening the sticker panel
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Open Sticker Panel uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:open_sticker_panel_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Users that opened stickers panel
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Field family: `sticker_panel_favourites`
- Aggregation: `uv/base_user`
- Meaning: 打开 sticker 面板的用户覆盖
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Save Sticker to Favourite pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:save_sticker_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Volume of stickers saved to favourites tab
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Save Sticker to Favourite uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:save_sticker_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Users that saved stickers to favourites tab
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Field family: `sticker_panel_favourites`
- Aggregation: `uv/base_user`
- Meaning: 收藏 sticker 的用户覆盖
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Big Sticker pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:send_big_sticker_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Volume of big Stickers sent
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Big Sticker uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:send_big_sticker_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: users of big Stickers sent
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Field family: `sticker_send_completion`
- Aggregation: `uv/base_user`
- Meaning: 发送 big sticker 的用户覆盖
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Favourites Tab Sticker pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:favourite_tab_send_sticker_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Volume of favourite panel sent stickers
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Favourites Tab Sticker uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:favourite_tab_send_sticker_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Users that sent stickers through the favourites panel
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Field family: `sticker_panel_favourites`
- Aggregation: `uv/base_user`
- Meaning: 从 favourites tab 回流发送的用户覆盖
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Preshown Sticker pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:send_suggested_sticker_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Volume of preshown stickers
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Preshown Sticker uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:send_suggested_sticker_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Users that sent stickers through preshown sticker panel
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Field family: `suggested_sticker_send`
- Aggregation: `uv/base_user`
- Meaning: 预推荐 sticker 的发送覆盖
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send SA pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:send_aimoji_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Volume of aimoji Stickers sent
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send SA uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:send_aimoji_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: users that aimoji Stickers send
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Field family: `sticker_send_completion`
- Aggregation: `uv/base_user`
- Meaning: 发送 SA/Aimoji 类 sticker 内容的用户覆盖
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Sticker pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:send_sticker_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Volume of stickers sent
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Sticker uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:send_sticker_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Users that sent stickers
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Field family: `sticker_send_completion`
- Aggregation: `uv/base_user`
- Meaning: 发生 sticker 发送的用户覆盖
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Typing Recommendation Sticker pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:keyword_recommendation_send_sticker_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Volume of typing recommendation stickers
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Typing Recommendation Sticker uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:keyword_recommendation_send_sticker_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Users that sent stickers through typing recommendations
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Field family: `sticker_typing_recommendation`
- Aggregation: `uv/base_user`
- Meaning: 推荐链路最终带来的发送覆盖
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send UGC Sticker pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:send_ugc_sticker_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Volume of UGC Stickers sent
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send UGC Sticker uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:send_ugc_sticker_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: users that UGC Stickers send
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Field family: `sticker_send_completion`
- Aggregation: `uv/base_user`
- Meaning: 发送 UGC sticker 的用户覆盖
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Typing Recommendation UV Keyword Coverage
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7046953
- Digest: [[digests/digest_7046953_dm_sticker]]
- Numerator: `T1:keyword_recommendation_show_sticker_cnt` (type: `uv`)
- Denominator: `T1:start_dm_typing_cnt` (type: `uv`)
- Description: Proportion of users that was shown a typing recommendation sticker suggestion after typing in chat
- Provenance: `raw/libra/libra_metric_group_7046953.json`
- Field family: `sticker_typing_recommendation`
- Aggregation: `uv/uv`
- Meaning: 进入输入态后能看到推荐 sticker 的覆盖
- Key filters:
  - `message_type = sticker`, `aimoji` - 区分普通消息发送与 sticker/SA send-side 分支
  - recommendation stage - 拆解曝光、点击、发送三段效率
  - favourites reuse path - 判断供给是否通过收藏被复用
  - user cohort cuts - 做人群切片与分层归因
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-sticker-daily]]
  - [[tables/table_musically-adl-user-social-im-sticker-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - `Send Preshown Sticker*` 仍缺更强的一一对应 send contract
  - `Send Favourites Tab Sticker*` 仍缺 dedicated resend-side event page

<!-- AUTO-GENERATED:metric_fields:end -->
