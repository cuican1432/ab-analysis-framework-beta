# Metrics By Group | [IM] DM Camera Metrics Group Chat

group_id: 7054233
canonical_name: [IM] DM Camera Metrics Group Chat
tags: metric-group, dm
wiki_digests: [[digests/digest_7054233_dm_camera_group_chat]]
wiki_matrices: [[digests/event_metric_matrix_7054233_dm_camera_group_chat]]

## Metrics

- Group Chat Send Camera Message uv/au
  - metric_id: `2005340`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_send_camera_message_uv_au__id_2005340.md`
- Group Chat Send Camera Message pv/uv
  - metric_id: `2005341`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_send_camera_message_pv_uv__id_2005341.md`
- Group Chat Send Camera Message Shooting uv/au
  - metric_id: `2005342`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_send_camera_message_shooting_uv_au__id_2005342.md`
- Group Chat Send Camera Message Shooting pv/uv
  - metric_id: `2005343`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_send_camera_message_shooting_pv_uv__id_2005343.md`
- Group Chat Send Camera Message Upload uv/au
  - metric_id: `2005344`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_send_camera_message_upload_uv_au__id_2005344.md`
- Group Chat Send Camera Message Upload pv/uv
  - metric_id: `2005345`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_send_camera_message_upload_pv_uv__id_2005345.md`
- Group Chat Send Camera Effects message uv/au
  - metric_id: `2005346`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_send_camera_effects_message_uv_au__id_2005346.md`
- Group Chat Send Camera Effects message pv/au
  - metric_id: `2005347`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_send_camera_effects_message_pv_au__id_2005347.md`

## Auto Definitions (Excerpt)

### Metric: Group Chat Send Camera Effects message pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054233
- Digest: [[digests/digest_7054233_dm_camera_group_chat]]
- Numerator: `T2:group_chat_send_effect_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera message with effects pv/au
- Provenance: `raw/libra/libra_metric_group_7054233.json`
- Key filters:
  - `chat_type = group` - 将所有 camera 指标限定为群聊场景
  - creation mode - 比较群聊创作路径差异
  - cohort cuts - 看群聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Send Camera Effects message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054233
- Digest: [[digests/digest_7054233_dm_camera_group_chat]]
- Numerator: `T2:group_chat_send_effect_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera message with effects uv/au
- Provenance: `raw/libra/libra_metric_group_7054233.json`
- Field family: `camera_group_creation_path`
- Aggregation: `uv/base_user`
- Meaning: 群聊特效路径发送覆盖
- Key filters:
  - `chat_type = group` - 将所有 camera 指标限定为群聊场景
  - creation mode - 比较群聊创作路径差异
  - cohort cuts - 看群聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Send Camera Message pv/uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054233
- Digest: [[digests/digest_7054233_dm_camera_group_chat]]
- Numerator: `T2:group_chat_send_camera_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera message pv/uv
- Provenance: `raw/libra/libra_metric_group_7054233.json`
- Field family: `camera_group_send_completion`
- Aggregation: `pv/base_user`
- Meaning: 群聊 camera 人均发送强度
- Key filters:
  - `chat_type = group` - 将所有 camera 指标限定为群聊场景
  - creation mode - 比较群聊创作路径差异
  - cohort cuts - 看群聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Send Camera Message Shooting pv/uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054233
- Digest: [[digests/digest_7054233_dm_camera_group_chat]]
- Numerator: `T2:group_chat_send_message_by_shoot_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera shoot message pv/uv
- Provenance: `raw/libra/libra_metric_group_7054233.json`
- Key filters:
  - `chat_type = group` - 将所有 camera 指标限定为群聊场景
  - creation mode - 比较群聊创作路径差异
  - cohort cuts - 看群聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Send Camera Message Shooting uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054233
- Digest: [[digests/digest_7054233_dm_camera_group_chat]]
- Numerator: `T2:group_chat_send_message_by_shoot_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera shoot message uv/au
- Provenance: `raw/libra/libra_metric_group_7054233.json`
- Field family: `camera_group_creation_path`
- Aggregation: `uv/base_user`
- Meaning: 群聊拍摄路径发送覆盖
- Key filters:
  - `chat_type = group` - 将所有 camera 指标限定为群聊场景
  - creation mode - 比较群聊创作路径差异
  - cohort cuts - 看群聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Send Camera Message Upload pv/uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054233
- Digest: [[digests/digest_7054233_dm_camera_group_chat]]
- Numerator: `T2:group_chat_send_message_by_upload_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera upload message pv/uv
- Provenance: `raw/libra/libra_metric_group_7054233.json`
- Key filters:
  - `chat_type = group` - 将所有 camera 指标限定为群聊场景
  - creation mode - 比较群聊创作路径差异
  - cohort cuts - 看群聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Send Camera Message Upload uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054233
- Digest: [[digests/digest_7054233_dm_camera_group_chat]]
- Numerator: `T2:group_chat_send_message_by_upload_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera upload message uv/au
- Provenance: `raw/libra/libra_metric_group_7054233.json`
- Field family: `camera_group_creation_path`
- Aggregation: `uv/base_user`
- Meaning: 群聊上传路径发送覆盖
- Key filters:
  - `chat_type = group` - 将所有 camera 指标限定为群聊场景
  - creation mode - 比较群聊创作路径差异
  - cohort cuts - 看群聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Chat Send Camera Message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054233
- Digest: [[digests/digest_7054233_dm_camera_group_chat]]
- Numerator: `T2:group_chat_send_camera_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send dm camera message uv/au
- Provenance: `raw/libra/libra_metric_group_7054233.json`
- Field family: `camera_group_send_completion`
- Aggregation: `uv/base_user`
- Meaning: 群聊 camera 发送用户覆盖
- Key filters:
  - `chat_type = group` - 将所有 camera 指标限定为群聊场景
  - creation mode - 比较群聊创作路径差异
  - cohort cuts - 看群聊 camera 在不同人群的结构差异
- Source tables (from digest):
  - [[tables/table_musically-adl-device-social-im-camera-daily]]
  - [[tables/table_musically-adl-user-social-im-camera-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->
