# Metrics By Group | DM Growth Pairs- Retention

group_id: 7049357
canonical_name: DM Growth Pairs- Retention
tags: metric-group, dm
wiki_digests: [[digests/digest_7049357_dm_growth_pairs_retention]]
wiki_matrices: [[digests/event_metric_matrix_7049357_dm_growth_pairs_retention]]

## Metrics

- base_user
  - metric_id: `1532154`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_1532154.md`
- DM Pair 1 Day Retention
  - metric_id: `1532155`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_pair_1_day_retention__id_1532155.md`
- DM Pair 3 Day Retention
  - metric_id: `1532156`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_pair_3_day_retention__id_1532156.md`
- DM Pair 7 Day Retention
  - metric_id: `1532157`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_pair_7_day_retention__id_1532157.md`
- DM New Pair 1 Day Retention
  - metric_id: `1532158`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_new_pair_1_day_retention__id_1532158.md`
- DM New Pair 3 Day Retention
  - metric_id: `1532159`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_new_pair_3_day_retention__id_1532159.md`
- DM New Pair 7 Day Retention
  - metric_id: `1532160`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_new_pair_7_day_retention__id_1532160.md`
- DM Retained Pair 1 Day Retention
  - metric_id: `1532161`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_retained_pair_1_day_retention__id_1532161.md`
- DM Retained Pair 3 Day Retention
  - metric_id: `1532162`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_retained_pair_3_day_retention__id_1532162.md`
- DM Retained Pair 7 Day Retention
  - metric_id: `1532163`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_retained_pair_7_day_retention__id_1532163.md`
- DM Resurrected Pair 1 Day Retention
  - metric_id: `1532164`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_resurrected_pair_1_day_retention__id_1532164.md`
- DM Resurrected Pair 3 Day Retention
  - metric_id: `1532165`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_resurrected_pair_3_day_retention__id_1532165.md`
- DM Resurrected Pair 7 Day Retention
  - metric_id: `1532166`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_resurrected_pair_7_day_retention__id_1532166.md`

## Auto Definitions (Excerpt)

### Metric: base_user (1532154)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049357
- Digest: [[digests/digest_7049357_dm_growth_pairs_retention]]
- Numerator: `user` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7049357.json`
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - No unique raw-event contract is isolated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM New Pair 1 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049357
- Digest: [[digests/digest_7049357_dm_growth_pairs_retention]]
- Numerator: `T3:send_or_like_muf_message_new_pair_cnt_ret_1d` (type: `pv`)
- Denominator: `T3:send_or_like_muf_message_new_pair_cnt` (type: `pv`)
- Description: 私信互动新增Muf关系对1日留存
- Provenance: `raw/libra/libra_metric_group_7049357.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - No unique raw-event contract is isolated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM New Pair 3 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049357
- Digest: [[digests/digest_7049357_dm_growth_pairs_retention]]
- Numerator: `T3:send_or_like_muf_message_new_pair_cnt_ret_3d` (type: `pv`)
- Denominator: `T3:send_or_like_muf_message_new_pair_cnt` (type: `pv`)
- Description: 私信互动新增Muf关系对3日留存
- Provenance: `raw/libra/libra_metric_group_7049357.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - No unique raw-event contract is isolated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM New Pair 7 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049357
- Digest: [[digests/digest_7049357_dm_growth_pairs_retention]]
- Numerator: `T3:send_or_like_muf_message_new_pair_cnt_ret_7d` (type: `pv`)
- Denominator: `T3:send_or_like_muf_message_new_pair_cnt` (type: `pv`)
- Description: 私信互动新增Muf关系对7日留存
- Provenance: `raw/libra/libra_metric_group_7049357.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - No unique raw-event contract is isolated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM Pair 1 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049357
- Digest: [[digests/digest_7049357_dm_growth_pairs_retention]]
- Numerator: `T3:send_or_like_muf_message_pair_cnt_ret_1d` (type: `pv`)
- Denominator: `T3:send_or_like_muf_message_pair_cnt` (type: `pv`)
- Description: 私信互动Muf关系对1日留存
- Provenance: `raw/libra/libra_metric_group_7049357.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - No unique raw-event contract is isolated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM Pair 3 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049357
- Digest: [[digests/digest_7049357_dm_growth_pairs_retention]]
- Numerator: `T3:send_or_like_muf_message_pair_cnt_ret_3d` (type: `pv`)
- Denominator: `T3:send_or_like_muf_message_pair_cnt` (type: `pv`)
- Description: 私信互动Muf关系对3日留存
- Provenance: `raw/libra/libra_metric_group_7049357.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - No unique raw-event contract is isolated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM Pair 7 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049357
- Digest: [[digests/digest_7049357_dm_growth_pairs_retention]]
- Numerator: `T3:send_or_like_muf_message_pair_cnt_ret_7d` (type: `pv`)
- Denominator: `T3:send_or_like_muf_message_pair_cnt` (type: `pv`)
- Description: 私信互动Muf关系对7日留存
- Provenance: `raw/libra/libra_metric_group_7049357.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - No unique raw-event contract is isolated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM Resurrected Pair 1 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049357
- Digest: [[digests/digest_7049357_dm_growth_pairs_retention]]
- Numerator: `T3:send_or_like_muf_message_resurrected_pair_cnt_ret_1d` (type: `pv`)
- Denominator: `T3:send_or_like_muf_message_resurrected_pair_cnt` (type: `pv`)
- Description: 私信互动唤活Muf关系对1日留存
- Provenance: `raw/libra/libra_metric_group_7049357.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - No unique raw-event contract is isolated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM Resurrected Pair 3 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049357
- Digest: [[digests/digest_7049357_dm_growth_pairs_retention]]
- Numerator: `T3:send_or_like_muf_message_resurrected_pair_cnt_ret_3d` (type: `pv`)
- Denominator: `T3:send_or_like_muf_message_resurrected_pair_cnt` (type: `pv`)
- Description: 私信互动唤活Muf关系对3日留存
- Provenance: `raw/libra/libra_metric_group_7049357.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - No unique raw-event contract is isolated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM Resurrected Pair 7 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049357
- Digest: [[digests/digest_7049357_dm_growth_pairs_retention]]
- Numerator: `T3:send_or_like_muf_message_resurrected_pair_cnt_ret_7d` (type: `pv`)
- Denominator: `T3:send_or_like_muf_message_resurrected_pair_cnt` (type: `pv`)
- Description: 私信互动唤活Muf关系对7日留存
- Provenance: `raw/libra/libra_metric_group_7049357.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - No unique raw-event contract is isolated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM Retained Pair 1 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049357
- Digest: [[digests/digest_7049357_dm_growth_pairs_retention]]
- Numerator: `T3:send_or_like_muf_message_retained_pair_cnt_ret_1d` (type: `pv`)
- Denominator: `T3:send_or_like_muf_message_retained_pair_cnt` (type: `pv`)
- Description: 私信互动留存Muf关系对1日留存
- Provenance: `raw/libra/libra_metric_group_7049357.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - No unique raw-event contract is isolated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM Retained Pair 3 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049357
- Digest: [[digests/digest_7049357_dm_growth_pairs_retention]]
- Numerator: `T3:send_or_like_muf_message_retained_pair_cnt_ret_3d` (type: `pv`)
- Denominator: `T3:send_or_like_muf_message_retained_pair_cnt` (type: `pv`)
- Description: 私信互动留存Muf关系对3日留存
- Provenance: `raw/libra/libra_metric_group_7049357.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - No unique raw-event contract is isolated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM Retained Pair 7 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049357
- Digest: [[digests/digest_7049357_dm_growth_pairs_retention]]
- Numerator: `T3:send_or_like_muf_message_retained_pair_cnt_ret_7d` (type: `pv`)
- Denominator: `T3:send_or_like_muf_message_retained_pair_cnt` (type: `pv`)
- Description: 私信互动留存Muf关系对7日留存
- Provenance: `raw/libra/libra_metric_group_7049357.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - No unique raw-event contract is isolated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->
