# Metrics By Group | Core Interaction Growth Pairs- Retention

group_id: 7049358
canonical_name: Core Interaction Growth Pairs- Retention
tags: metric-group, dm
wiki_digests: [[digests/digest_7049358_core_interaction_growth_pairs_retention]]
wiki_matrices: [[digests/event_metric_matrix_7049358_core_interaction_growth_pairs_retention]]

## Metrics

- base_user
  - metric_id: `1532141`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_1532141.md`
- Core interaction Pair 1 Day Retention
  - metric_id: `1532142`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_pair_1_day_retention__id_1532142.md`
- Core interaction Pair 3 Day Retention
  - metric_id: `1532143`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_pair_3_day_retention__id_1532143.md`
- Core interaction Pair 7 Day Retention
  - metric_id: `1532144`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_pair_7_day_retention__id_1532144.md`
- Core interaction New Pair 1 Day Retention
  - metric_id: `1532145`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_new_pair_1_day_retention__id_1532145.md`
- Core interaction New Pair 3 Day Retention
  - metric_id: `1532146`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_new_pair_3_day_retention__id_1532146.md`
- Core interaction New Pair 7 Day Retention
  - metric_id: `1532147`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_new_pair_7_day_retention__id_1532147.md`
- Core interaction Retained Pair 1 Day Retention
  - metric_id: `1532148`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_retained_pair_1_day_retention__id_1532148.md`
- Core interaction Retained Pair 3 Day Retention
  - metric_id: `1532149`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_retained_pair_3_day_retention__id_1532149.md`
- Core interaction Retained Pair 7 Day Retention
  - metric_id: `1532150`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_retained_pair_7_day_retention__id_1532150.md`
- Core interaction Resurrected Pair 1 Day Retention
  - metric_id: `1532151`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_resurrected_pair_1_day_retention__id_1532151.md`
- Core interaction Resurrected Pair 3 Day Retention
  - metric_id: `1532152`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_resurrected_pair_3_day_retention__id_1532152.md`
- Core interaction Resurrected Pair 7 Day Retention
  - metric_id: `1532153`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_core_interaction_resurrected_pair_7_day_retention__id_1532153.md`

## Auto Definitions (Excerpt)

### Metric: base_user (1532141)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049358
- Digest: [[digests/digest_7049358_core_interaction_growth_pairs_retention]]
- Numerator: `user` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7049358.json`
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Core-interaction growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - Raw-event contract is not separated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction New Pair 1 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049358
- Digest: [[digests/digest_7049358_core_interaction_growth_pairs_retention]]
- Numerator: `T3:core_interactive_muf_new_pair_cnt_ret_1d` (type: `pv`)
- Denominator: `T3:core_interactive_muf_new_pair_cnt` (type: `pv`)
- Description: 核心互动新增Muf关系对1日留存
- Provenance: `raw/libra/libra_metric_group_7049358.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Core-interaction growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - Raw-event contract is not separated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction New Pair 3 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049358
- Digest: [[digests/digest_7049358_core_interaction_growth_pairs_retention]]
- Numerator: `T3:core_interactive_muf_new_pair_cnt_ret_3d` (type: `pv`)
- Denominator: `T3:core_interactive_muf_new_pair_cnt` (type: `pv`)
- Description: 核心互动新增Muf关系对3日留存
- Provenance: `raw/libra/libra_metric_group_7049358.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Core-interaction growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - Raw-event contract is not separated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction New Pair 7 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049358
- Digest: [[digests/digest_7049358_core_interaction_growth_pairs_retention]]
- Numerator: `T3:core_interactive_muf_new_pair_cnt_ret_7d` (type: `pv`)
- Denominator: `T3:core_interactive_muf_new_pair_cnt` (type: `pv`)
- Description: 核心互动新增Muf关系对7日留存
- Provenance: `raw/libra/libra_metric_group_7049358.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Core-interaction growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - Raw-event contract is not separated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction Pair 1 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049358
- Digest: [[digests/digest_7049358_core_interaction_growth_pairs_retention]]
- Numerator: `T3:core_interactive_pair_cnt_ret_1d` (type: `pv`)
- Denominator: `T3:core_interactive_muf_pair_cnt` (type: `pv`)
- Description: 核心互动Muf关系对1日留存
- Provenance: `raw/libra/libra_metric_group_7049358.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Core-interaction growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - Raw-event contract is not separated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction Pair 3 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049358
- Digest: [[digests/digest_7049358_core_interaction_growth_pairs_retention]]
- Numerator: `T3:core_interactive_pair_cnt_ret_3d` (type: `pv`)
- Denominator: `T3:core_interactive_muf_pair_cnt` (type: `pv`)
- Description: 核心互动Muf关系对3日留存
- Provenance: `raw/libra/libra_metric_group_7049358.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Core-interaction growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - Raw-event contract is not separated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction Pair 7 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049358
- Digest: [[digests/digest_7049358_core_interaction_growth_pairs_retention]]
- Numerator: `T3:core_interactive_pair_cnt_ret_7d` (type: `pv`)
- Denominator: `T3:core_interactive_muf_pair_cnt` (type: `pv`)
- Description: 核心互动Muf关系对7日留存
- Provenance: `raw/libra/libra_metric_group_7049358.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Core-interaction growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - Raw-event contract is not separated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction Resurrected Pair 1 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049358
- Digest: [[digests/digest_7049358_core_interaction_growth_pairs_retention]]
- Numerator: `T3:core_interactive_muf_resurrected_pair_cnt_ret_1d` (type: `pv`)
- Denominator: `T3:core_interactive_muf_resurrected_pair_cnt` (type: `pv`)
- Description: 核心互动唤活Muf关系对1日留存
- Provenance: `raw/libra/libra_metric_group_7049358.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Core-interaction growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - Raw-event contract is not separated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction Resurrected Pair 3 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049358
- Digest: [[digests/digest_7049358_core_interaction_growth_pairs_retention]]
- Numerator: `T3:core_interactive_muf_resurrected_pair_cnt_ret_3d` (type: `pv`)
- Denominator: `T3:core_interactive_muf_resurrected_pair_cnt` (type: `pv`)
- Description: 核心互动唤活Muf关系对3日留存
- Provenance: `raw/libra/libra_metric_group_7049358.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Core-interaction growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - Raw-event contract is not separated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction Resurrected Pair 7 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049358
- Digest: [[digests/digest_7049358_core_interaction_growth_pairs_retention]]
- Numerator: `T3:core_interactive_muf_resurrected_pair_cnt_ret_7d` (type: `pv`)
- Denominator: `T3:core_interactive_muf_resurrected_pair_cnt` (type: `pv`)
- Description: 核心互动唤活Muf关系对7日留存
- Provenance: `raw/libra/libra_metric_group_7049358.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Core-interaction growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - Raw-event contract is not separated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction Retained Pair 1 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049358
- Digest: [[digests/digest_7049358_core_interaction_growth_pairs_retention]]
- Numerator: `T3:core_interactive_muf_retained_pair_cnt_ret_1d` (type: `pv`)
- Denominator: `T3:core_interactive_muf_retained_pair_cnt` (type: `pv`)
- Description: 核心互动留存Muf关系对1日留存
- Provenance: `raw/libra/libra_metric_group_7049358.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Core-interaction growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - Raw-event contract is not separated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction Retained Pair 3 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049358
- Digest: [[digests/digest_7049358_core_interaction_growth_pairs_retention]]
- Numerator: `T3:core_interactive_muf_retained_pair_cnt_ret_3d` (type: `pv`)
- Denominator: `T3:core_interactive_muf_retained_pair_cnt` (type: `pv`)
- Description: 核心互动留存Muf关系对3日留存
- Provenance: `raw/libra/libra_metric_group_7049358.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Core-interaction growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - Raw-event contract is not separated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Core interaction Retained Pair 7 Day Retention
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049358
- Digest: [[digests/digest_7049358_core_interaction_growth_pairs_retention]]
- Numerator: `T3:core_interactive_muf_retained_pair_cnt_ret_7d` (type: `pv`)
- Denominator: `T3:core_interactive_muf_retained_pair_cnt` (type: `pv`)
- Description: 核心互动留存Muf关系对7日留存
- Provenance: `raw/libra/libra_metric_group_7049358.json`
- Aggregation: pv / pv
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-muf-retention-metric-nd]]
  - [[tables/table_musically-app-abtest-social-user-muf-retention-metric-nd]]
- Boundary notes:
  - Core-interaction growth-pairs retention metrics are confirmed at ND retention aggregate table level.
  - Raw-event contract is not separated from the retention aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->
