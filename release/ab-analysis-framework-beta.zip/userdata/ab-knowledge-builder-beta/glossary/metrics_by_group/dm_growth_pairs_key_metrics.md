# Metrics By Group | DM Growth Pairs-Key Metrics

group_id: 7049137
canonical_name: DM Growth Pairs-Key Metrics
tags: metric-group, dm
wiki_digests: [[digests/digest_7049137_growth_pairs_key_metrics]]
wiki_matrices: [[digests/event_metric_matrix_7049137_growth_pairs_key_metrics]]

## Metrics

- base_user
  - metric_id: `1532122`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_1532122.md`
- Muf Core Interaction  pairs / U
  - metric_id: `1532123`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_core_interaction_pairs_u__id_1532123.md`
- Muf Core Interaction New pairs / U
  - metric_id: `1532124`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_core_interaction_new_pairs_u__id_1532124.md`
- Muf Core Interaction Retained Pais / U
  - metric_id: `1532125`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_core_interaction_retained_pais_u__id_1532125.md`
- Muf Core Interaction Resurrected Pairs / U
  - metric_id: `1532126`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_core_interaction_resurrected_pairs_u__id_1532126.md`
- Muf DM pairs / U
  - metric_id: `1532127`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_dm_pairs_u__id_1532127.md`
- Muf DM New pairs / U
  - metric_id: `1532128`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_dm_new_pairs_u__id_1532128.md`
- Muf DM Retained Pais / U
  - metric_id: `1532129`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_dm_retained_pais_u__id_1532129.md`
- Muf DM Resurrected Pairs / U
  - metric_id: `1532130`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_muf_dm_resurrected_pairs_u__id_1532130.md`

## Auto Definitions (Excerpt)

### Metric: base_user (1532122)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049137
- Digest: [[digests/digest_7049137_growth_pairs_key_metrics]]
- Numerator: `user` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7049137.json`
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Growth-pairs key metrics are confirmed at MUF pair aggregate table level.
  - No unique raw-event contract is isolated from the pair aggregates yet.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Muf Core Interaction New pairs / U
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049137
- Digest: [[digests/digest_7049137_growth_pairs_key_metrics]]
- Numerator: `T2:core_interactive_muf_new_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均Muf核心活跃新增关系对
- Provenance: `raw/libra/libra_metric_group_7049137.json`
- Aggregation: pv / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Growth-pairs key metrics are confirmed at MUF pair aggregate table level.
  - No unique raw-event contract is isolated from the pair aggregates yet.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Muf Core Interaction  pairs / U
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049137
- Digest: [[digests/digest_7049137_growth_pairs_key_metrics]]
- Numerator: `T2:core_interactive_muf_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均Muf核心活跃关系对
- Provenance: `raw/libra/libra_metric_group_7049137.json`
- Aggregation: pv / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Growth-pairs key metrics are confirmed at MUF pair aggregate table level.
  - No unique raw-event contract is isolated from the pair aggregates yet.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Muf Core Interaction Resurrected Pairs / U
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049137
- Digest: [[digests/digest_7049137_growth_pairs_key_metrics]]
- Numerator: `T2:core_interactive_muf_resurrected_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均Muf核心活跃唤活关系对
- Provenance: `raw/libra/libra_metric_group_7049137.json`
- Aggregation: pv / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Growth-pairs key metrics are confirmed at MUF pair aggregate table level.
  - No unique raw-event contract is isolated from the pair aggregates yet.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Muf Core Interaction Retained Pais / U
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049137
- Digest: [[digests/digest_7049137_growth_pairs_key_metrics]]
- Numerator: `T2:core_interactive_muf_retained_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均Muf核心活跃留存关系对
- Provenance: `raw/libra/libra_metric_group_7049137.json`
- Aggregation: pv / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Growth-pairs key metrics are confirmed at MUF pair aggregate table level.
  - No unique raw-event contract is isolated from the pair aggregates yet.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Muf DM New pairs / U
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049137
- Digest: [[digests/digest_7049137_growth_pairs_key_metrics]]
- Numerator: `T2:send_or_like_muf_message_new_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均Muf私信新增关系对
- Provenance: `raw/libra/libra_metric_group_7049137.json`
- Aggregation: pv / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Growth-pairs key metrics are confirmed at MUF pair aggregate table level.
  - No unique raw-event contract is isolated from the pair aggregates yet.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Muf DM pairs / U
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049137
- Digest: [[digests/digest_7049137_growth_pairs_key_metrics]]
- Numerator: `T2:send_or_like_muf_message_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均Muf私信活跃关系对
- Provenance: `raw/libra/libra_metric_group_7049137.json`
- Aggregation: pv / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Growth-pairs key metrics are confirmed at MUF pair aggregate table level.
  - No unique raw-event contract is isolated from the pair aggregates yet.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Muf DM Resurrected Pairs / U
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049137
- Digest: [[digests/digest_7049137_growth_pairs_key_metrics]]
- Numerator: `T2:send_or_like_muf_message_resurrected_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均Muf私信唤活关系对
- Provenance: `raw/libra/libra_metric_group_7049137.json`
- Aggregation: pv / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Growth-pairs key metrics are confirmed at MUF pair aggregate table level.
  - No unique raw-event contract is isolated from the pair aggregates yet.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Muf DM Retained Pais / U
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049137
- Digest: [[digests/digest_7049137_growth_pairs_key_metrics]]
- Numerator: `T2:send_or_like_muf_message_retained_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均Muf私信留存关系对
- Provenance: `raw/libra/libra_metric_group_7049137.json`
- Aggregation: pv / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Growth-pairs key metrics are confirmed at MUF pair aggregate table level.
  - No unique raw-event contract is isolated from the pair aggregates yet.

<!-- AUTO-GENERATED:metric_fields:end -->
