# Metrics By Group | [DM] DM Group Chat by Msg Type

group_id: 7049184
canonical_name: [DM] DM Group Chat by Msg Type
tags: metric-group, dm
wiki_digests: [[digests/digest_7049184_dm_group_chat_by_msg_type]]
wiki_matrices: [[digests/event_metric_matrix_7049184_dm_group_chat_by_msg_type]]

## Metrics


## Auto Definitions (Excerpt)
