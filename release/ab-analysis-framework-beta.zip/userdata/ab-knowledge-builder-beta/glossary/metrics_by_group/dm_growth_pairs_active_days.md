# Metrics By Group | DM Growth Pairs-Active Days

group_id: 7049146
canonical_name: DM Growth Pairs-Active Days
tags: metric-group, dm
wiki_digests: [[digests/digest_7049146_dm_growth_pairs_active_days]]
wiki_matrices: [[digests/event_metric_matrix_7049146_dm_growth_pairs_active_days]]

## Metrics

- base_user
  - metric_id: `1532136`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_1532136.md`
- DM Pair Active Days
  - metric_id: `1532137`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_pair_active_days__id_1532137.md`
- DM New Pair Active Days
  - metric_id: `1532138`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_new_pair_active_days__id_1532138.md`
- DM Retained Pair Active Days
  - metric_id: `1532139`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_retained_pair_active_days__id_1532139.md`
- DM Resurrected Pair Active Days
  - metric_id: `1532140`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_dm_resurrected_pair_active_days__id_1532140.md`

## Auto Definitions (Excerpt)

### Metric: base_user (1532136)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049146
- Digest: [[digests/digest_7049146_dm_growth_pairs_active_days]]
- Numerator: `user` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7049146.json`
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Growth-pairs activeness metrics are confirmed at daily pair aggregate level.
  - Raw-event contract is not separated from the pair aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM New Pair Active Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049146
- Digest: [[digests/digest_7049146_dm_growth_pairs_active_days]]
- Numerator: `T2:send_or_like_muf_message_new_pair_cnt` (type: `cross_days_action`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: DM New Pair Active Days
- Provenance: `raw/libra/libra_metric_group_7049146.json`
- Aggregation: cross_days_action / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Growth-pairs activeness metrics are confirmed at daily pair aggregate level.
  - Raw-event contract is not separated from the pair aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM Pair Active Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049146
- Digest: [[digests/digest_7049146_dm_growth_pairs_active_days]]
- Numerator: `T2:send_or_like_muf_message_pair_cnt` (type: `cross_days_action`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: DM Pair Active Days
- Provenance: `raw/libra/libra_metric_group_7049146.json`
- Aggregation: cross_days_action / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Growth-pairs activeness metrics are confirmed at daily pair aggregate level.
  - Raw-event contract is not separated from the pair aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM Resurrected Pair Active Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049146
- Digest: [[digests/digest_7049146_dm_growth_pairs_active_days]]
- Numerator: `T2:send_or_like_muf_message_resurrected_pair_cnt` (type: `cross_days_action`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: DM Resurrected Pair Active Days
- Provenance: `raw/libra/libra_metric_group_7049146.json`
- Aggregation: cross_days_action / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Growth-pairs activeness metrics are confirmed at daily pair aggregate level.
  - Raw-event contract is not separated from the pair aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: DM Retained Pair Active Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049146
- Digest: [[digests/digest_7049146_dm_growth_pairs_active_days]]
- Numerator: `T2:send_or_like_muf_message_retained_pair_cnt` (type: `cross_days_action`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: DM Retained Pair Active Days
- Provenance: `raw/libra/libra_metric_group_7049146.json`
- Aggregation: cross_days_action / base_user
- Key filters:
  - `pair` - 以关系对为分析单位
  - `nd retention` - 区分 activeness 和 retention
- Source tables (from digest):
  - [[tables/table_musically-adl-social-device-muf-growth-metric-1d]]
  - [[tables/table_musically-adl-social-user-muf-growth-metric-1d]]
- Boundary notes:
  - Growth-pairs activeness metrics are confirmed at daily pair aggregate level.
  - Raw-event contract is not separated from the pair aggregate source.

<!-- AUTO-GENERATED:metric_fields:end -->
