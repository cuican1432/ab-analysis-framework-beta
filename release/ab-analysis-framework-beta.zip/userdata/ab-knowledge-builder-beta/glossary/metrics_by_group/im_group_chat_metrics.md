# Metrics By Group | [IM] Group Chat Metrics

group_id: 7034976
canonical_name: [IM] Group Chat Metrics
tags: metric-group, dm
wiki_digests: [[digests/digest_7034976_dm_group_chat]]
wiki_matrices: [[digests/event_metric_matrix_7034976_dm_group_chat]]

## Metrics

- GC Send or Like Penetration
  - metric_id: `2313967`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_gc_send_or_like_penetration__id_2313967.md`
- GC Send or Like pv/au
  - metric_id: `2313968`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_gc_send_or_like_pv_au__id_2313968.md`
- GC Send Message uv/au
  - metric_id: `2313969`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_gc_send_message_uv_au__id_2313969.md`
- GC Send Message pv/au
  - metric_id: `2313970`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_gc_send_message_pv_au__id_2313970.md`
- GC Receive Message uv/au
  - metric_id: `2313971`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_gc_receive_message_uv_au__id_2313971.md`
- GC Receive Message pv/au
  - metric_id: `2313972`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_gc_receive_message_pv_au__id_2313972.md`
- Create GC uv/au
  - metric_id: `2313973`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_create_gc_uv_au__id_2313973.md`
- Create GC pv/au
  - metric_id: `2313974`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_create_gc_pv_au__id_2313974.md`
- GC Share Video uv/au
  - metric_id: `2313975`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_gc_share_video_uv_au__id_2313975.md`
- GC Share Video pv/au
  - metric_id: `2313976`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_gc_share_video_pv_au__id_2313976.md`
- GC Enter Chat uv/au
  - metric_id: `2313977`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_gc_enter_chat_uv_au__id_2313977.md`
- GC Enter Chat pv/au
  - metric_id: `2313978`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_gc_enter_chat_pv_au__id_2313978.md`

## Auto Definitions (Excerpt)

### Metric: Create GC pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7034976
- Digest: [[digests/digest_7034976_dm_group_chat]]
- Numerator: `T1:create_group_chat_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Create group chat pv/au
- Provenance: `raw/libra/libra_metric_group_7034976.json`
- Field family: `group_creation`
- Aggregation: `pv/base_user`
- Meaning: 人均建群次数
- Key filters:
  - `chat_type = group` - 定义整组指标都只看群聊场景
  - create entrance buckets - 区分 share / notification / private_chat / live_share / chat_list 等建群来源
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Create GC uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7034976
- Digest: [[digests/digest_7034976_dm_group_chat]]
- Numerator: `T1:create_group_chat_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Create group chat uv/au
- Provenance: `raw/libra/libra_metric_group_7034976.json`
- Field family: `group_creation`
- Aggregation: `uv/base_user`
- Meaning: 有建群行为的用户覆盖
- Key filters:
  - `chat_type = group` - 定义整组指标都只看群聊场景
  - create entrance buckets - 区分 share / notification / private_chat / live_share / chat_list 等建群来源
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: GC Enter Chat pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7034976
- Digest: [[digests/digest_7034976_dm_group_chat]]
- Numerator: `T1:enter_group_chat_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Group chat enter chat pv/au
- Provenance: `raw/libra/libra_metric_group_7034976.json`
- Field family: `group_entry`
- Aggregation: `pv/base_user`
- Meaning: 人均进群次数
- Key filters:
  - `chat_type = group` - 定义整组指标都只看群聊场景
  - create entrance buckets - 区分 share / notification / private_chat / live_share / chat_list 等建群来源
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: GC Enter Chat uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7034976
- Digest: [[digests/digest_7034976_dm_group_chat]]
- Numerator: `T1:enter_group_chat_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Group chat enter chat uv/au
- Provenance: `raw/libra/libra_metric_group_7034976.json`
- Field family: `group_entry`
- Aggregation: `uv/base_user`
- Meaning: 有进群行为的用户覆盖
- Key filters:
  - `chat_type = group` - 定义整组指标都只看群聊场景
  - create entrance buckets - 区分 share / notification / private_chat / live_share / chat_list 等建群来源
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: GC Receive Message pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7034976
- Digest: [[digests/digest_7034976_dm_group_chat]]
- Numerator: `T1:receive_group_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Group chat receive message pv/au
- Provenance: `raw/libra/libra_metric_group_7034976.json`
- Field family: `group_interaction`
- Aggregation: `pv/base_user`
- Meaning: 人均群聊接收消息强度
- Key filters:
  - `chat_type = group` - 定义整组指标都只看群聊场景
  - create entrance buckets - 区分 share / notification / private_chat / live_share / chat_list 等建群来源
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: GC Receive Message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7034976
- Digest: [[digests/digest_7034976_dm_group_chat]]
- Numerator: `T1:receive_group_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Group chat receive message uv/au
- Provenance: `raw/libra/libra_metric_group_7034976.json`
- Field family: `group_interaction`
- Aggregation: `uv/base_user`
- Meaning: 有群聊接收消息行为的用户覆盖
- Key filters:
  - `chat_type = group` - 定义整组指标都只看群聊场景
  - create entrance buckets - 区分 share / notification / private_chat / live_share / chat_list 等建群来源
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: GC Send Message pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7034976
- Digest: [[digests/digest_7034976_dm_group_chat]]
- Numerator: `T1:send_group_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Group chat send message pv/au
- Provenance: `raw/libra/libra_metric_group_7034976.json`
- Field family: `group_interaction`
- Aggregation: `pv/base_user`
- Meaning: 人均群聊消息发送强度
- Key filters:
  - `chat_type = group` - 定义整组指标都只看群聊场景
  - create entrance buckets - 区分 share / notification / private_chat / live_share / chat_list 等建群来源
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: GC Send Message uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7034976
- Digest: [[digests/digest_7034976_dm_group_chat]]
- Numerator: `T1:send_group_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Group chat send message uv/au
- Provenance: `raw/libra/libra_metric_group_7034976.json`
- Field family: `group_interaction`
- Aggregation: `uv/base_user`
- Meaning: 有群聊发消息行为的用户覆盖
- Key filters:
  - `chat_type = group` - 定义整组指标都只看群聊场景
  - create entrance buckets - 区分 share / notification / private_chat / live_share / chat_list 等建群来源
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: GC Send or Like Penetration
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7034976
- Digest: [[digests/digest_7034976_dm_group_chat]]
- Numerator: `T1:send_or_like_message_by_group_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Group chat send or like uv/au
- Provenance: `raw/libra/libra_metric_group_7034976.json`
- Field family: `group_interaction`
- Aggregation: `uv/base_user`
- Meaning: 群聊发送或点赞渗透率
- Key filters:
  - `chat_type = group` - 定义整组指标都只看群聊场景
  - create entrance buckets - 区分 share / notification / private_chat / live_share / chat_list 等建群来源
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: GC Send or Like pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7034976
- Digest: [[digests/digest_7034976_dm_group_chat]]
- Numerator: `T1:send_or_like_message_by_group_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Group chat send or like pv/au
- Provenance: `raw/libra/libra_metric_group_7034976.json`
- Field family: `group_interaction`
- Aggregation: `pv/base_user`
- Meaning: 人均群聊发送或点赞强度
- Key filters:
  - `chat_type = group` - 定义整组指标都只看群聊场景
  - create entrance buckets - 区分 share / notification / private_chat / live_share / chat_list 等建群来源
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: GC Share Video pv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7034976
- Digest: [[digests/digest_7034976_dm_group_chat]]
- Numerator: `T1:send_video_group_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Group chat share video pv/au
- Provenance: `raw/libra/libra_metric_group_7034976.json`
- Field family: `group_share_enrichment`
- Aggregation: `pv/base_user`
- Meaning: 人均群聊视频分享强度
- Key filters:
  - `chat_type = group` - 定义整组指标都只看群聊场景
  - create entrance buckets - 区分 share / notification / private_chat / live_share / chat_list 等建群来源
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: GC Share Video uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7034976
- Digest: [[digests/digest_7034976_dm_group_chat]]
- Numerator: `T1:send_video_group_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Group chat share video uv/au
- Provenance: `raw/libra/libra_metric_group_7034976.json`
- Field family: `group_share_enrichment`
- Aggregation: `uv/base_user`
- Meaning: 有群聊内分享视频行为的用户覆盖
- Key filters:
  - `chat_type = group` - 定义整组指标都只看群聊场景
  - create entrance buckets - 区分 share / notification / private_chat / live_share / chat_list 等建群来源
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->
