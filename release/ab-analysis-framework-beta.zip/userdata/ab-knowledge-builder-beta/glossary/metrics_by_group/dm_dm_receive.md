# Metrics By Group | [DM] DM Receive

group_id: 7014898
canonical_name: [DM] DM Receive
tags: metric-group, dm
wiki_digests: [[digests/digest_7014898_dm_receive]]
wiki_matrices: [[digests/event_metric_matrix_7014898_dm_receive]]

## Metrics

- User
  - metric_id: `36507`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base-user__id_36507.md`
- User
  - metric_id: `36507`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_user__id_36507.md`
- Receive_msg_user/user
  - metric_id: `36508`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive_msg_user_user__id_36508.md`
- receive_message_cnt_1d
  - metric_id: `36509`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive_message_cnt_1d__id_36509.md`
- Receive_msg/user
  - metric_id: `36509`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive_msg_user__id_36509.md`
- Receiver_session/user
  - metric_id: `36510`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receiver_session_user__id_36510.md`
- Receive_internal_share_user/user
  - metric_id: `36511`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive_internal_share_user_user__id_36511.md`
- Receive_internal_share/user
  - metric_id: `36512`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive_internal_share_user__id_36512.md`
- New_receive_message_user/user
  - metric_id: `36513`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_new_receive_message_user_user__id_36513.md`
- New_receive_message/user
  - metric_id: `36514`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_new_receive_message_user__id_36514.md`
- Receive_and_enter_chat_user/user
  - metric_id: `36515`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive_and_enter_chat_user_user__id_36515.md`
- Receive_and_enter_chat/user
  - metric_id: `36516`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive_and_enter_chat_user__id_36516.md`
- Receive_and_reply_user/user
  - metric_id: `36517`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive_and_reply_user_user__id_36517.md`
- receive_and_reply_message_cnt_1d
  - metric_id: `36518`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive_and_reply_message_cnt_1d__id_36518.md`
- Receive_and_reply/user
  - metric_id: `36518`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive_and_reply_user__id_36518.md`
- Firrst_coldstart_via_msg_push_user/user
  - metric_id: `36519`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_firrst_coldstart_via_msg_push_user_user__id_36519.md`

## Auto Definitions (Excerpt)

### Metric: User (36507)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `(implicit)` (type: `pv`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Firrst_coldstart_via_msg_push_user/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `T0:first_cold_launch_by_message_flag` (type: `uv`)
- Denominator: `(implicit)` (type: `-`)
- Description: first cold launch through dm push penetration
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: New_receive_message/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `T0:new_receive_message_cnt_1d` (type: `pv`)
- Denominator: `(implicit)` (type: `-`)
- Description: first receive message count per dau
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Aggregation: pv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: New_receive_message_user/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `T0:new_receive_message_flag` (type: `uv`)
- Denominator: `(implicit)` (type: `-`)
- Description: first receive message penetration
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive_and_enter_chat/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `T0:receive_message_and_enter_chat_cnt_1d` (type: `pv`)
- Denominator: `(implicit)` (type: `-`)
- Description: receive message and enter chat count per dau
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Aggregation: pv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive_and_enter_chat_user/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `T0:receive_message_and_enter_chat_cnt_1d` (type: `uv`)
- Denominator: `(implicit)` (type: `-`)
- Description: receive message and enter chat penetration
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: receive_and_reply_message_cnt_1d
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `T0:receive_and_reply_message_cnt_1d` (type: `pv`)
- Denominator: `(implicit)` (type: `-`)
- Description: receive message and reply count per dau
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Aggregation: inferred_field
- Meaning: Inferred from digest field reference
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive_and_reply/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `T0:receive_and_reply_message_cnt_1d` (type: `pv`)
- Denominator: `(implicit)` (type: `-`)
- Description: receive message and reply count per dau
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Aggregation: pv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive_and_reply_user/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `T0:receive_and_reply_message_cnt_1d` (type: `uv`)
- Denominator: `(implicit)` (type: `-`)
- Description: receive message and reply penetration
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive_internal_share/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `T0:receive_video_message_cnt_1d` (type: `pv`)
- Denominator: `(implicit)` (type: `-`)
- Description: receive internal video share count per dau
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Aggregation: pv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive_internal_share_user/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `T0:receive_video_message_cnt_1d` (type: `uv`)
- Denominator: `(implicit)` (type: `-`)
- Description: receive internal video share penetration
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: receive_message_cnt_1d
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `T0:receive_message_cnt_1d` (type: `pv`)
- Denominator: `(implicit)` (type: `-`)
- Description: receive message count per dau
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Aggregation: inferred_field
- Meaning: Inferred from digest field reference
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive_msg/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `T0:receive_message_cnt_1d` (type: `pv`)
- Denominator: `(implicit)` (type: `-`)
- Description: receive message count per dau
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Aggregation: pv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive_msg_user/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `T0:receive_message_cnt_1d` (type: `uv`)
- Denominator: `(implicit)` (type: `-`)
- Description: receive message penetration
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Aggregation: uv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receiver_session/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `T0:msg_receiver_session_cnt_1d` (type: `pv`)
- Denominator: `(implicit)` (type: `-`)
- Description: session count for users receive message per dau
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Aggregation: pv / base_user
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: User (36507)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7014898
- Digest: [[digests/digest_7014898_dm_receive]]
- Numerator: `(implicit)` (type: `pv`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7014898.json`
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-adl-user-social-metric-history]]
- Boundary notes:
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->
