# Metrics By Group | [B2C] Business Message Key Metrics

group_id: 7044888
canonical_name: [B2C] Business Message Key Metrics
tags: metric-group, dm
wiki_digests: [[digests/digest_7044888_b2c_business_message_key_metrics]]
wiki_matrices: [[digests/event_metric_matrix_7044888_b2c_business_message_key_metrics]]

## Metrics

- base_user
  - metric_id: `3086294`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_3086294.md`
- Business Conv DM 2-way penetration
  - metric_id: `3086295`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_business_conv_dm_2_way_penetration__id_3086295.md`
- Business Conv DM 2-way pair / au
  - metric_id: `3086296`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_business_conv_dm_2_way_pair_au__id_3086296.md`
- Business Conv DM 2-way UV
  - metric_id: `3086297`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_business_conv_dm_2_way_uv__id_3086297.md`
- Business Conv DM 2-way pair
  - metric_id: `3086298`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_business_conv_dm_2_way_pair__id_3086298.md`
- Business Conv DM penetration
  - metric_id: `3086299`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_business_conv_dm_penetration__id_3086299.md`
- C2B DM penetration
  - metric_id: `3086300`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_dm_penetration__id_3086300.md`
- C2B start UV / enter UV
  - metric_id: `3086301`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_start_uv_enter_uv__id_3086301.md`
- C2B start PV / enter PV
  - metric_id: `3086302`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_start_pv_enter_pv__id_3086302.md`
- C2B DM pair / DAU
  - metric_id: `3086303`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_dm_pair_dau__id_3086303.md`
- C2B conv 3min response rate
  - metric_id: `3086304`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_conv_3min_response_rate__id_3086304.md`
- C2B conv 1h response rate
  - metric_id: `3086305`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_conv_1h_response_rate__id_3086305.md`
- C2B conv 24h response rate
  - metric_id: `3086306`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_conv_24h_response_rate__id_3086306.md`
- B2C DM penetration
  - metric_id: `3086307`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_b2c_dm_penetration__id_3086307.md`
- B2C DM pair / DAU
  - metric_id: `3086308`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_b2c_dm_pair_dau__id_3086308.md`
- B2C conv 3min response rate
  - metric_id: `3086309`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_b2c_conv_3min_response_rate__id_3086309.md`
- B2C conv 1h response rate
  - metric_id: `3086310`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_b2c_conv_1h_response_rate__id_3086310.md`
- B2C conv 24h response rate
  - metric_id: `3086311`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_b2c_conv_24h_response_rate__id_3086311.md`
- C2B enter chat penetration
  - metric_id: `3086312`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_enter_chat_penetration__id_3086312.md`
- C2B enter chat pv/au
  - metric_id: `3086313`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_enter_chat_pv_au__id_3086313.md`
- C2B pair initiation rate
  - metric_id: `3086314`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_pair_initiation_rate__id_3086314.md`
- C2B first message conv 3min reply rate
  - metric_id: `3086315`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_first_message_conv_3min_reply_rate__id_3086315.md`
- C2B first message conv 1h reply rate
  - metric_id: `3086316`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_first_message_conv_1h_reply_rate__id_3086316.md`
- C2B first message conv 24h reply rate
  - metric_id: `3086317`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_first_message_conv_24h_reply_rate__id_3086317.md`
- C2B first message conv 3min average time
  - metric_id: `3086318`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_first_message_conv_3min_average_time__id_3086318.md`
- C2B first message conv 1h average min
  - metric_id: `3086319`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_first_message_conv_1h_average_min__id_3086319.md`
- C2B first message conv 24h average hour
  - metric_id: `3086320`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_first_message_conv_24h_average_hour__id_3086320.md`
- Business Conv DM 2+Round penetration
  - metric_id: `3086321`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_business_conv_dm_2_round_penetration__id_3086321.md`
- Business Conv DM 2+Round pair / au
  - metric_id: `3086322`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_business_conv_dm_2_round_pair_au__id_3086322.md`
- B2C DM Report rate
  - metric_id: `3086323`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_b2c_dm_report_rate__id_3086323.md`
- C2B DM Report Message rate
  - metric_id: `3086324`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_dm_report_message_rate__id_3086324.md`
- Business Conv DM Report Message rate
  - metric_id: `3086325`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_business_conv_dm_report_message_rate__id_3086325.md`
- B2C DM Violative Message rate
  - metric_id: `3086326`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_b2c_dm_violative_message_rate__id_3086326.md`
- C2B DM Violative Message rate
  - metric_id: `3086327`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_dm_violative_message_rate__id_3086327.md`
- Business Conv DM Violative Message rate
  - metric_id: `3086328`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_business_conv_dm_violative_message_rate__id_3086328.md`
- C2B DM pair leads rate
  - metric_id: `3086329`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_dm_pair_leads_rate__id_3086329.md`
- C2B DM Block Pair rate
  - metric_id: `3086330`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_dm_block_pair_rate__id_3086330.md`
- B2C DM Block Pair rate
  - metric_id: `3086331`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_b2c_dm_block_pair_rate__id_3086331.md`
- Business Conv DM Block Pair rate
  - metric_id: `3086332`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_business_conv_dm_block_pair_rate__id_3086332.md`
- Business Conv DM 2-way Days / Days
  - metric_id: `3086333`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_business_conv_dm_2_way_days_days__id_3086333.md`
- Business Conv DM Days / Days
  - metric_id: `3086334`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_business_conv_dm_days_days__id_3086334.md`
- C2B DM Days / Days
  - metric_id: `3086335`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_dm_days_days__id_3086335.md`
- B2C DM Days / Days
  - metric_id: `3086336`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_b2c_dm_days_days__id_3086336.md`
- C2B enter chat Days / Days
  - metric_id: `3086337`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_c2b_enter_chat_days_days__id_3086337.md`
- Business Conv DM 2+Round Days / Days
  - metric_id: `3086338`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_business_conv_dm_2_round_days_days__id_3086338.md`

## Auto Definitions (Excerpt)

### Metric: B2C conv 1h response rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T4:b2c_message_responded_1h_chat_ucnt` (type: `pv`)
- Denominator: `T4:b2c_send_or_like_message_chat_ucnt` (type: `pv`)
- Description: B2C会话1h回复率
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Field family: `business_conv_response`
- Aggregation: `pv/pv`
- Meaning: B2C 1 小时响应率
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = b2c` - business to consumer
  - `response_window = 1h` - response-time slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: B2C conv 24h response rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T4:b2c_message_responded_chat_ucnt` (type: `pv`)
- Denominator: `T4:b2c_send_or_like_message_chat_ucnt` (type: `pv`)
- Description: B2C会话24h回复率
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = b2c` - business to consumer
  - `response_window = 24h` - response-time slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: B2C conv 3min response rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T4:b2c_message_responded_3min_chat_ucnt` (type: `pv`)
- Denominator: `T4:b2c_send_or_like_message_chat_ucnt` (type: `pv`)
- Description: B2C会话3min回复率
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = b2c` - business to consumer
  - `response_window = 3min` - response-time slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: B2C DM Block Pair rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:b2c_chat_blocked_confirm_chat_ucnt` (type: `pv`)
- Denominator: `T7:send_message_by_private_chat_ucnt` (type: `pv`)
- Description: B被C屏蔽
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = b2c` - business to consumer
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: B2C DM Days / Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:b2c_send_or_like_message_cnt` (type: `action_days`)
- Denominator: `T7:base_action_days` (type: `action_days`)
- Description: B2C私信 Days / Active Days
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = b2c` - business to consumer
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: B2C DM pair / DAU
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:b2c_send_or_like_message_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: B2C人均pair数
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = b2c` - business to consumer
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: B2C DM penetration (3086307)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:b2c_send_or_like_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: B2C私信渗透
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = b2c` - business to consumer
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: B2C DM Report rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:b2c_reported_msg_cnt` (type: `pv`)
- Denominator: `T7:send_message_by_private_cnt` (type: `pv`)
- Description: B给C发信息， B被举报。
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Field family: `business_conv_moderation`
- Aggregation: `pv/pv`
- Meaning: B2C 举报率
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = b2c` - business to consumer
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: B2C DM Violative Message rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:b2c_tcs_reported_violated_msg_cnt_mul_1m` (type: `pv`)
- Denominator: `T7:send_message_by_private_cnt` (type: `pv`)
- Description: B给C发信息， B违规 。
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = b2c` - business to consumer
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: base_user (3086294)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Business Conv DM 2+Round Days / Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:engaged_chat_ucnt` (type: `action_days`)
- Denominator: `T7:base_action_days` (type: `action_days`)
- Description: Business对话超过两轮的 Days / Active Days：
对话超过两轮：用户对商家发至少一条消息 + 商家回复用户至少一条消息+ 用户再次对商家发至少一条消息
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Business Conv DM 2+Round pair / au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:engaged_chat_ucnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Business对话超过两轮的人均pair数：
对话超过两轮：用户对商家发至少一条消息 + 商家回复用户至少一条消息+ 用户再次对商家发至少一条消息
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Business Conv DM 2+Round penetration
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:engaged_chat_ucnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Business对话超过两轮的渗透：
对话超过两轮：用户对商家发至少一条消息 + 商家回复用户至少一条消息+ 用户再次对商家发至少一条消息
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Field family: `business_conv_engagement`
- Aggregation: `uv/base_user`
- Meaning: 2+轮商业会话渗透率
- Key filters:
  - `is_business = true` - business conversation slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Business Conv DM 2-way Days / Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:dual_pair_cnt` (type: `action_days`)
- Denominator: `T7:base_action_days` (type: `action_days`)
- Description: Business双向私信会话 Days / Active Days
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Business Conv DM 2-way pair
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:dual_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `-`)
- Description: Business双向私信会话pair数
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Business Conv DM 2-way pair / au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:dual_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Business人均双向私信会话pair数
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Business Conv DM 2-way penetration
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:dual_pair_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Business双向私信会话渗透
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Field family: `business_conv_engagement`
- Aggregation: `uv/base_user`
- Meaning: 双向商业会话渗透率
- Key filters:
  - `is_business = true` - business conversation slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Business Conv DM 2-way UV
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:dual_pair_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `-`)
- Description: Business双向私信会话UV
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Business Conv DM Block Pair rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:business_conv_chat_blocked_confirm_chat_ucnt` (type: `pv`)
- Denominator: `T7:send_message_by_private_chat_ucnt` (type: `pv`)
- Description: C或B中任何一方被屏蔽
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Business Conv DM Days / Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:business_conv_send_or_like_message_cnt` (type: `action_days`)
- Denominator: `T7:base_action_days` (type: `action_days`)
- Description: 会话双方有一方为Business私信会话 Days / Active Days
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Business Conv DM penetration
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:business_conv_send_or_like_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 会话双方有一方为Business私信会话渗透
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Field family: `business_conv_penetration`
- Aggregation: `uv/base_user`
- Meaning: 商业会话渗透率
- Key filters:
  - `is_business = true` - business conversation slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Business Conv DM Report Message rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:business_conv_reported_msg_cnt` (type: `pv`)
- Denominator: `T7:send_message_by_private_cnt` (type: `pv`)
- Description: B或者C任何一方发消息被举报。
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Business Conv DM Violative Message rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:business_conv_tcs_reported_violated_msg_cnt_mul_1m` (type: `pv`)
- Denominator: `T7:send_message_by_private_cnt` (type: `pv`)
- Description: B或者C任何一方发消息违规。
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Field family: `business_conv_moderation`
- Aggregation: `pv/pv`
- Meaning: 商业会话违规消息率
- Key filters:
  - `is_business = true` - business conversation slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2B conv 1h response rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T4:c2b_message_responded_1h_chat_ucnt` (type: `pv`)
- Denominator: `T4:c2b_send_or_like_message_chat_ucnt` (type: `pv`)
- Description: C2B会话1h回复率
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Field family: `business_conv_response`
- Aggregation: `pv/pv`
- Meaning: C2B 1 小时响应率
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = c2b` - consumer to business
  - `response_window = 1h` - response-time slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2B conv 24h response rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T4:c2b_message_responded_chat_ucnt` (type: `pv`)
- Denominator: `T4:c2b_send_or_like_message_chat_ucnt` (type: `pv`)
- Description: C2B会话24h回复率
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = c2b` - consumer to business
  - `response_window = 24h` - response-time slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2B conv 3min response rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T4:c2b_message_responded_3min_chat_ucnt` (type: `pv`)
- Denominator: `T4:c2b_send_or_like_message_chat_ucnt` (type: `pv`)
- Description: C2B会话3min回复率
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = c2b` - consumer to business
  - `response_window = 3min` - response-time slice
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2B DM Block Pair rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:c2b_chat_blocked_confirm_chat_ucnt` (type: `pv`)
- Denominator: `T7:send_message_by_private_chat_ucnt` (type: `pv`)
- Description: C被B屏蔽
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = c2b` - consumer to business
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2B DM Days / Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:c2b_send_or_like_message_cnt` (type: `action_days`)
- Denominator: `T7:base_action_days` (type: `action_days`)
- Description: C2B私信 Days / Active Days
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = c2b` - consumer to business
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2B DM pair / DAU
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:c2b_send_or_like_message_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: C2B人均pair数
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = c2b` - consumer to business
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: C2B DM pair leads rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7044888
- Digest: [[digests/digest_7044888_b2c_business_message_key_metrics]]
- Numerator: `T1:c2b_submit_leads_chat_ucnt` (type: `pv`)
- Denominator: `T1:c2b_send_message_pair_cnt` (type: `pv`)
- Description: c2b 产生leads的pair/发消息的c2b pair
- Provenance: `raw/libra/libra_metric_group_7044888.json`
- Field family: `business_conv_conversion`
- Aggregation: `pv/pv`
- Meaning: C2B 会话 leads 转化率
- Key filters:
  - `is_business = true` - business conversation slice
  - `direction = c2b` - consumer to business
  - `include_ai_reply = true` - AI reply included
- Source tables (from digest):
  - [[tables/table_musically-adl-social-im-b2c-user-daily]]
  - [[tables/table_musically-adl-social-im-b2c-message-responded-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]

<!-- AUTO-GENERATED:metric_fields:end -->

> truncated: 15 more metrics omitted from the auto excerpt.
