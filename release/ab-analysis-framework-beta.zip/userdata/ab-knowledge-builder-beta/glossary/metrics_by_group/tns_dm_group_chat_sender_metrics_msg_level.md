# Metrics By Group | TnS DM Group Chat Sender Metrics - Msg Level

group_id: 7043979
canonical_name: TnS DM Group Chat Sender Metrics - Msg Level
tags: metric-group, dm
wiki_digests: [[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]
wiki_matrices: [[digests/event_metric_matrix_7043979_tns_dm_group_chat_sender_metrics_msg_level]]

## Metrics

- report_rate
  - metric_id: `916510`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_rate__id_916510.md`
- egregious_rate
  - metric_id: `916511`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_egregious_rate__id_916511.md`
- violation_rate
  - metric_id: `916512`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_violation_rate__id_916512.md`
- ban_rate_groupmsg
  - metric_id: `916513`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_ban_rate_groupmsg__id_916513.md`
- notice_rate_groupmsg
  - metric_id: `916514`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notice_rate_groupmsg__id_916514.md`
- feedback_rate_groupmsg
  - metric_id: `916515`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_rate_groupmsg__id_916515.md`
- feedback_success_rate_groupmsg
  - metric_id: `916516`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_success_rate_groupmsg__id_916516.md`
- feedback_appeal_rate_groupmsg
  - metric_id: `916517`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_appeal_rate_groupmsg__id_916517.md`
- feedback_appeal_success_rate_groupmsg
  - metric_id: `916518`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_feedback_appeal_success_rate_groupmsg__id_916518.md`
- report_violate_rate_groupmsg
  - metric_id: `916519`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_violate_rate_groupmsg__id_916519.md`
- report_egregious_rate_groupmsg
  - metric_id: `916520`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_egregious_rate_groupmsg__id_916520.md`
- report_appeal_rate_groupmsg
  - metric_id: `916521`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_appeal_rate_groupmsg__id_916521.md`
- report_appeal_success_rate_groupmsg
  - metric_id: `916522`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_appeal_success_rate_groupmsg__id_916522.md`
- report_appeal_egregious_rate_groupmsg
  - metric_id: `916523`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_report_appeal_egregious_rate_groupmsg__id_916523.md`

## Auto Definitions (Excerpt)

### Metric: ban_rate_groupmsg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043979
- Digest: [[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]
- Numerator: `T1:ban_group_msg_cnt` (type: `pv`)
- Denominator: `T1:group_msg_cnt` (type: `pv`)
- Description: Ban Rate % at Msg Level for Group Chat. ban_groupmsg_cnt / groupmsg_cnt
- Provenance: `raw/libra/libra_metric_group_7043979.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: egregious_rate (916511)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043979
- Digest: [[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]
- Numerator: `T1:report_egregious_group_msg_cnt` (type: `pv`)
- Denominator: `T1:group_msg_cnt` (type: `pv`)
- Description: Report Egregious Rate % at Msg Level. Denominator: Group Chat Msg Count. User this for describing egregsious leakage for Group Chat. report_egregious_group_msg_cnt / group_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043979.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_appeal_rate_groupmsg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043979
- Digest: [[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]
- Numerator: `T1:feedback_appeal_group_msg_cnt` (type: `pv`)
- Denominator: `T1:feedback_group_msg_cnt` (type: `pv`)
- Description: Feedback Appeal Rate % at Msg Level for Group Chat. Denominator: Feedback Msg Count. feedback_appeal_groupmsg_cnt / feedback_group_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043979.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_appeal_success_rate_groupmsg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043979
- Digest: [[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]
- Numerator: `T1:feedback_appeal_success_group_msg_cnt` (type: `pv`)
- Denominator: `T1:feedback_appeal_group_msg_cnt` (type: `pv`)
- Description: Feedback Appeal Success Rate % at Msg Level for Group Chat. Denominator: Feedback Appealed Group Chat Msg Count. feedback_appeal_success_groupmsg_cnt / feedback_appeal_group_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043979.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_rate_groupmsg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043979
- Digest: [[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]
- Numerator: `T1:feedback_group_msg_cnt` (type: `pv`)
- Denominator: `T1:ban_group_msg_cnt` (type: `pv`)
- Description: Feedback Rate % at Msg Level for Group Chat. Denominator: Banned Msg Count. feedback_groupmsg_cnt / ban_group_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043979.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: feedback_success_rate_groupmsg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043979
- Digest: [[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]
- Numerator: `T1:feedback_success_group_msg_cnt` (type: `pv`)
- Denominator: `T1:feedback_group_msg_cnt` (type: `pv`)
- Description: Feedback Success Rate % at Msg Level for Group Chat. Denominator: Feedback Msg Count. feedback_success_groupmsg_cnt / feedback_group_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043979.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: notice_rate_groupmsg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043979
- Digest: [[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]
- Numerator: `T1:notice_group_msg_cnt` (type: `pv`)
- Denominator: `T1:group_msg_cnt` (type: `pv`)
- Description: Notice Rate % at Msg Level for Group Chat. notice_groupmsg_cnt / groupmsg_cnt
- Provenance: `raw/libra/libra_metric_group_7043979.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_appeal_egregious_rate_groupmsg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043979
- Digest: [[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]
- Numerator: `T1:report_appeal_egregious_group_msg_cnt` (type: `pv`)
- Denominator: `T1:report_appeal_group_msg_cnt` (type: `pv`)
- Description: Report Appeal Egregious Rate % at Msg Level for Group Chat. Denominator: Messages in group chat were appealed because of banned by report. report_appeal_egregious_groupmsg_cnt / report_appeal_group_chat_msg
- Provenance: `raw/libra/libra_metric_group_7043979.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_appeal_rate_groupmsg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043979
- Digest: [[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]
- Numerator: `T1:report_appeal_group_msg_cnt` (type: `pv`)
- Denominator: `T1:report_group_msg_cnt` (type: `pv`)
- Description: Report Appeal Rate % at Msg Level for Group Chat. Denominator: Reported Group Chat Msg Count. report_appeal_groupmsg_cnt / report_group_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043979.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_appeal_success_rate_groupmsg
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043979
- Digest: [[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]
- Numerator: `T1:report_appeal_success_group_msg_cnt` (type: `pv`)
- Denominator: `T1:report_appeal_group_msg_cnt` (type: `pv`)
- Description: Report Appeal Success Rate % at Msg Level for Group Chat. Denominator: Messages in group chat were appealed because of banned by report. report_appeal_success_groupmsg_cnt / report_appeal_group_chat_msg
- Provenance: `raw/libra/libra_metric_group_7043979.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_egregious_rate_groupmsg (916520)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043979
- Digest: [[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]
- Numerator: `T1:report_egregious_group_msg_cnt` (type: `pv`)
- Denominator: `T1:report_group_msg_cnt` (type: `pv`)
- Description: Report Egregious Rate % at Msg Level For Group Chat. Denominator: Reported Group Chat Msg Count. report_egregious_groupmsg_cnt / report_group_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043979.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_rate (916510)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043979
- Digest: [[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]
- Numerator: `T1:report_group_msg_cnt` (type: `pv`)
- Denominator: `T1:group_msg_cnt` (type: `pv`)
- Description: Report Rate % at Msg Level for Group Chat. . report_groupmsg_cnt / groupmsg_cnt
- Provenance: `raw/libra/libra_metric_group_7043979.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: report_violate_rate_groupmsg (916519)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043979
- Digest: [[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]
- Numerator: `T1:report_violate_group_msg_cnt` (type: `pv`)
- Denominator: `T1:report_group_msg_cnt` (type: `pv`)
- Description: Report Violation Rate % at Msg Level for Group Chat. Denominator: Reported Group Chat Msg Count. report_violate_groupmsg_cnt / report_group_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043979.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: violation_rate (916512)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7043979
- Digest: [[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]
- Numerator: `T1:report_violate_group_msg_cnt` (type: `pv`)
- Denominator: `T1:group_msg_cnt` (type: `pv`)
- Description: Report Violation Rate % at Msg Level. Denominator: Group Chat Msg Count. User this for describing violation leakage for Group Chat. report_violate_group_msg_cnt / group_msg_cnt
- Provenance: `raw/libra/libra_metric_group_7043979.json`
- Aggregation: pv / pv
- Key filters:
  - `private`, `group` - 区分会话形态
  - `sender`, `receiver` - 区分责任侧和承压侧
  - `conv`, `msg` - 区分会话级和消息级风险
- Source tables (from digest):
  - [[tables/table_tnscdm-ads-mt-msg-sender-1d]]
- Boundary notes:
  - 尚未把举报 / moderation 口径拆成独立 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->
