# Metrics By Group | [IM] Group Chat 14d Retention metrics

group_id: 7049634
canonical_name: [IM] Group Chat 14d Retention metrics
tags: metric-group, dm
wiki_digests: [[digests/digest_7049634_dm_group_chat_14d_retention]]
wiki_matrices: [[digests/event_metric_matrix_7049634_dm_group_chat_14d_retention]]

## Metrics

- base_user
  - metric_id: `2780334`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_2780334.md`
- 14d retention
  - metric_id: `2780335`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_14d_retention__id_2780335.md`

## Auto Definitions (Excerpt)

### Metric: 14d retention (2780335)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049634
- Digest: [[digests/digest_7049634_dm_group_chat_14d_retention]]
- Numerator: `T3:new_group_chat_ret_14d` (type: `pv`)
- Denominator: `T3:new_group_chat` (type: `pv`)
- Description: 14d retention
- Provenance: `raw/libra/libra_metric_group_7049634.json`
- Field family: `group_chat_retention_14d_core`
- Aggregation: `pv/pv`
- Meaning: 全量新建群在 14d 窗口后的留存率
- Key filters:
  - `14d` - 指定两周窗口留存
  - cohort scope - 本组面向全量新建群 cohort
  - numerator / denominator pair - 拆解 cohort 创建与 survival 变化
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-14d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-14d]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: base_user (2780334)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7049634
- Digest: [[digests/digest_7049634_dm_group_chat_14d_retention]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7049634.json`
- Key filters:
  - `14d` - 指定两周窗口留存
  - cohort scope - 本组面向全量新建群 cohort
  - numerator / denominator pair - 拆解 cohort 创建与 survival 变化
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-device-group-chat-retention-14d]]
  - [[tables/table_musically-app-abtest-social-user-group-chat-retention-14d]]

<!-- AUTO-GENERATED:metric_fields:end -->
