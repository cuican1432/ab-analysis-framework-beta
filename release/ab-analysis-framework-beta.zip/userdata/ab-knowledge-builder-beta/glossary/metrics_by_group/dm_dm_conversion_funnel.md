# Metrics By Group | [DM] DM Conversion Funnel

group_id: 7033046
canonical_name: [DM] DM Conversion Funnel
tags: metric-group, dm
wiki_digests: [[digests/digest_7033046_dm_conversion_funnel]]
wiki_matrices: [[digests/event_metric_matrix_7033046_dm_conversion_funnel]]

## Metrics

- base_user
  - metric_id: `2780267`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_2780267.md`
- Send message uv/user
  - metric_id: `2780269`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_message_uv_user__id_2780269.md`
- Receive message pv/user
  - metric_id: `2780270`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive_message_pv_user__id_2780270.md`
- Receive message uv/user
  - metric_id: `2780271`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive_message_uv_user__id_2780271.md`
- Read message pv/user
  - metric_id: `2780272`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_read_message_pv_user__id_2780272.md`
- Read message uv/user
  - metric_id: `2780273`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_read_message_uv_user__id_2780273.md`
- Reply message pv/user
  - metric_id: `2780274`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_reply_message_pv_user__id_2780274.md`
- Reply message uv/user
  - metric_id: `2780275`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_reply_message_uv_user__id_2780275.md`
- Read/Receive PV rate
  - metric_id: `2780276`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_read_receive_pv_rate__id_2780276.md`
- Read/Receive UV rate
  - metric_id: `2780277`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_read_receive_uv_rate__id_2780277.md`
- Reply/Read PV rate
  - metric_id: `2780278`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_reply_read_pv_rate__id_2780278.md`
- Reply/Read UV rate
  - metric_id: `2780279`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_reply_read_uv_rate__id_2780279.md`

## Auto Definitions (Excerpt)

### Metric: base_user (2780267)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7033046
- Digest: [[digests/digest_7033046_dm_conversion_funnel]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7033046.json`
- Key filters:
  - 无显式过滤 - 这是标准消息漏斗，不依赖 MuF / group 等切片过滤
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - It still does not provide full ByteIO contract verification for each funnel stage, so this stops at event-family confidence rather than contract confidence.
  - reply 层尚未完成 raw event contract 验证
  - 若要升级整组为 `raw_event_contract_verified`，需逐层补 ByteIO/TEA 证据

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Read message pv/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7033046
- Digest: [[digests/digest_7033046_dm_conversion_funnel]]
- Numerator: `T1:read_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: read message per user
- Provenance: `raw/libra/libra_metric_group_7033046.json`
- Aggregation: pv / base_user
- Key filters:
  - 无显式过滤 - 这是标准消息漏斗，不依赖 MuF / group 等切片过滤
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - It still does not provide full ByteIO contract verification for each funnel stage, so this stops at event-family confidence rather than contract confidence.
  - reply 层尚未完成 raw event contract 验证
  - 若要升级整组为 `raw_event_contract_verified`，需逐层补 ByteIO/TEA 证据

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Read message uv/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7033046
- Digest: [[digests/digest_7033046_dm_conversion_funnel]]
- Numerator: `T1:read_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: read message penetration rate
- Provenance: `raw/libra/libra_metric_group_7033046.json`
- Aggregation: uv / base_user
- Key filters:
  - 无显式过滤 - 这是标准消息漏斗，不依赖 MuF / group 等切片过滤
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - It still does not provide full ByteIO contract verification for each funnel stage, so this stops at event-family confidence rather than contract confidence.
  - reply 层尚未完成 raw event contract 验证
  - 若要升级整组为 `raw_event_contract_verified`，需逐层补 ByteIO/TEA 证据

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Read/Receive PV rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7033046
- Digest: [[digests/digest_7033046_dm_conversion_funnel]]
- Numerator: `T1:read_message_cnt` (type: `pv`)
- Denominator: `T1:receive_message_cnt` (type: `pv`)
- Description: read message/receive message pv rate
- Provenance: `raw/libra/libra_metric_group_7033046.json`
- Aggregation: pv / pv
- Key filters:
  - 无显式过滤 - 这是标准消息漏斗，不依赖 MuF / group 等切片过滤
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - It still does not provide full ByteIO contract verification for each funnel stage, so this stops at event-family confidence rather than contract confidence.
  - reply 层尚未完成 raw event contract 验证
  - 若要升级整组为 `raw_event_contract_verified`，需逐层补 ByteIO/TEA 证据

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Read/Receive UV rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7033046
- Digest: [[digests/digest_7033046_dm_conversion_funnel]]
- Numerator: `T1:read_message_cnt` (type: `uv`)
- Denominator: `T1:receive_message_cnt` (type: `uv`)
- Description: read message/receive message uv rate
- Provenance: `raw/libra/libra_metric_group_7033046.json`
- Aggregation: uv / uv
- Key filters:
  - 无显式过滤 - 这是标准消息漏斗，不依赖 MuF / group 等切片过滤
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - It still does not provide full ByteIO contract verification for each funnel stage, so this stops at event-family confidence rather than contract confidence.
  - reply 层尚未完成 raw event contract 验证
  - 若要升级整组为 `raw_event_contract_verified`，需逐层补 ByteIO/TEA 证据

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive message pv/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7033046
- Digest: [[digests/digest_7033046_dm_conversion_funnel]]
- Numerator: `T1:receive_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: receive message per user
- Provenance: `raw/libra/libra_metric_group_7033046.json`
- Aggregation: pv / base_user
- Key filters:
  - 无显式过滤 - 这是标准消息漏斗，不依赖 MuF / group 等切片过滤
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - It still does not provide full ByteIO contract verification for each funnel stage, so this stops at event-family confidence rather than contract confidence.
  - reply 层尚未完成 raw event contract 验证
  - 若要升级整组为 `raw_event_contract_verified`，需逐层补 ByteIO/TEA 证据

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive message uv/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7033046
- Digest: [[digests/digest_7033046_dm_conversion_funnel]]
- Numerator: `T1:receive_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: receive message penetration rate
- Provenance: `raw/libra/libra_metric_group_7033046.json`
- Aggregation: uv / base_user
- Key filters:
  - 无显式过滤 - 这是标准消息漏斗，不依赖 MuF / group 等切片过滤
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - It still does not provide full ByteIO contract verification for each funnel stage, so this stops at event-family confidence rather than contract confidence.
  - reply 层尚未完成 raw event contract 验证
  - 若要升级整组为 `raw_event_contract_verified`，需逐层补 ByteIO/TEA 证据

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Reply message pv/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7033046
- Digest: [[digests/digest_7033046_dm_conversion_funnel]]
- Numerator: `T1:reply_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: reply message per user
- Provenance: `raw/libra/libra_metric_group_7033046.json`
- Aggregation: pv / base_user
- Key filters:
  - 无显式过滤 - 这是标准消息漏斗，不依赖 MuF / group 等切片过滤
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - It still does not provide full ByteIO contract verification for each funnel stage, so this stops at event-family confidence rather than contract confidence.
  - reply 层尚未完成 raw event contract 验证
  - 若要升级整组为 `raw_event_contract_verified`，需逐层补 ByteIO/TEA 证据

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Reply message uv/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7033046
- Digest: [[digests/digest_7033046_dm_conversion_funnel]]
- Numerator: `T1:reply_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: reply message penetration rate
- Provenance: `raw/libra/libra_metric_group_7033046.json`
- Aggregation: uv / base_user
- Key filters:
  - 无显式过滤 - 这是标准消息漏斗，不依赖 MuF / group 等切片过滤
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - It still does not provide full ByteIO contract verification for each funnel stage, so this stops at event-family confidence rather than contract confidence.
  - reply 层尚未完成 raw event contract 验证
  - 若要升级整组为 `raw_event_contract_verified`，需逐层补 ByteIO/TEA 证据

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Reply/Read PV rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7033046
- Digest: [[digests/digest_7033046_dm_conversion_funnel]]
- Numerator: `T1:reply_message_cnt` (type: `pv`)
- Denominator: `T1:read_message_cnt` (type: `pv`)
- Description: reply message/read message pv rate
- Provenance: `raw/libra/libra_metric_group_7033046.json`
- Aggregation: pv / pv
- Key filters:
  - 无显式过滤 - 这是标准消息漏斗，不依赖 MuF / group 等切片过滤
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - It still does not provide full ByteIO contract verification for each funnel stage, so this stops at event-family confidence rather than contract confidence.
  - reply 层尚未完成 raw event contract 验证
  - 若要升级整组为 `raw_event_contract_verified`，需逐层补 ByteIO/TEA 证据

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Reply/Read UV rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7033046
- Digest: [[digests/digest_7033046_dm_conversion_funnel]]
- Numerator: `T1:reply_message_cnt` (type: `uv`)
- Denominator: `T1:read_message_cnt` (type: `uv`)
- Description: reply message/read message uv rate
- Provenance: `raw/libra/libra_metric_group_7033046.json`
- Aggregation: uv / uv
- Key filters:
  - 无显式过滤 - 这是标准消息漏斗，不依赖 MuF / group 等切片过滤
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - It still does not provide full ByteIO contract verification for each funnel stage, so this stops at event-family confidence rather than contract confidence.
  - reply 层尚未完成 raw event contract 验证
  - 若要升级整组为 `raw_event_contract_verified`，需逐层补 ByteIO/TEA 证据

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send message uv/user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7033046
- Digest: [[digests/digest_7033046_dm_conversion_funnel]]
- Numerator: `T1:send_message_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message penetration rate
- Provenance: `raw/libra/libra_metric_group_7033046.json`
- Aggregation: uv / base_user
- Key filters:
  - 无显式过滤 - 这是标准消息漏斗，不依赖 MuF / group 等切片过滤
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
- Boundary notes:
  - It still does not provide full ByteIO contract verification for each funnel stage, so this stops at event-family confidence rather than contract confidence.
  - reply 层尚未完成 raw event contract 验证
  - 若要升级整组为 `raw_event_contract_verified`，需逐层补 ByteIO/TEA 证据

<!-- AUTO-GENERATED:metric_fields:end -->
