# Metrics By Group | Activity Status User Metrics

group_id: 7041632
canonical_name: Activity Status User Metrics
tags: metric-group, dm
wiki_digests: [[digests/digest_7041632_activity_status_user_metrics]]
wiki_matrices: [[digests/event_metric_matrix_7041632_activity_status_user_metrics]]

## Metrics

- base_user
  - metric_id: `702585`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_702585.md`
- activity_status_permit_uv/Dau
  - metric_id: `702586`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_activity_status_permit_uv_dau__id_702586.md`
- new_activity_status_permit_uv/Dau
  - metric_id: `702587`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_new_activity_status_permit_uv_dau__id_702587.md`
- Show uv / Dau
  - metric_id: `702588`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_show_uv_dau__id_702588.md`
- Click uv / Dau
  - metric_id: `702589`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_uv_dau__id_702589.md`
- Inbox top show uv / Dau
  - metric_id: `702590`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_top_show_uv_dau__id_702590.md`
- Inbox top click uv / Dau
  - metric_id: `702591`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_top_click_uv_dau__id_702591.md`
- Inbox top Uctr
  - metric_id: `702592`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_inbox_top_uctr__id_702592.md`
- Chat cell show uv / Dau
  - metric_id: `702593`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_chat_cell_show_uv_dau__id_702593.md`
- Chat cell click uv / Dau
  - metric_id: `702594`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_chat_cell_click_uv_dau__id_702594.md`
- Chat cell Uctr
  - metric_id: `702595`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_chat_cell_uctr__id_702595.md`
- Share panel show uv / Dau
  - metric_id: `702596`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_panel_show_uv_dau__id_702596.md`
- Share panel click uv / Dau
  - metric_id: `702597`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_panel_click_uv_dau__id_702597.md`
- Share panel Uctr
  - metric_id: `702598`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_share_panel_uctr__id_702598.md`
- Long press panel show uv / Dau
  - metric_id: `702599`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_panel_show_uv_dau__id_702599.md`
- Long press panel click uv / Dau
  - metric_id: `702600`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_panel_click_uv_dau__id_702600.md`
- Long press panel Uctr
  - metric_id: `702601`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_panel_uctr__id_702601.md`
- Friend online inner push show uv / Dau
  - metric_id: `702602`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_friend_online_inner_push_show_uv_dau__id_702602.md`
- Friend online inner push  click uv / Dau
  - metric_id: `702603`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_friend_online_inner_push_click_uv_dau__id_702603.md`
- Friend online inner push Uctr
  - metric_id: `702604`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_friend_online_inner_push_uctr__id_702604.md`
- Cold start inner push show uv / Dau
  - metric_id: `702605`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cold_start_inner_push_show_uv_dau__id_702605.md`
- Cold start inner push  click uv / Dau
  - metric_id: `702606`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cold_start_inner_push_click_uv_dau__id_702606.md`
- Cold start inner push Uctr
  - metric_id: `702607`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_cold_start_inner_push_uctr__id_702607.md`
- Outer push show uv / Dau
  - metric_id: `702608`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_outer_push_show_uv_dau__id_702608.md`
- Outer push  click uv / Dau
  - metric_id: `702609`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_outer_push_click_uv_dau__id_702609.md`
- Outer push Uctr
  - metric_id: `702610`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_outer_push_uctr__id_702610.md`

## Auto Definitions (Excerpt)

### Metric: activity_status_permit_uv/Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:with_default_on_activity_status_new` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: (null_on uv +on_uv)/ dau
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: base_user (702585)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `user` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Chat cell click uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_chat_cell_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 聊天框在线状态点击渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Chat cell show uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_chat_cell_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 聊天框在线状态展现渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Chat cell Uctr
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_inbox_top_click_cnt` (type: `uv`)
- Denominator: `T1:activity_status_chat_cell_show_cnt` (type: `uv`)
- Description: 聊天框在线状态点击率
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / uv
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Click uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 在线状态点击渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cold start inner push  click uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_coldstart_push_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 冷启好友在线push点击渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cold start inner push show uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_coldstart_push_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 冷启好友在线push展现渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Cold start inner push Uctr
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_coldstart_push_click_cnt` (type: `uv`)
- Denominator: `T1:activity_status_coldstart_push_show_cnt` (type: `uv`)
- Description: 冷启好友在线push点击率
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / uv
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Friend online inner push  click uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_online_push_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 好友上线push点击渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Friend online inner push show uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_online_push_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 好友上线push展现渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Friend online inner push Uctr
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_online_push_click_cnt` (type: `uv`)
- Denominator: `T1:activity_status_online_push_show_cnt` (type: `uv`)
- Description: 好友上线push点击率
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / uv
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox top click uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_inbox_top_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox天窗在线状态点击渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox top show uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_inbox_top_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: inbox天窗在线状态展现渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Inbox top Uctr
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_inbox_top_click_cnt` (type: `uv`)
- Denominator: `T1:activity_status_inbox_top_show_cnt` (type: `uv`)
- Description: inbox天窗在线状态点击率
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / uv
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Long press panel click uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_long_press_panel_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 长按面板在线状态点击渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Long press panel show uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_long_press_panel_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 长按面板在线状态展现渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Long press panel Uctr
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_long_press_panel_click_cnt` (type: `uv`)
- Denominator: `T1:activity_status_long_press_panel_show_cnt` (type: `uv`)
- Description: 长按面板在线状态点击率
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / uv
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: new_activity_status_permit_uv/Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:is_activity_status_turn_on` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 当天手动打开授权的渗透（不包含默认打开的）
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Outer push  click uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_outer_push_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 站外push点击渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Outer push show uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:receive_activity_status_outer_push_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 站外push展现渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Outer push Uctr
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_outer_push_click_cnt` (type: `uv`)
- Denominator: `T1:receive_activity_status_outer_push_cnt` (type: `uv`)
- Description: 站外push点击率
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / uv
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Share panel click uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_share_panel_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 分享面板在线状态点击渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Share panel show uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_share_panel_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 分享面板在线状态展现渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Share panel Uctr
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_share_panel_click_cnt` (type: `uv`)
- Denominator: `T1:activity_status_share_panel_show_cnt` (type: `uv`)
- Description: 分享面板在线状态 点击率
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / uv
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Show uv / Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7041632
- Digest: [[digests/digest_7041632_activity_status_user_metrics]]
- Numerator: `T1:activity_status_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 在线状态展现渗透
- Provenance: `raw/libra/libra_metric_group_7041632.json`
- Aggregation: uv / base_user
- Key filters:
  - `surface=inbox_top` - 区分顶部入口用户覆盖
- Source tables (from digest):
  - [[tables/table_musically-adl-social-activity-status-metric-daily]]
  - [[tables/table_musically-adl-social-user-activity-status-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - Raw-event contract resolution is still absent.
  - permit / show / click 的 raw contract 仍未独立确认

<!-- AUTO-GENERATED:metric_fields:end -->
