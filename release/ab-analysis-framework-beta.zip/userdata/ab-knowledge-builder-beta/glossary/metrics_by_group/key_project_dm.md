# Metrics By Group | Key Project-DM

group_id: 7019062
canonical_name: Key Project-DM
tags: metric-group, dm
wiki_digests: [[digests/digest_7019062_key_project_dm]]
wiki_matrices: [[digests/event_metric_matrix_7019062]]

## Metrics

- User
  - metric_id: `3229481`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base-user__id_3229481.md`
- User
  - metric_id: `3229481`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_user__id_3229481.md`
- Social MUF Send or Like Message Days/Days
  - metric_id: `3229482`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_like-or-send-muf-message-cnt-active-days-per-base-active-days__id_3229482.md`
- Social MUF Send or Like Message Days/Days
  - metric_id: `3229482`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_social_muf_send_or_like_message_days_days__id_3229482.md`
- Social MUF Send or Like Message Days/User
  - metric_id: `3229483`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_like-or-send-muf-message-cnt-active-days-per-user__id_3229483.md`
- Social MUF Send or Like Message Days/User
  - metric_id: `3229483`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_social_muf_send_or_like_message_days_user__id_3229483.md`
- Social MUF Send or Like Message Pair/User
  - metric_id: `3229484`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send-or-like-muf-message-pair-cnt-per-user__id_3229484.md`
- Social MUF Send or Like Message Pair/User
  - metric_id: `3229484`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_social_muf_send_or_like_message_pair_user__id_3229484.md`
- Social MUF Send or Like Message PV/User
  - metric_id: `3229485`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_like-or-send-muf-message-cnt-per-user__id_3229485.md`
- Social MUF Send or Like Message PV/User
  - metric_id: `3229485`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_social_muf_send_or_like_message_pv_user__id_3229485.md`
- Send or Like Message Days/Days
  - metric_id: `3229486`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send-or-like-message-cnt-active-days-per-base-active-days__id_3229486.md`
- Send or Like Message Days/Days
  - metric_id: `3229486`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_or_like_message_days_days__id_3229486.md`
- Send or Like Message Days/User
  - metric_id: `3229487`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send-or-like-message-cnt-active-days-per-user__id_3229487.md`
- Send or Like Message Days/User
  - metric_id: `3229487`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_or_like_message_days_user__id_3229487.md`
- Send or Like Message PV/User
  - metric_id: `3229488`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send-or-like-message-cnt-per-user__id_3229488.md`
- Send or Like Message PV/User
  - metric_id: `3229488`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_or_like_message_pv_user__id_3229488.md`
- Receive or Liked Message Days/Days
  - metric_id: `3229489`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive_or_liked_message_days_days__id_3229489.md`
- Receive or Liked Message Days/Days
  - metric_id: `3229489`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_recieve-or-liked-message-cnt-active-days-per-base-active-days__id_3229489.md`
- Receive or Liked Message Days/User
  - metric_id: `3229490`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive_or_liked_message_days_user__id_3229490.md`
- Receive or Liked Message Days/User
  - metric_id: `3229490`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_recieve-or-liked-message-cnt-active-days-per-user__id_3229490.md`
- Receive or Liked Message PV/User
  - metric_id: `3229491`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive-or-liked-message-cnt-per-user__id_3229491.md`
- Receive or Liked Message PV/User
  - metric_id: `3229491`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_receive_or_liked_message_pv_user__id_3229491.md`
- FYP Internal Share PV/User
  - metric_id: `3229492`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_fyp_internal_share_pv_user__id_3229492.md`
- FYP Internal Share PV/User
  - metric_id: `3229492`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_hot-share-video-internal-cnt-per-user__id_3229492.md`
- Group Send or Like Message Days/Days
  - metric_id: `3229493`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_send_or_like_message_days_days__id_3229493.md`
- Group Send or Like Message Days/Days
  - metric_id: `3229493`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send-or-like-message-by-group-cnt-active-days-per-base-active-days__id_3229493.md`
- Group Send or Like Message Days/User
  - metric_id: `3229494`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_send_or_like_message_days_user__id_3229494.md`
- Group Send or Like Message Days/User
  - metric_id: `3229494`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send-or-like-message-by-group-cnt-active-days-per-user__id_3229494.md`
- Last 7-day Social MUF Send or Like Message Pair/User
  - metric_id: `3229495`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_last_7_day_social_muf_send_or_like_message_pair_user__id_3229495.md`
- Last 7-day Social MUF Send or Like Message Pair/User
  - metric_id: `3229495`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send-or-like-muf-message-pair-cnt-7d-per-user__id_3229495.md`

## Auto Definitions (Excerpt)

### Metric: User (3229481)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: FYP Internal Share PV/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:hot_share_video_internal_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: FYP Internal Share PV / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Send or Like Message Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:send_or_like_message_by_group_cnt_active_days` (type: `pv`)
- Denominator: `T0:base_active_days` (type: `pv`)
- Description: Days of Group Send or Like Message Days / Active days
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Send or Like Message Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:send_or_like_message_by_group_cnt_active_days` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Days of Group Send or Like Message Days / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: FYP Internal Share PV/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:hot_share_video_internal_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: FYP Internal Share PV / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Last 7-day Social MUF Send or Like Message Pair/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:send_or_like_muf_message_pair_cnt` (type: `cross_days_action`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Last 7-day Social MUF Send or Like Message Pair / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Social MUF Send or Like Message Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:like_or_send_muf_message_cnt_active_days` (type: `pv`)
- Denominator: `T0:base_active_days` (type: `pv`)
- Description: Days of Social MUF Send or Like Message Days / Active days
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Social MUF Send or Like Message Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:like_or_send_muf_message_cnt_active_days` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Days of Social MUF Send or Like Message Days / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Social MUF Send or Like Message PV/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:like_or_send_muf_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Social MUF Send or Like Message PV / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive or Liked Message PV/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:receive_or_liked_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Receive or Liked Message PV / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive or Liked Message Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:recieve_or_liked_message_cnt_active_days` (type: `pv`)
- Denominator: `T0:base_active_days` (type: `pv`)
- Description: Days of Receive or Liked Message Days / Active days
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive or Liked Message Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:recieve_or_liked_message_cnt_active_days` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Days of Receive or Liked Message Days / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive or Liked Message PV/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:receive_or_liked_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Receive or Liked Message PV / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive or Liked Message Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:recieve_or_liked_message_cnt_active_days` (type: `pv`)
- Denominator: `T0:base_active_days` (type: `pv`)
- Description: Days of Receive or Liked Message Days / Active days
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Receive or Liked Message Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:recieve_or_liked_message_cnt_active_days` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Days of Receive or Liked Message Days / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Send or Like Message Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:send_or_like_message_by_group_cnt_active_days` (type: `pv`)
- Denominator: `T0:base_active_days` (type: `pv`)
- Description: Days of Group Send or Like Message Days / Active days
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group Send or Like Message Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:send_or_like_message_by_group_cnt_active_days` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Days of Group Send or Like Message Days / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send or Like Message Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:send_or_like_message_cnt_active_days` (type: `pv`)
- Denominator: `T0:base_active_days` (type: `pv`)
- Description: Days of Send or Like Message Days / Active days
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send or Like Message Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:send_or_like_message_cnt_active_days` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Days of Send or Like Message Days / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send or Like Message PV/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:send_or_like_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send or Like Message PV / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Last 7-day Social MUF Send or Like Message Pair/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:send_or_like_muf_message_pair_cnt` (type: `cross_days_action`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Last 7-day Social MUF Send or Like Message Pair / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Social MUF Send or Like Message Pair/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:send_or_like_muf_message_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Social MUF Send or Like Message Pair / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send or Like Message Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:send_or_like_message_cnt_active_days` (type: `pv`)
- Denominator: `T0:base_active_days` (type: `pv`)
- Description: Days of Send or Like Message Days / Active days
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send or Like Message Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:send_or_like_message_cnt_active_days` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Days of Send or Like Message Days / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send or Like Message PV/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:send_or_like_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Send or Like Message PV / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Social MUF Send or Like Message Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:like_or_send_muf_message_cnt_active_days` (type: `pv`)
- Denominator: `T0:base_active_days` (type: `pv`)
- Description: Days of Social MUF Send or Like Message Days / Active days
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Social MUF Send or Like Message Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:like_or_send_muf_message_cnt_active_days` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Days of Social MUF Send or Like Message Days / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Social MUF Send or Like Message Pair/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:send_or_like_muf_message_pair_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Social MUF Send or Like Message Pair / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Social MUF Send or Like Message PV/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `T0:like_or_send_muf_message_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Social MUF Send or Like Message PV / Base users
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: User (3229481)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7019062
- Digest: [[digests/digest_7019062_key_project_dm]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7019062.json`
- Key filters:
  - `params['chat_type']` - 群聊/私聊过滤
  - `params['follow_status_relation']` - MuF互关过滤
  - `metric IN ('direct_message_json','direct_message_pair_json')` - JSON指标过滤
- Source tables (from digest):
  - [[tables/table_musically-adl-user-direct-message-metric-daily]]
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - **仍停留在 `aggregate_field_confirmed_raw_event_unverified` 的字段族**：

<!-- AUTO-GENERATED:metric_fields:end -->
