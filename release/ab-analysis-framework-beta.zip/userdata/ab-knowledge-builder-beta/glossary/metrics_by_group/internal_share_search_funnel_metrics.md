# Metrics By Group | internal share search funnel metrics

group_id: 7054477
canonical_name: internal share search funnel metrics
tags: metric-group, dm
wiki_digests: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
wiki_matrices: [[digests/event_metric_matrix_7054477_internal_share_search_funnel_metrics]]

## Metrics

- base_user
  - metric_id: `2285310`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_2285310.md`
- click share search show uv / au
  - metric_id: `2285311`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_search_show_uv_au__id_2285311.md`
- click share search click uv / au
  - metric_id: `2285312`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_search_click_uv_au__id_2285312.md`
- click share search list show uv / au
  - metric_id: `2285313`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_search_list_show_uv_au__id_2285313.md`
- click share search list share uv / au
  - metric_id: `2285314`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_search_list_share_uv_au__id_2285314.md`
- click share search list share pv / au
  - metric_id: `2285315`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_search_list_share_pv_au__id_2285315.md`
- click share search click pv / click share search show uv
  - metric_id: `2285316`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_search_click_pv_click_share_search_show_uv__id_2285316.md`
- click share  search list show pv/ click share search click uv
  - metric_id: `2285317`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_search_list_show_pv_click_share_search_click_uv__id_2285317.md`
- click share  search list share pv /click share search list show uv
  - metric_id: `2285318`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_search_list_share_pv_click_share_search_list_show_uv__id_2285318.md`
- click share search click pv / click share search show pv
  - metric_id: `2285319`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_search_click_pv_click_share_search_show_pv__id_2285319.md`
- click share  search list share pv/click share search list show pv
  - metric_id: `2285320`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_click_share_search_list_share_pv_click_share_search_list_show_pv__id_2285320.md`
- long press share search show uv / au
  - metric_id: `2285321`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_search_show_uv_au__id_2285321.md`
- long press share search click uv / au
  - metric_id: `2285322`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_search_click_uv_au__id_2285322.md`
- long press share  search list show uv / au
  - metric_id: `2285323`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_search_list_show_uv_au__id_2285323.md`
- long press share  search list share uv / au
  - metric_id: `2285324`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_search_list_share_uv_au__id_2285324.md`
- long press share  search list share pv / au
  - metric_id: `2285325`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_search_list_share_pv_au__id_2285325.md`
- long press share search click pv /long press share search show uv
  - metric_id: `2285326`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_search_click_pv_long_press_share_search_show_uv__id_2285326.md`
- long press share  search list show pv/long press share search click uv
  - metric_id: `2285327`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_search_list_show_pv_long_press_share_search_click_uv__id_2285327.md`
- long press share  search list share pv /long press share  search list show uv
  - metric_id: `2285328`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_search_list_share_pv_long_press_share_search_list_show_uv__id_2285328.md`
- long press share search click pv /long press  share search show pv
  - metric_id: `2285329`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_search_click_pv_long_press_share_search_show_pv__id_2285329.md`
- long press share  search list share pv/long press share  search list show pv
  - metric_id: `2285330`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_long_press_share_search_list_share_pv_long_press_share_search_list_show_pv__id_2285330.md`

## Auto Definitions (Excerpt)

### Metric: base_user (2285310)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share search click pv / click share search show pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:share_panel_search_click_cnt` (type: `pv`)
- Denominator: `T1:share_panel_search_show_cnt` (type: `pv`)
- Description: 点击more拉起面板后，搜索入口 点击pv/曝光pv
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: pv / pv
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share search click pv / click share search show uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:share_panel_search_click_cnt` (type: `pv`)
- Denominator: `T1:share_panel_search_show_cnt` (type: `uv`)
- Description: 点击more曝光搜索入口后，人均点击次数
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: pv / uv
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share search click uv / au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:share_panel_search_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 点击more拉起面板后点击搜索入口
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: uv / base_user
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share search list share pv / au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:share_panel_search_share_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 点击more人均分享次数
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share  search list share pv/click share search list show pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:share_panel_search_share_cnt` (type: `pv`)
- Denominator: `T1:share_panel_search_show_user_cnt` (type: `pv`)
- Description: 点击more点击搜索头像曝光后，分享次数/曝光头像次数
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: pv / pv
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share  search list share pv /click share search list show uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:share_panel_search_share_cnt` (type: `pv`)
- Denominator: `T1:share_panel_search_show_user_cnt` (type: `uv`)
- Description: 点击more头像曝光后，人均分享次数
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: pv / uv
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share search list share uv / au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:share_panel_search_share_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 点击more搜索分享渗透
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share  search list show pv/ click share search click uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:share_panel_search_show_user_cnt` (type: `pv`)
- Denominator: `T1:share_panel_search_click_cnt` (type: `uv`)
- Description: 点击more点击搜索后，人均曝光头像次数
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: pv / uv
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share search list show uv / au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:share_panel_search_show_user_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 点击more点击搜索后，好友列表曝光
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: uv / base_user
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: click share search show uv / au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:share_panel_search_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 点击more拉起面板后，曝光搜索入口
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: uv / base_user
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share search click pv /long press  share search show pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:long_press_search_click_cnt` (type: `pv`)
- Denominator: `T1:long_press_search_show_cnt` (type: `pv`)
- Description: 长按面板拉起面板后，搜索入口 点击pv/曝光pv
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: pv / pv
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share search click pv /long press share search show uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:long_press_search_click_cnt` (type: `pv`)
- Denominator: `T1:long_press_search_show_cnt` (type: `uv`)
- Description: 长按面板曝光搜索入口后，人均点击次数
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: pv / uv
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share search click uv / au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:long_press_search_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 长按面板拉起面板后点击搜索入口
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: uv / base_user
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share  search list share pv / au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:long_press_search_share_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 长按面板人均分享次数
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: pv / base_user
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share  search list share pv/long press share  search list show pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:long_press_search_share_cnt` (type: `pv`)
- Denominator: `T1:long_press_search_show_user_cnt` (type: `pv`)
- Description: 长按面板点击搜多头像曝光后，分享次数/曝光头像次数
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: pv / pv
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share  search list share pv /long press share  search list show uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:long_press_search_share_cnt` (type: `pv`)
- Denominator: `T1:long_press_search_show_user_cnt` (type: `uv`)
- Description: 长按面板头像曝光后，人均分享次数
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: pv / uv
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share  search list share uv / au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:long_press_search_share_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 长按面板搜索分享渗透
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: uv / base_user
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share  search list show pv/long press share search click uv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:long_press_search_show_user_cnt` (type: `pv`)
- Denominator: `T1:long_press_search_click_cnt` (type: `uv`)
- Description: 长按面板点击搜索后，人均曝光头像次数
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: pv / uv
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share  search list show uv / au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:long_press_search_show_user_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 长按面板点击搜索后，好友列表曝光
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: uv / base_user
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: long press share search show uv / au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7054477
- Digest: [[digests/digest_7054477_internal_share_search_funnel_metrics]]
- Numerator: `T1:long_press_search_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 长按面板拉起面板后，曝光搜索入口
- Provenance: `raw/libra/libra_metric_group_7054477.json`
- Aggregation: uv / base_user
- Key filters:
  - `search` - 区分搜索子链路和普通分享链路
  - `list_show`, `list_share` - 区分候选列表曝光与最终发送
- Source tables (from digest):
  - [[tables/table_musically-adl-ug-device-share-metric-daily]]
  - [[tables/table_musically-adl-ug-user-share-metric-daily]]
- Boundary notes:
  - 尚未把 share-search 各阶段映射到唯一 raw event contract

<!-- AUTO-GENERATED:metric_fields:end -->
