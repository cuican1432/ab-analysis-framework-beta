# Metrics By Group | [IM] New gt3-users Group Chat 14d Retention

group_id: 7056673
canonical_name: [IM] New gt3-users Group Chat 14d Retention
tags: metric-group, dm
wiki_digests: [[digests/digest_7056673_dm_group_chat_14d_retention_new_gt3_users]]
wiki_matrices: [[digests/event_metric_matrix_7056673_dm_group_chat_14d_retention_new_gt3_users]]

## Metrics

- base_user
  - metric_id: `2780352`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_2780352.md`
- 14d retention
  - metric_id: `2780353`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_14d_retention__id_2780353.md`

## Auto Definitions (Excerpt)

### Metric: 14d retention (2780353)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7056673
- Digest: [[digests/digest_7056673_dm_group_chat_14d_retention_new_gt3_users]]
- Numerator: `T7:new_group_chat_ret_14d` (type: `pv`)
- Denominator: `T7:new_group_chat` (type: `pv`)
- Description: 14d retention
- Provenance: `raw/libra/libra_metric_group_7056673.json`
- Field family: `group_chat_retention_14d_gt3_core`
- Aggregation: `pv/pv`
- Meaning: 高价值新建群 cohort 在 14d 窗口后的留存率
- Key filters:
  - `14d` - 指定两周窗口留存
  - `new gt3-users` - 将 cohort 限定为高价值新建群用户
  - numerator / denominator pair - 拆解 cohort 创建与 survival 变化
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-im-new-gt3-users-group-chat-retention-14d-di]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: base_user (2780352)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7056673
- Digest: [[digests/digest_7056673_dm_group_chat_14d_retention_new_gt3_users]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7056673.json`
- Key filters:
  - `14d` - 指定两周窗口留存
  - `new gt3-users` - 将 cohort 限定为高价值新建群用户
  - numerator / denominator pair - 拆解 cohort 创建与 survival 变化
- Source tables (from digest):
  - [[tables/table_musically-app-abtest-social-im-new-gt3-users-group-chat-retention-14d-di]]

<!-- AUTO-GENERATED:metric_fields:end -->
