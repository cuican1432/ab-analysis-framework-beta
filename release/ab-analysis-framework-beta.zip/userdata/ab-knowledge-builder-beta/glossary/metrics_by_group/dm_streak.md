# Metrics By Group | DM_streak

group_id: 7045333
canonical_name: DM_streak
tags: metric-group, dm
wiki_digests: [[digests/digest_7045333_dm_streak]]
wiki_matrices: [[digests/event_metric_matrix_7045333_dm_streak]]

## Metrics

- base_user
  - metric_id: `2780356`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_2780356.md`
- Streak uv/Dau
  - metric_id: `2780357`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_streak_uv_dau__id_2780357.md`
- Streak pair/Dau
  - metric_id: `2780358`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_streak_pair_dau__id_2780358.md`
- Streak break rate
  - metric_id: `2780359`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_streak_break_rate__id_2780359.md`
- streak break uv/Dau
  - metric_id: `2780360`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_streak_break_uv_dau__id_2780360.md`
- Streak pair/UV
  - metric_id: `2780361`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_streak_pair_uv__id_2780361.md`
- Streak new rate
  - metric_id: `2780362`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_streak_new_rate__id_2780362.md`
- streak new uv/Dau
  - metric_id: `2780363`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_streak_new_uv_dau__id_2780363.md`
- streak pet uv/Dau
  - metric_id: `2780364`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_streak_pet_uv_dau__id_2780364.md`
- streak pet pair/Dau
  - metric_id: `2780365`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_streak_pet_pair_dau__id_2780365.md`
- new streak pet pair/Dau
  - metric_id: `2780366`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_new_streak_pet_pair_dau__id_2780366.md`
- break streak pet pair/Dau
  - metric_id: `2780367`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_break_streak_pet_pair_dau__id_2780367.md`
- Group chat streak user uv/au
  - metric_id: `2780368`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_streak_user_uv_au__id_2780368.md`
- Group chat streaks new user uv/au
  - metric_id: `2780369`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_streaks_new_user_uv_au__id_2780369.md`
- Group chat streaks break rate
  - metric_id: `2780370`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_streaks_break_rate__id_2780370.md`
- All DM streaks uv/au
  - metric_id: `2780371`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_all_dm_streaks_uv_au__id_2780371.md`
- Group chat streak active user uv/au
  - metric_id: `2780372`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_streak_active_user_uv_au__id_2780372.md`
- Group chat streaks active new user uv/au
  - metric_id: `2780373`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_streaks_active_new_user_uv_au__id_2780373.md`
- Group chat streaks active break uv rate
  - metric_id: `2780374`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_group_chat_streaks_active_break_uv_rate__id_2780374.md`
- All DM active streaks uv/au
  - metric_id: `2780375`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_all_dm_active_streaks_uv_au__id_2780375.md`

## Auto Definitions (Excerpt)

### Metric: All DM active streaks uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:is_active_in_all_dm_streak_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Private chat + Group chat streak active uv/au (deduplicated)
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Field family: `group_chat_streak_active`
- Aggregation: `uv/base_user`
- Meaning: 所有 DM streak 中满足 active 定义的用户覆盖
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: All DM streaks uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:all_dm_streak_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Private chat + Group chat streak uv/au (deduplicated)
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: base_user (2780356)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: break streak pet pair/Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:break_streak_pet_chat_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均断聊火人用户对
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group chat streak active user uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:is_active_in_group_chat_streak` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Active user cnt (has to be active in group chat) of users in a group chat with streak_day_cnt >=3 / dau
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Field family: `group_chat_streak_active`
- Aggregation: `uv/base_user`
- Meaning: 群 streak 中仍活跃的用户覆盖
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group chat streak user uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:group_chat_streak_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Active user cnt (does not have to be active in group) of users in a group chat with streak_day_cnt >=3 / dau
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Field family: `group_chat_streak_active`
- Aggregation: `uv/base_user`
- Meaning: 处于群 streak 库存的用户覆盖
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group chat streaks active break uv rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:is_active_in_break_group_chat_streak` (type: `uv`)
- Denominator: `T1:group_chat_streak_cnt_prev_1d` (type: `uv`)
- Description: Active user cnt (has to be active in group chat) of users in a group chat who broke streaks today / Active user cnt (does not have to be active in group) of users in a group chat with streak_day_cnt >=3 yesterday
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group chat streaks active new user uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:is_active_in_new_group_chat_streak` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Active user cnt (has to be active in group chat) of users in a group chat with streak_day_cnt =3 / dau
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group chat streaks break rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:group_chat_break_streak_cnt` (type: `pv`)
- Denominator: `T1:group_chat_streak_cnt_prev_1d` (type: `pv`)
- Description: 群聊断火率 （当天断火的群数/前一天有火花的群数）
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Field family: `group_chat_streak_active`
- Aggregation: `pv/pv`
- Meaning: 群 streak 的断裂率
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Group chat streaks new user uv/au
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:group_chat_new_streak_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Active user cnt (does not have to be active in group) of users in a group chat with streak_day_cnt =3 / dau
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: new streak pet pair/Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:new_streak_pet_chat_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均新领养宠物火花对
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Field family: `dm_streak_pet`
- Aggregation: `pv/base_user`
- Meaning: pet streak 新增关系对数
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Streak break rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:break_streak_chat_cnt` (type: `pv`)
- Denominator: `T1:streak_chat_cnt_prev_1d` (type: `pv`)
- Description: 断火率 （当天断火的pair数/前一天pair数）
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Field family: `dm_streak_transition`
- Aggregation: `pv/pv`
- Meaning: 前日 streak 库存在当日断裂的占比
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: streak break uv/Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:break_streak_chat_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 断火渗透
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Streak new rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:new_streak_chat_cnt` (type: `pv`)
- Denominator: `T1:streak_chat_cnt` (type: `pv`)
- Description: 新增火花占比 （当天新增火花/当天pair数）
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Field family: `dm_streak_transition`
- Aggregation: `pv/pv`
- Meaning: 当日 streak 中新增部分占比
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: streak new uv/Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:new_streak_chat_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 新增火花渗透
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Streak pair/Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:streak_chat_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均火花对数
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Field family: `dm_streak_core`
- Aggregation: `pv/base_user`
- Meaning: streak 关系对数强度
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Streak pair/UV
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:streak_chat_cnt` (type: `pv`)
- Denominator: `T1:streak_chat_cnt` (type: `uv`)
- Description: 火花用户人均有几对火花
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: streak pet pair/Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:streak_pet_chat_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 人均有宠物的火花对
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: streak pet uv/Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:streak_pet_chat_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 有宠物的火花渗透
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Field family: `dm_streak_pet`
- Aggregation: `uv/base_user`
- Meaning: pet streak 用户覆盖
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Streak uv/Dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7045333
- Digest: [[digests/digest_7045333_dm_streak]]
- Numerator: `T1:streak_chat_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: 有火花渗透
- Provenance: `raw/libra/libra_metric_group_7045333.json`
- Field family: `dm_streak_core`
- Aggregation: `uv/base_user`
- Meaning: 处于私聊 streak 库存中的用户覆盖
- Key filters:
  - `send_message_active_days_14d_layer` - 对 streak 用户活跃天数做分层
  - `mutual_follow_cnt_td_prev_1d_layer` - 观察关系强度对 streak 稳定性的影响
  - `*_prev_1d` - 作为 break/new rate 的库存分母
  - `is_active_in_*` - 在 streak 库存上叠加活跃质量定义
- Source tables (from digest):
  - [[tables/table_musically-adl-user-streak-df]]
  - [[tables/table_musically-adl-abtest-user-core-metric-daily]]
  - [[tables/table_musically-mds-dim-user-social-ext]]

<!-- AUTO-GENERATED:metric_fields:end -->
