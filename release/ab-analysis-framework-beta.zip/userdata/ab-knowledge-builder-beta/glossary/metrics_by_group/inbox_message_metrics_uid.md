# Metrics By Group | Inbox message metrics uid

group_id: 7032462
canonical_name: Inbox message metrics uid
tags: metric-group, dm
wiki_digests: [[digests/digest_7032462_inbox_message_metrics_uid]]
wiki_matrices: [[digests/event_metric_matrix_7032462_inbox_message_metrics_uid]]

## Metrics

- base_user
  - metric_id: `3417532`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base_user__id_3417532.md`
- Notification_message_show_user/dau
  - metric_id: `3417533`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_message_show_user_dau__id_3417533.md`
- Notification_message_show_pv/dau
  - metric_id: `3417534`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_message_show_pv_dau__id_3417534.md`
- Notification_message_click_user/dau
  - metric_id: `3417535`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_message_click_user_dau__id_3417535.md`
- Notification_message_click_pv/dau
  - metric_id: `3417536`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_message_click_pv_dau__id_3417536.md`
- Notification_message_click_user/show_user
  - metric_id: `3417537`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_message_click_user_show_user__id_3417537.md`
- Notification_message_click_pv/show_pv
  - metric_id: `3417538`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_message_click_pv_show_pv__id_3417538.md`
- Official_message_show_user/dau
  - metric_id: `3417539`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_official_message_show_user_dau__id_3417539.md`
- Official_message_show_pv/dau
  - metric_id: `3417540`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_official_message_show_pv_dau__id_3417540.md`
- Official_message_click_user/dau
  - metric_id: `3417541`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_official_message_click_user_dau__id_3417541.md`
- Official_message_click_pv/dau
  - metric_id: `3417542`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_official_message_click_pv_dau__id_3417542.md`
- Official_message_click_user/show_user
  - metric_id: `3417543`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_official_message_click_user_show_user__id_3417543.md`
- Official_message_click_pv/show_pv
  - metric_id: `3417544`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_official_message_click_pv_show_pv__id_3417544.md`
- Official_message_show_ucnt/dau
  - metric_id: `3417545`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_official_message_show_ucnt_dau__id_3417545.md`
- Official_message_click_ucnt/dau
  - metric_id: `3417546`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_official_message_click_ucnt_dau__id_3417546.md`
- Official_message_click_ucnt/show_ucnt
  - metric_id: `3417547`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_official_message_click_ucnt_show_ucnt__id_3417547.md`
- Notification_mention_aggregate_show_user/dau
  - metric_id: `3417548`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_mention_aggregate_show_user_dau__id_3417548.md`
- Notification_mention_aggregate_show_pv/dau
  - metric_id: `3417549`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_mention_aggregate_show_pv_dau__id_3417549.md`
- Notification_mention_aggregate_click_user/dau
  - metric_id: `3417550`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_mention_aggregate_click_user_dau__id_3417550.md`
- Notification_mention_aggregate_click_pv/dau
  - metric_id: `3417551`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_mention_aggregate_click_pv_dau__id_3417551.md`
- Notification_mention_aggregate_click_user/show_user
  - metric_id: `3417552`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_mention_aggregate_click_user_show_user__id_3417552.md`
- Notification_mention_aggregate_click_pv/show_pv
  - metric_id: `3417553`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_mention_aggregate_click_pv_show_pv__id_3417553.md`
- Notification_like_show_user/dau
  - metric_id: `3417554`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_like_show_user_dau__id_3417554.md`
- Notification_like_show_pv/dau
  - metric_id: `3417555`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_like_show_pv_dau__id_3417555.md`
- Notification_like_click_user/dau
  - metric_id: `3417556`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_like_click_user_dau__id_3417556.md`
- Notification_like_click_pv/dau
  - metric_id: `3417557`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_like_click_pv_dau__id_3417557.md`
- Notification_like_click_user/show_user
  - metric_id: `3417558`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_like_click_user_show_user__id_3417558.md`
- Notification_like_click_pv/show_pv
  - metric_id: `3417559`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_like_click_pv_show_pv__id_3417559.md`
- Notification_comment_show_user/dau
  - metric_id: `3417560`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_comment_show_user_dau__id_3417560.md`
- Notification_comment_show_pv/dau
  - metric_id: `3417561`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_comment_show_pv_dau__id_3417561.md`
- Notification_comment_click_user/dau
  - metric_id: `3417562`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_comment_click_user_dau__id_3417562.md`
- Notification_comment_click_pv/dau
  - metric_id: `3417563`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_comment_click_pv_dau__id_3417563.md`
- Notification_comment_click_user/show_user
  - metric_id: `3417564`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_comment_click_user_show_user__id_3417564.md`
- Notification_comment_click_pv/show_pv
  - metric_id: `3417565`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_comment_click_pv_show_pv__id_3417565.md`
- Notification_fans_show_user/dau
  - metric_id: `3417566`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_fans_show_user_dau__id_3417566.md`
- Notification_fans_show_pv/dau
  - metric_id: `3417567`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_fans_show_pv_dau__id_3417567.md`
- Notification_fans_click_user/dau
  - metric_id: `3417568`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_fans_click_user_dau__id_3417568.md`
- Notification_fans_click_pv/dau
  - metric_id: `3417569`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_fans_click_pv_dau__id_3417569.md`
- Notification_fans_click_user/show_user
  - metric_id: `3417570`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_fans_click_user_show_user__id_3417570.md`
- Notification_fans_click_pv/show_pv
  - metric_id: `3417571`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_fans_click_pv_show_pv__id_3417571.md`
- Notification_at_show_user/dau
  - metric_id: `3417572`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_at_show_user_dau__id_3417572.md`
- Notification_at_show_pv/dau
  - metric_id: `3417573`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_at_show_pv_dau__id_3417573.md`
- Notification_at_click_user/dau
  - metric_id: `3417574`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_at_click_user_dau__id_3417574.md`
- Notification_at_click_pv/dau
  - metric_id: `3417575`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_at_click_pv_dau__id_3417575.md`
- Notification_at_click_user/show_user
  - metric_id: `3417576`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_at_click_user_show_user__id_3417576.md`
- Notification_at_click_pv/show_pv
  - metric_id: `3417577`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_at_click_pv_show_pv__id_3417577.md`
- Notification_tag_show_user/dau
  - metric_id: `3417578`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_tag_show_user_dau__id_3417578.md`
- Notification_tag_show_pv/dau
  - metric_id: `3417579`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_tag_show_pv_dau__id_3417579.md`
- Notification_tag_click_user/dau
  - metric_id: `3417580`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_tag_click_user_dau__id_3417580.md`
- Notification_tag_click_pv/dau
  - metric_id: `3417581`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_tag_click_pv_dau__id_3417581.md`
- Notification_tag_click_user/show_user
  - metric_id: `3417582`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_tag_click_user_show_user__id_3417582.md`
- Notification_tag_click_pv/show_pv
  - metric_id: `3417583`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_tag_click_pv_show_pv__id_3417583.md`
- Notification_visitor_show_user/dau
  - metric_id: `3417584`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_visitor_show_user_dau__id_3417584.md`
- Notification_visitor_show_pv/dau
  - metric_id: `3417585`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_visitor_show_pv_dau__id_3417585.md`
- Notification_visitor_click_user/dau
  - metric_id: `3417586`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_visitor_click_user_dau__id_3417586.md`
- Notification_visitor_click_pv/dau
  - metric_id: `3417587`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_visitor_click_pv_dau__id_3417587.md`
- Notification_visitor_click_user/show_user
  - metric_id: `3417588`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_visitor_click_user_show_user__id_3417588.md`
- Notification_visitor_click_pv/show_pv
  - metric_id: `3417589`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_visitor_click_pv_show_pv__id_3417589.md`
- Notification_recommend_show_user/dau
  - metric_id: `3417590`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_recommend_show_user_dau__id_3417590.md`
- Notification_recommend_show_pv/dau
  - metric_id: `3417591`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_recommend_show_pv_dau__id_3417591.md`
- Notification_recommend_click_user/dau
  - metric_id: `3417592`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_recommend_click_user_dau__id_3417592.md`
- Notification_recommend_click_pv/dau
  - metric_id: `3417593`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_recommend_click_pv_dau__id_3417593.md`
- Notification_recommend_click_user/show_user
  - metric_id: `3417594`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_recommend_click_user_show_user__id_3417594.md`
- Notification_recommend_click_pv/show_pv
  - metric_id: `3417595`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_notification_recommend_click_pv_show_pv__id_3417595.md`

## Auto Definitions (Excerpt)

### Metric: base_user (3417532)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_at_click_pv/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_at_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_at_click_pv/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_at_click_pv/show_pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_at_click_cnt` (type: `pv`)
- Denominator: `T3:notification_at_show_cnt` (type: `pv`)
- Description: Notification_at_click_pv/show_pv
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: pv / pv
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_at_click_user/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_at_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_at_click_user/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_at_click_user/show_user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_at_click_cnt` (type: `uv`)
- Denominator: `T3:notification_at_show_cnt` (type: `uv`)
- Description: Notification_at_click_user/show_user
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: uv / uv
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_at_show_pv/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_at_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_at_show_pv/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_at_show_user/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_at_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_at_show_user/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_comment_click_pv/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_comment_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_comment_click_pv/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_comment_click_pv/show_pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_comment_click_cnt` (type: `pv`)
- Denominator: `T3:notification_comment_show_cnt` (type: `pv`)
- Description: Notification_comment_click_pv/show_pv
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: pv / pv
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_comment_click_user/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_comment_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_comment_click_user/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_comment_click_user/show_user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_comment_click_cnt` (type: `uv`)
- Denominator: `T3:notification_comment_show_cnt` (type: `uv`)
- Description: Notification_comment_click_user/show_user
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: uv / uv
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_comment_show_pv/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_comment_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_comment_show_pv/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_comment_show_user/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_comment_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_comment_show_user/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_fans_click_pv/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_fans_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_fans_click_pv/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_fans_click_pv/show_pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_fans_click_cnt` (type: `pv`)
- Denominator: `T3:notification_fans_show_cnt` (type: `pv`)
- Description: Notification_fans_click_pv/show_pv
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: pv / pv
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_fans_click_user/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_fans_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_fans_click_user/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_fans_click_user/show_user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_fans_click_cnt` (type: `uv`)
- Denominator: `T3:notification_fans_show_cnt` (type: `uv`)
- Description: Notification_fans_click_user/show_user
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: uv / uv
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_fans_show_pv/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_fans_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_fans_show_pv/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_fans_show_user/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_fans_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_fans_show_user/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_like_click_pv/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_like_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_like_click_pv/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_like_click_pv/show_pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_like_click_cnt` (type: `pv`)
- Denominator: `T3:notification_like_show_cnt` (type: `pv`)
- Description: Notification_like_click_pv/show_pv
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: pv / pv
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_like_click_user/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_like_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_like_click_user/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_like_click_user/show_user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_like_click_cnt` (type: `uv`)
- Denominator: `T3:notification_like_show_cnt` (type: `uv`)
- Description: Notification_like_click_user/show_user
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: uv / uv
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_like_show_pv/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_like_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_like_show_pv/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_like_show_user/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_like_show_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_like_show_user/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_mention_aggregate_click_pv/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_mention_aggregate_click_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_mention_aggregate_click_pv/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_mention_aggregate_click_pv/show_pv
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_mention_aggregate_click_cnt` (type: `pv`)
- Denominator: `T3:notification_mention_aggregate_show_cnt` (type: `pv`)
- Description: Notification_mention_aggregate_click_pv/show_pv
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: pv / pv
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_mention_aggregate_click_user/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_mention_aggregate_click_cnt` (type: `uv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_mention_aggregate_click_user/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: uv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_mention_aggregate_click_user/show_user
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_mention_aggregate_click_cnt` (type: `uv`)
- Denominator: `T3:notification_mention_aggregate_show_cnt` (type: `uv`)
- Description: Notification_mention_aggregate_click_user/show_user
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: uv / uv
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Notification_mention_aggregate_show_pv/dau
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7032462
- Digest: [[digests/digest_7032462_inbox_message_metrics_uid]]
- Numerator: `T3:notification_mention_aggregate_show_cnt` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: Notification_mention_aggregate_show_pv/dau
- Provenance: `raw/libra/libra_metric_group_7032462.json`
- Aggregation: pv / base_user
- Key filters:
  - `action_type`, `enter_from` - 区分 message 分支与通知子类型
  - `element`, `message` - 区分组件层和消息层
  - `device`, `uid` - 区分设备级和用户级
- Source tables (from digest):
  - [[tables/table_musically-mds-fact-device-inbox-daily]]
  - [[tables/table_musically-mds-fact-user-inbox-daily]]
- Boundary notes:
  - Inbox message uid metrics are confirmed at user-level inbox aggregate table level.
  - User-side SQL is now extracted for both:

<!-- AUTO-GENERATED:metric_fields:end -->

> truncated: 34 more metrics omitted from the auto excerpt.
