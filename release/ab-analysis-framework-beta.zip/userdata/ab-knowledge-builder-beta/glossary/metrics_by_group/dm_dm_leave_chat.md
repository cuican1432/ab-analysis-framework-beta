# Metrics By Group | [DM] DM Leave Chat

group_id: 7003233
canonical_name: [DM] DM Leave Chat
tags: metric-group, dm
wiki_digests: [[digests/digest_7003233_dm_leave_chat]]
wiki_matrices: [[digests/event_metric_matrix_7003233_dm_leave_chat]]

## Metrics

- 进组用户
  - metric_id: `36209`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_unknown_metric__id_36209.md`
- leave chat rate
  - metric_id: `36210`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_leave_chat_rate__id_36210.md`
- leave chat list rate
  - metric_id: `36211`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_leave_chat_list_rate__id_36211.md`
- leave chat uv rate
  - metric_id: `36212`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_leave_chat_uv_rate__id_36212.md`
- leave chat list uv rate
  - metric_id: `36213`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_leave_chat_list_uv_rate__id_36213.md`

## Auto Definitions (Excerpt)

### Metric: leave chat list rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7003233
- Digest: [[digests/digest_7003233_dm_leave_chat]]
- Numerator: `T0:leave_chat_list_under_2s_cnt` (type: `pv`)
- Denominator: `T0:leave_chat_list_cnt` (type: `pv`)
- Description: count of leaving chat list which duration less than 2000ms/count of total leave chat list
- Provenance: `raw/libra/libra_metric_group_7003233.json`
- Aggregation: pv / pv
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - `leave_chat` itself is still only confirmed at raw-event-family level because the ByteIO basic payload remains partial.
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: leave chat list uv rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7003233
- Digest: [[digests/digest_7003233_dm_leave_chat]]
- Numerator: `T0:leave_chat_list_under_2s_cnt` (type: `uv`)
- Denominator: `T0:leave_chat_list_cnt` (type: `uv`)
- Description: count of users that leave chat list before staying 2000ms/count of all users that leaved chat list
- Provenance: `raw/libra/libra_metric_group_7003233.json`
- Aggregation: uv / uv
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - `leave_chat` itself is still only confirmed at raw-event-family level because the ByteIO basic payload remains partial.
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: leave chat rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7003233
- Digest: [[digests/digest_7003233_dm_leave_chat]]
- Numerator: `T0:leave_chat_under_2s_cnt` (type: `pv`)
- Denominator: `T0:leave_chat_cnt` (type: `pv`)
- Description: count of leaving chat which duration less than 2000ms/count of total leave chat
- Provenance: `raw/libra/libra_metric_group_7003233.json`
- Aggregation: pv / pv
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - `leave_chat` itself is still only confirmed at raw-event-family level because the ByteIO basic payload remains partial.
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: leave chat uv rate
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7003233
- Digest: [[digests/digest_7003233_dm_leave_chat]]
- Numerator: `T0:leave_chat_under_2s_cnt` (type: `uv`)
- Denominator: `T0:leave_chat_cnt` (type: `uv`)
- Description: count of users that leave chat before staying 2000ms/count of all users that leaved chat
- Provenance: `raw/libra/libra_metric_group_7003233.json`
- Aggregation: uv / uv
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - `leave_chat` itself is still only confirmed at raw-event-family level because the ByteIO basic payload remains partial.
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: 进组用户
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7003233
- Digest: [[digests/digest_7003233_dm_leave_chat]]
- Numerator: `(implicit)` (type: `pv`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户
- Provenance: `raw/libra/libra_metric_group_7003233.json`
- Aggregation: pv / base_user
- Numerator (from digest): `base_user`
- Denominator (from digest): `-`
- Key filters:
  - 无稳定过滤参数 - 仍以 aggregate family 解释
- Source tables (from digest):
  - [[tables/table_musically-edl-direct-message-metric-daily]]
- Boundary notes:
  - `leave_chat` itself is still only confirmed at raw-event-family level because the ByteIO basic payload remains partial.
  - 仍需更深层 Hive / DWD / ByteIO tracing 来升级置信度。

<!-- AUTO-GENERATED:metric_fields:end -->
