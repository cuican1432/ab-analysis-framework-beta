# Metrics By Group | [DM] DM by Entrance

group_id: 7015335
canonical_name: [DM] DM by Entrance
tags: metric-group, dm
wiki_digests: [[digests/digest_7015335_dm_by_entrance]]
wiki_matrices: [[digests/event_metric_matrix_7015335_dm_by_entrance]]

## Metrics

- User
  - metric_id: `3201823`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_base-user__id_3201823.md`
- User
  - metric_id: `3201823`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_user__id_3201823.md`
- Send Msg from FYP Days/Days
  - metric_id: `3201824`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_fyp_days_days__id_3201824.md`
- Send Msg from FYP Days/User
  - metric_id: `3201825`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_fyp_days_user__id_3201825.md`
- Send Msg from FYP/User
  - metric_id: `3201826`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_fyp_user__id_3201826.md`
- Send Msg from Profile Days/Days
  - metric_id: `3201827`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_profile_days_days__id_3201827.md`
- Send Msg from Profile Days/User
  - metric_id: `3201828`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_profile_days_user__id_3201828.md`
- Send Msg from Profile/User
  - metric_id: `3201829`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_profile_user__id_3201829.md`
- Send Msg from Inbox Days/Days
  - metric_id: `3201830`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_inbox_days_days__id_3201830.md`
- Send Msg from Inbox Days/User
  - metric_id: `3201831`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_inbox_days_user__id_3201831.md`
- Send Msg from Inbox/User
  - metric_id: `3201832`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_inbox_user__id_3201832.md`
- Send Msg from Inner Push Days/Days
  - metric_id: `3201833`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_inner_push_days_days__id_3201833.md`
- Send Msg from Inner Push Days/User
  - metric_id: `3201834`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_inner_push_days_user__id_3201834.md`
- Send Msg from Inner Push/User
  - metric_id: `3201835`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_inner_push_user__id_3201835.md`
- Send Msg from Outer Push Days/Days
  - metric_id: `3201836`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_outer_push_days_days__id_3201836.md`
- Send Msg from Outer Push Days/User
  - metric_id: `3201837`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_outer_push_days_user__id_3201837.md`
- Send Msg from Outer Push/User
  - metric_id: `3201838`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_outer_push_user__id_3201838.md`
- Send Msg from Chat Days/Days
  - metric_id: `3201839`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_chat_days_days__id_3201839.md`
- Send Msg from Chat Days/User
  - metric_id: `3201840`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_chat_days_user__id_3201840.md`
- Send Msg from Chat/User
  - metric_id: `3201841`
  - report_tier: `diagnostic`; role: `supporting`; good_if_up: `unknown`
  - wiki_metric_page: `metrics/metric_send_msg_from_chat_user__id_3201841.md`

## Auto Definitions (Excerpt)

### Metric: User (3201823)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from Chat Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_chat_list` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send message from chatroom penetration
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from Chat Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_chat_list` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message from chatroom days per user
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from Chat/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_chat_list` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message from chatroom count per user
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from FYP Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_homepage_hot` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send message from fyp penetration
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from FYP Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_homepage_hot` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message from fyp days per user
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from FYP/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_homepage_hot` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message from fyp count per user
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from Inbox Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_notification_page` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send message from notification page penetration
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from Inbox Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_notification_page` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message from notification page days per user
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from Inbox/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_notification_page` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message from notification page count per user
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from Inner Push Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_inner_push` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send message from inner push penetration
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from Inner Push Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_inner_push` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message from inner push days per user
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from Inner Push/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_inner_push` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message from inner push count per user
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from Outer Push Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_outer_push` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send message from outer push penetration
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from Outer Push Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_outer_push` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message from outer push days per user
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from Outer Push/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_outer_push` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message from outer push count per user
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from Profile Days/Days
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_others_homepage` (type: `action_days`)
- Denominator: `T0:is_active` (type: `action_days`)
- Description: send message from others profile penetration
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from Profile Days/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_others_homepage` (type: `action_days`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message from others profile days per user
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: Send Msg from Profile/User
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `T0:send_message_from_others_homepage` (type: `pv`)
- Denominator: `(implicit)` (type: `base_user`)
- Description: send message from others profile count per user
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->

### Metric: User (3201823)
<!-- AUTO-GENERATED:metric_fields:start -->
## Metric Definition (Auto)

- 目标：为每个指标沉淀 `分子/分母/过滤参数/口径边界/上游表`；归因请优先读对应的 Attribution Matrix。

### Group 7015335
- Digest: [[digests/digest_7015335_dm_by_entrance]]
- Numerator: `(implicit)` (type: `base_user`)
- Denominator: `(implicit)` (type: `-`)
- Description: 进组用户 | Experiment group user cnt
- Provenance: `raw/libra/libra_metric_group_7015335.json`
- Key filters:
  - `enter_from` - 同一发送事件族按入口拆维
- Source tables (from digest):
  - `musically.adl_user_direct_message_metric_daily`
  - `musically.edl_direct_message_metric_daily`
- Boundary notes:
  - 还未把各 entrance bucket 精确回写到 canonical event 参数说明
  - 入口字段在底层表中的精确字段名还需继续用 Hive 口径页补充

<!-- AUTO-GENERATED:metric_fields:end -->
