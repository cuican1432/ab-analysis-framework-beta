# Metric Group Working Table | 指标组工作表

Generated from `karpathy-data-wiki/wiki/metric_groups/*`.

| group_id | group_name | tags | digests | matrices | notes |
|---|---|---|---|---|---|
| `7003233` | `[DM] DM Leave Chat` | `metric-group, dm` | `[[digests/digest_7003233_dm_leave_chat]]` | `[[digests/event_metric_matrix_7003233_dm_leave_chat]]` | `` |
| `7014898` | `[DM] DM Receive` | `metric-group, dm` | `[[digests/digest_7014898_dm_receive]]` | `[[digests/event_metric_matrix_7014898_dm_receive]]` | `` |
| `7015262` | `[DM] DM by Msg Type` | `metric-group, dm` | `[[digests/digest_7015262_dm_by_msg_type]]` | `[[digests/event_metric_matrix_7015262_dm_by_msg_type]]` | `` |
| `7015335` | `[DM] DM by Entrance` | `metric-group, dm` | `[[digests/digest_7015335_dm_by_entrance]]` | `[[digests/event_metric_matrix_7015335_dm_by_entrance]]` | `` |
| `7018203` | `DM Core` | `metric-group, dm` | `[[digests/digest_7018203_dm_core]]` | `[[digests/event_metric_matrix_7018203_dm_core]]` | `` |
| `7019062` | `Key Project-DM` | `metric-group, dm` | `[[digests/digest_7019062_key_project_dm]]` | `[[digests/event_metric_matrix_7019062]]` | `` |
| `7019895` | `Inbox Element Metrics` | `metric-group, dm` | `[[digests/digest_7019895_inbox_element_metrics]]` | `[[digests/event_metric_matrix_7019895_inbox_element_metrics]]` | `` |
| `7027819` | `[DM] DM by Link` | `metric-group, dm` | `[[digests/digest_7027819_dm_by_link]]` | `[[digests/event_metric_matrix_7027819_dm_by_link]]` | `` |
| `7029593` | `internal share funnel metrics` | `metric-group, dm` | `[[digests/digest_7029593_internal_share_funnel_metrics]]` | `[[digests/event_metric_matrix_7029593_internal_share_funnel_metrics]]` | `` |
| `7032341` | `Inbox element metrics uid` | `metric-group, dm` | `[[digests/digest_7032341_inbox_element_metrics_uid]]` | `[[digests/event_metric_matrix_7032341_inbox_element_metrics_uid]]` | `` |
| `7032462` | `Inbox message metrics uid` | `metric-group, dm` | `[[digests/digest_7032462_inbox_message_metrics_uid]]` | `[[digests/event_metric_matrix_7032462_inbox_message_metrics_uid]]` | `` |
| `7033046` | `[DM] DM Conversion Funnel` | `metric-group, dm` | `[[digests/digest_7033046_dm_conversion_funnel]]` | `[[digests/event_metric_matrix_7033046_dm_conversion_funnel]]` | `` |
| `7034976` | `[IM] Group Chat Metrics` | `metric-group, dm` | `[[digests/digest_7034976_dm_group_chat]]` | `[[digests/event_metric_matrix_7034976_dm_group_chat]]` | `` |
| `7036186` | `[IM] DM Camera Metrics` | `metric-group, dm` | `[[digests/digest_7036186_dm_camera]]` | `[[digests/event_metric_matrix_7036186_dm_camera]]` | `` |
| `7041632` | `Activity Status User Metrics` | `metric-group, dm` | `[[digests/digest_7041632_activity_status_user_metrics]]` | `[[digests/event_metric_matrix_7041632_activity_status_user_metrics]]` | `` |
| `7041665` | `Activity Status Metrics` | `metric-group, dm` | `[[digests/digest_7041665_activity_status_metrics]]` | `[[digests/event_metric_matrix_7041665_activity_status_metrics]]` | `` |
| `7042278` | `[DM] DM Permission` | `metric-group, dm` | `[[digests/digest_7042278_dm_permission]]` | `[[digests/event_metric_matrix_7042278_dm_permission]]` | `` |
| `7043217` | `[IM] DM Camera Metrics by entrance` | `metric-group, dm` | `[[digests/digest_7043217_dm_camera_by_entrance]]` | `[[digests/event_metric_matrix_7043217_dm_camera_by_entrance]]` | `` |
| `7043978` | `TnS DM Private Sender Metrics - Conv Level` | `metric-group, dm` | `[[digests/digest_7043978_tns_dm_private_sender_metrics_conv_level]]` | `[[digests/event_metric_matrix_7043978_tns_dm_private_sender_metrics_conv_level]]` | `` |
| `7043979` | `TnS DM Group Chat Sender Metrics - Msg Level` | `metric-group, dm` | `[[digests/digest_7043979_tns_dm_group_chat_sender_metrics_msg_level]]` | `[[digests/event_metric_matrix_7043979_tns_dm_group_chat_sender_metrics_msg_level]]` | `` |
| `7043980` | `TnS DM Group Chat Sender Metrics - Conv Level` | `metric-group, dm` | `[[digests/digest_7043980_tns_dm_group_chat_sender_metrics_conv_level]]` | `[[digests/event_metric_matrix_7043980_tns_dm_group_chat_sender_metrics_conv_level]]` | `` |
| `7043981` | `TnS DM Group Chat Receiver Metrics - Msg Level` | `metric-group, dm` | `[[digests/digest_7043981_tns_dm_group_chat_receiver_metrics_msg_level]]` | `[[digests/event_metric_matrix_7043981_tns_dm_group_chat_receiver_metrics_msg_level]]` | `` |
| `7043982` | `TnS DM Private Sender Metrics - Msg Level` | `metric-group, dm` | `[[digests/digest_7043982_tns_dm_private_sender_metrics_msg_level]]` | `[[digests/event_metric_matrix_7043982_tns_dm_private_sender_metrics_msg_level]]` | `` |
| `7043983` | `TnS DM Private Receiver Metrics - Msg Level` | `metric-group, dm` | `[[digests/digest_7043983_tns_dm_private_receiver_metrics_msg_level]]` | `[[digests/event_metric_matrix_7043983_tns_dm_private_receiver_metrics_msg_level]]` | `` |
| `7044888` | `[B2C] Business Message Key Metrics` | `metric-group, dm` | `[[digests/digest_7044888_b2c_business_message_key_metrics]]` | `[[digests/event_metric_matrix_7044888_b2c_business_message_key_metrics]]` | `` |
| `7045333` | `DM_streak` | `metric-group, dm` | `[[digests/digest_7045333_dm_streak]]` | `[[digests/event_metric_matrix_7045333_dm_streak]]` | `` |
| `7046339` | `DM_Share_Type | direct message share type` | `metric-group, dm` | `[[digests/digest_7046339_dm_share_type]]` | `[[digests/event_metric_matrix_7046339_dm_share_type]]` | `` |
| `7046953` | `[IM] DM Sticker Metrics` | `metric-group, dm` | `[[digests/digest_7046953_dm_sticker]]` | `[[digests/event_metric_matrix_7046953_dm_sticker]]` | `` |
| `7047592` | `DM Quick Share` | `metric-group, dm` | `[[digests/digest_7047592_dm_quick_share]]` | `[[digests/event_metric_matrix_7047592_dm_quick_share]]` | `` |
| `7048542` | `[DM] DM Message Pairs` | `metric-group, dm` | `[[digests/digest_7048542_dm_message_pairs]]` | `[[digests/event_metric_matrix_7048542_dm_message_pairs]]` | `` |
| `7049137` | `DM Growth Pairs-Key Metrics` | `metric-group, dm` | `[[digests/digest_7049137_growth_pairs_key_metrics]]` | `[[digests/event_metric_matrix_7049137_growth_pairs_key_metrics]]` | `` |
| `7049143` | `Core Interaction Growth Pairs Active Days` | `metric-group, dm` | `[[digests/digest_7049143_core_interaction_growth_pairs_active_days]]` | `[[digests/event_metric_matrix_7049143_core_interaction_growth_pairs_active_days]]` | `` |
| `7049146` | `DM Growth Pairs-Active Days` | `metric-group, dm` | `[[digests/digest_7049146_dm_growth_pairs_active_days]]` | `[[digests/event_metric_matrix_7049146_dm_growth_pairs_active_days]]` | `` |
| `7049184` | `[DM] DM Group Chat by Msg Type` | `metric-group, dm` | `[[digests/digest_7049184_dm_group_chat_by_msg_type]]` | `[[digests/event_metric_matrix_7049184_dm_group_chat_by_msg_type]]` | `` |
| `7049357` | `DM Growth Pairs- Retention` | `metric-group, dm` | `[[digests/digest_7049357_dm_growth_pairs_retention]]` | `[[digests/event_metric_matrix_7049357_dm_growth_pairs_retention]]` | `` |
| `7049358` | `Core Interaction Growth Pairs- Retention` | `metric-group, dm` | `[[digests/digest_7049358_core_interaction_growth_pairs_retention]]` | `[[digests/event_metric_matrix_7049358_core_interaction_growth_pairs_retention]]` | `` |
| `7049566` | `[B2C] Creator Message Key Metrics` | `metric-group, dm` | `[[digests/digest_7049566_b2c_creator_message_key_metrics]]` | `[[digests/event_metric_matrix_7049566_b2c_creator_message_key_metrics]]` | `` |
| `7049585` | `[IM] Group Chat 3d Retention metrics` | `metric-group, dm` | `[[digests/digest_7049585_dm_group_chat_3d_retention]]` | `[[digests/event_metric_matrix_7049585_dm_group_chat_3d_retention]]` | `` |
| `7049633` | `[IM] Group Chat 7d Retention metrics` | `metric-group, dm` | `[[digests/digest_7049633_dm_group_chat_7d_retention]]` | `[[digests/event_metric_matrix_7049633_dm_group_chat_7d_retention]]` | `` |
| `7049634` | `[IM] Group Chat 14d Retention metrics` | `metric-group, dm` | `[[digests/digest_7049634_dm_group_chat_14d_retention]]` | `[[digests/event_metric_matrix_7049634_dm_group_chat_14d_retention]]` | `` |
| `7049635` | `[IM] Group Chat 28d Retention metrics` | `metric-group, dm` | `[[digests/digest_7049635_dm_group_chat_28d_retention]]` | `[[digests/event_metric_matrix_7049635_dm_group_chat_28d_retention]]` | `` |
| `7050036` | `Internal Share All` | `metric-group, dm` | `[[digests/digest_7050036_internal_share_all]]` | `[[digests/event_metric_matrix_7050036_internal_share_all]]` | `` |
| `7051462` | `[DM] MuF DM by Motivation` | `metric-group, dm` | `[[digests/digest_7051462_muf_dm_by_motivation]]` | `[[digests/event_metric_matrix_7051462_muf_dm_by_motivation]]` | `` |
| `7054071` | `[IM] Voice Message Metrics` | `metric-group, dm` | `[[digests/digest_7054071_dm_voice_message]]` | `[[digests/event_metric_matrix_7054071_dm_voice_message]]` | `` |
| `7054231` | `[IM] DM Camera Metrics Private Chat` | `metric-group, dm` | `[[digests/digest_7054231_dm_camera_private_chat]]` | `[[digests/event_metric_matrix_7054231_dm_camera_private_chat]]` | `` |
| `7054232` | `[IM] DM Camera Metrics Group Chat by entrance` | `metric-group, dm` | `[[digests/digest_7054232_dm_camera_group_chat_by_entrance]]` | `[[digests/event_metric_matrix_7054232_dm_camera_group_chat_by_entrance]]` | `` |
| `7054233` | `[IM] DM Camera Metrics Group Chat` | `metric-group, dm` | `[[digests/digest_7054233_dm_camera_group_chat]]` | `[[digests/event_metric_matrix_7054233_dm_camera_group_chat]]` | `` |
| `7054234` | `[IM] DM Camera Metrics Private Chat by entrance` | `metric-group, dm` | `[[digests/digest_7054234_dm_camera_private_chat_by_entrance]]` | `[[digests/event_metric_matrix_7054234_dm_camera_private_chat_by_entrance]]` | `` |
| `7054477` | `internal share search funnel metrics` | `metric-group, dm` | `[[digests/digest_7054477_internal_share_search_funnel_metrics]]` | `[[digests/event_metric_matrix_7054477_internal_share_search_funnel_metrics]]` | `` |
| `7056673` | `[IM] New gt3-users Group Chat 14d Retention` | `metric-group, dm` | `[[digests/digest_7056673_dm_group_chat_14d_retention_new_gt3_users]]` | `[[digests/event_metric_matrix_7056673_dm_group_chat_14d_retention_new_gt3_users]]` | `` |
| `7056674` | `[IM] New gt3-users Group Chat 3d Retention` | `metric-group, dm` | `[[digests/digest_7056674_dm_group_chat_3d_retention_new_gt3_users]]` | `[[digests/event_metric_matrix_7056674_dm_group_chat_3d_retention_new_gt3_users]]` | `` |
| `7056675` | `[IM] New gt3-users Group Chat 7d Retention` | `metric-group, dm` | `[[digests/digest_7056675_dm_group_chat_7d_retention_new_gt3_users]]` | `[[digests/event_metric_matrix_7056675_dm_group_chat_7d_retention_new_gt3_users]]` | `` |
| `7056676` | `[IM] New gt3-users Group Chat 28d Retention` | `metric-group, dm` | `[[digests/digest_7056676_dm_group_chat_28d_retention_new_gt3_users]]` | `[[digests/event_metric_matrix_7056676_dm_group_chat_28d_retention_new_gt3_users]]` | `` |
